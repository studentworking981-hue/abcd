"""
Application-wide constants.

These values were originally hardcoded inline inside
``ImageAnalyzerApp.__init__`` in the single-file version of this
application. They are reproduced here **unchanged** (same literal
values) and simply referenced from ``app.py`` instead of being
duplicated inline, per the "centralize configuration values" goal of
the refactor. No value has been altered.
"""

# ── Colour palette (professional dark-steel theme) ─────────────────────────
COLOR_BG = '#1e2328'   # near-black charcoal
COLOR_PANEL = '#252b33'   # dark steel panel
COLOR_ACCENT = '#2e3a4a'   # muted slate-blue accent
COLOR_HIGHLIGHT = '#2d7dd2'   # professional azure blue
COLOR_FG = '#dde3ea'   # soft white text
COLOR_FG2 = '#7f8c9a'   # muted grey-blue subtext
COLOR_BTN_BG = '#2e3a4a'   # slate button
COLOR_BTN_ACT = '#1a5fa8'   # darker azure on hover
COLOR_ENTRY_BG = '#181d22'   # deep input background

# ── Window sizing ───────────────────────────────────────────────────────────
MAIN_WINDOW_GEOMETRY = "1400x900"
HEADER_HEIGHT = 54
FOOTER_HEIGHT = 28

# ── Header / footer text ────────────────────────────────────────────────────
APP_HEADER_TITLE = 'ADDITIVE MANUFACTURING DEFECT DETECTION'
APP_FOOTER_TEXT = 'Designed and Developed by RCI-DAIV'

# ── Navigation tab keys/labels (used to build the nav pill buttons) ────────
NAV_TABS = [
    ('single', 'Single Image'),
    ('batch', 'Batch Processing & 3D Visualization'),
]

# ── Default 18-step pipeline parameters (12 original + 6 PBF steps) ─────────
# Single source of truth for the per-step parameter defaults, used by both
# the Single Image tab (ui/tabs.py) and the Batch tab (processing/batch.py)
# so the two can never drift apart again. Steps 0/1 have no tunable
# parameters (original image / ROI mask) so they have no entry here.
#
# NOTE: the old Step 11 (Topography Surface Generation) and Step 12
# (Topo-Watershed defect mask) have been removed entirely -- they duplicated
# the bright/dark defect detection already done by the histogram-markers +
# watershed stages below (and by the PBF engine above), and their output
# was only ever folded back in via a bitwise-OR patch rather than a real
# pipeline hand-off. Steps 13-20 have been renumbered down to 11-18 to
# close the gap.
#
# IMPORTANT (regression fix): `step_11_markers.enabled` must be True to match
# the original pipeline's equivalent step. Leaving it False makes every
# masked pixel count as foreground, producing one oversized blob that gets
# filtered out entirely at Step 17 (min_area/max_area), so nearly every
# image is misclassified as Non-Indicator.
DEFAULT_PIPELINE_PARAMS = {
    'step_2_rotate_flip':   {'enabled': True, 'rotate': 0, 'flip_h': False, 'flip_v': False},
    'step_3_grayscale':     {'enabled': True},
    'step_4_sobel':         {'enabled': False},

    # ── NEW Step 5-10: PBF-style multi-band defect conditioning ────────
    # Inserted between the original Step 4 and Step 5. Ported unchanged
    # from the standalone PBF inspector engine (processing/pbf_defect.py).
    # These six steps run together as one detection pass (illumination
    # flatten -> denoise -> multi-scale DoG -> watershed+shape filter ->
    # full-extent band -> minute-defect rescue); only the resulting
    # denoised grayscale image is handed to the (renumbered) Step 11
    # onward, so every downstream step is unaffected. If every one of
    # these six is disabled, the grayscale image passes through
    # untouched and the pipeline continues exactly as before.
    'step_5_pbf_illum':      {'enabled': True, 'bg_sigma': 45.0,
                               'bilat_d': 9, 'bilat_sc': 50.0, 'bilat_ss': 50.0},
    'step_6_pbf_dog':        {'enabled': True, 'fine_sigma1': 1.0, 'fine_sigma2': 3.0,
                               'coarse_sigma1': 5.0, 'coarse_sigma2': 16.0, 'recon_radius': 1},
    'step_7_pbf_sensitivity': {'enabled': True, 'noise_k_fine': 4.0, 'noise_k_coarse': 3.5,
                               'min_component_area_fine': 5, 'min_component_area_coarse': 60,
                               'local_max_min_dist': 4, 'compactness': 0.0},
    'step_8_pbf_shape':      {'enabled': True, 'min_area': 12, 'max_area': 25000,
                               'min_circularity': 0.4, 'min_solidity': 0.8,
                               'max_aspect_ratio': 5.0, 'min_convexity': 0.88},
    'step_9_pbf_extent':     {'enabled': True, 'close_radius_fine': 1, 'close_radius_coarse': 2,
                               'close_radius_extent': 3, 'extent_k': 3.0,
                               'min_component_area_extent': 120, 'local_max_min_dist_extent': 15},
    'step_10_pbf_rescue':    {'enabled': True, 'micro_rescue_ring_px': 6,
                               'micro_rescue_min_z': 3.0, 'micro_rescue_max_area': 40},

    'step_11_markers':       {'enabled': True, 'low_threshold': 90, 'high_threshold': 220},
    'step_12_watershed':     {'enabled': False},
    'step_13_morph_close':   {'enabled': False, 'iterations': 1},
    'step_14_morph_open':    {'enabled': False, 'iterations': 1},
    'step_15_fillholes':     {'enabled': False},
    'step_16_labeling':      {'enabled': True, 'min_size': 50},
    'step_17_final':         {'min_area': 50, 'max_area': 10000},
    'step_18_perspective':   {'enabled': True},
}
