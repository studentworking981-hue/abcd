"""Tab/frame creation and layout: builds the widgets for the Single Image tab
(ROI + step-by-step controls) and the merged Batch Processing & 3D
Visualization tab. Relocated verbatim from ImageAnalyzerApp in the
original single-file app; only the hardcoded 3D-viz default values and
tool paths inside _init_tab_batch_3d were swapped for the equivalent
constants in utils.config (same values)."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from PIL import Image, ImageTk
import cv2
import numpy as np
from scipy import ndimage as ndi
from skimage.segmentation import watershed as _skimage_watershed
from skimage.morphology import disk
import copy
import json
import math
import os
import sys
import gc
import threading
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from ..utils import config
from ..utils.constants import DEFAULT_PIPELINE_PARAMS


class TabsMixin:
    """
    Mixin holding methods relocated verbatim from the original
    ``ImageAnalyzerApp`` god-class. It is combined with the other
    mixins in ``app.Application`` via multiple inheritance, so every
    method below still shares the same ``self`` (and therefore the
    same widgets / state) as before -- nothing about how these
    methods call each other or access ``self.*`` attributes changed.
    """

    def _init_tab_batch_3d(self):
        """Initialize the merged Batch Processing & 3D Visualization tab."""
        self.tab3_input_folder = None
        self.tab3_config_data  = None
        self.tab3_roi_points   = None
        self.tab3_processing   = False
        self._batch3d_stop_flag = False   # set True by Stop button

        # Reports state
        self._rpt_results_data = None
        self._rpt_metrics_data = None
        self._rpt_pred_folder = None
        self._rpt_gt_folder = None

        # 3D Viz hardcoded defaults (preserved from original, now centralised
        # in utils/config.py -- same values, just no longer duplicated inline)
        #values of the volume loaded from the images
        self._VIZ3D_SP_X = config.VIZ3D_SP_X
        self._VIZ3D_SP_Y = config.VIZ3D_SP_Y
        self._VIZ3D_SP_Z = config.VIZ3D_SP_Z  # 10.0 0.48  0.6
        self._VIZ3D_ISLAND = config.VIZ3D_ISLAND
        self._VIZ3D_R_MIN = config.VIZ3D_R_MIN
        self._VIZ3D_G_MAX = config.VIZ3D_G_MAX
        self._VIZ3D_B_MAX = config.VIZ3D_B_MAX
        #cad/stl model of the article
        self._VIZ3D_SX = config.VIZ3D_SX
        self._VIZ3D_SY = config.VIZ3D_SY
        self._VIZ3D_SZ = config.VIZ3D_SZ
        self._VIZ3D_TX = config.VIZ3D_TX
        self._VIZ3D_TY = config.VIZ3D_TY
        self._VIZ3D_TZ = config.VIZ3D_TZ

        # 3D Viz parameters for the seg.nrrd segmentation model   independent
        # of the STL parameters above. Defaults to an identity transform
        # (scale=1, translate=0) so existing behaviour is unchanged unless
        # these are explicitly set to something else.
        self._VIZ3D_NRRD_SX = config.VIZ3D_NRRD_SX
        self._VIZ3D_NRRD_SY = config.VIZ3D_NRRD_SY
        self._VIZ3D_NRRD_SZ = config.VIZ3D_NRRD_SZ
        self._VIZ3D_NRRD_TX = config.VIZ3D_NRRD_TX
        self._VIZ3D_NRRD_TY = config.VIZ3D_NRRD_TY
        self._VIZ3D_NRRD_TZ = config.VIZ3D_NRRD_TZ
        self._freecad_exe_var = tk.StringVar(value=config.DEFAULT_FREECAD_EXE)
        # ── Hardcoded 3D Slicer path ─────────────────────────────────────
        self._slicer_exe_var = tk.StringVar(value=config.DEFAULT_SLICER_EXE)

        frame = self.tab_frames['batch']
        frame.configure(bg=self.BG)

        # ── Helper ───────────────────────────────────────────────────────
        def _row_entry(parent, label_text, var, cmd, btn_text='Browse', extra_left_pad=0):
            row = tk.Frame(parent, bg=self.PANEL)
            row.pack(fill='x', padx=(16 + extra_left_pad, 16), pady=5)
            tk.Label(row, text=label_text, bg=self.PANEL, fg=self.FG2,
                     font=(self.FONT, 9), width=16, anchor='w').pack(side='left')
            entry = tk.Entry(row, textvariable=var, bg=self.ENTRY_BG, fg=self.FG,
                             relief='flat', font=(self.FONT, 9), state='readonly',
                             readonlybackground=self.ENTRY_BG, bd=0)
            entry.pack(side='left', fill='x', expand=True, ipady=6, padx=(6, 8))
            tk.Button(row, text=btn_text, command=cmd,
                      bg=self.BTN_BG, fg=self.FG, relief='flat',
                      font=(self.FONT, 9, 'bold'), padx=10,
                      activebackground=self.HIGHLIGHT, cursor='hand2').pack(side='right')

        # ── Settings card ────────────────────────────────────────────────
        card = tk.Frame(frame, bg=self.PANEL)
        card.pack(fill='x', padx=20, pady=(18, 0))

        tk.Label(card, text='',
                 bg=self.PANEL, fg=self.HIGHLIGHT,
                 font=(self.FONT, 13, 'bold')).pack(anchor='w', padx=16, pady=(14, 10))


        # Input Folder row
        self._tab3_folder_var = tk.StringVar(value='Not selected')
        _row_entry(card, 'INPUT FOLDER :', self._tab3_folder_var,
                   self._batch3d_pick_input_folder)

        # STL File row
        self._batch3d_stl_var = tk.StringVar(value='Not selected')
        def _pick_stl():
            p = filedialog.askopenfilename(
                title='Select STL File',
                filetypes=[('STL / STEP files', '*.stl *.step *.stp'),
                           ('All files', '*.*')])
            if p:
                self._batch3d_stl_var.set(p)
        _row_entry(card, 'ARTICLE CAD MODEL:', self._batch3d_stl_var, _pick_stl)
                   

        # Output Folder row
        self._tab3_output_var = tk.StringVar(value='Not selected')
        def _pick_out():
            p = filedialog.askdirectory(title='Select Output Folder')
            if p:
                self._tab3_output_var.set(p)
        _row_entry(card, 'OUTPUT FOLDER:', self._tab3_output_var, _pick_out)

        # ── Separator ────────────────────────────────────────────────────
        tk.Frame(card, bg=self.ACCENT, height=1).pack(fill='x', padx=16, pady=(8, 10))

        # ── Action buttons ────────────────────────────────────────────────
        btn_row = tk.Frame(card, bg=self.PANEL)
        btn_row.pack(fill='x', padx=16, pady=(0, 14))

        self._batch3d_start_btn = tk.Button(
            btn_row, text='  Start',
            command=self._batch3d_start,
            bg=self.HIGHLIGHT, fg='#ffffff', relief='flat',
            font=(self.FONT, 11, 'bold'), padx=18, pady=6,
            activebackground=self.BTN_ACT, cursor='hand2')
        self._batch3d_start_btn.pack(side='left', padx=(0, 6))

        self._batch3d_stop_btn = tk.Button(
            btn_row, text=' Stop',
            command=self._batch3d_stop,
            bg=self.BTN_BG, fg=self.FG, relief='flat',
            font=(self.FONT, 11, 'bold'), padx=18, pady=6,
            activebackground=self.HIGHLIGHT, cursor='hand2')
        self._batch3d_stop_btn.pack(side='left', padx=(0, 6))

        self._batch3d_clear_btn = tk.Button(
            btn_row, text=' Clear',
            command=self._batch3d_clear,
            bg=self.BTN_BG, fg=self.FG, relief='flat',
            font=(self.FONT, 11, 'bold'), padx=18, pady=6,
            activebackground=self.HIGHLIGHT, cursor='hand2')
        self._batch3d_clear_btn.pack(side='left', padx=(0, 6))

        self._batch3d_viz_btn = tk.Button(
            btn_row, text=' 3D Visualise',
            command=self._batch3d_launch_viz_independent,
            bg='#1e3a2f', fg='#5dbf8e', relief='flat',
            font=(self.FONT, 11, 'bold'), padx=18, pady=6,
            activebackground='#14532d', cursor='hand2')
        self._batch3d_viz_btn.pack(side='left', padx=(0, 6))

        self._batch3d_reports_btn = tk.Button(
            btn_row, text=' Reports',
            command=self._open_reports_popup,
            bg=self.BTN_BG, fg=self.FG, relief='flat',
            font=(self.FONT, 11, 'bold'), padx=18, pady=6,
            activebackground=self.HIGHLIGHT, cursor='hand2')
        self._batch3d_reports_btn.pack(side='left')

        # ── Change 3: clickable report hyperlink (not a separate button) ──
        # Always points to the most recently generated report; styled and
        # behaves like a real hyperlink (underlined link-colored text,
        # hand cursor) rather than a button.
        self._batch3d_report_link_btn = tk.Label(
            btn_row, text='No report generated yet',
            bg=self.PANEL, fg=self.FG2,
            font=(self.FONT, 9, 'underline'), cursor='arrow')
        self._batch3d_report_link_btn.pack(side='left', padx=(14, 0))
        self._batch3d_report_link_btn.bind('<Button-1>', lambda e: self._batch3d_open_report())
        self._latest_report_path = None

        # ── Progress card ─────────────────────────────────────────────────
        prog_card = tk.Frame(frame, bg=self.PANEL)
        prog_card.pack(fill='x', padx=20, pady=(10, 0))

        prog_top = tk.Frame(prog_card, bg=self.PANEL)
        prog_top.pack(fill='x', padx=16, pady=(12, 4))

        self._batch3d_status_lbl = tk.Label(
            prog_top, text='Ready', bg=self.PANEL, fg=self.HIGHLIGHT,
            font=(self.FONT, 10, 'bold'))
        self._batch3d_status_lbl.pack(side='left')

        self._batch3d_progress = ttk.Progressbar(
            prog_top, orient='horizontal', mode='determinate', length=500)
        self._batch3d_progress.pack(side='right', fill='x', expand=True, padx=(16, 8))

        self._batch3d_pct_lbl = tk.Label(
            prog_top, text='0%', bg=self.PANEL, fg=self.FG2,
            font=(self.FONT, 9, 'bold'), width=5, anchor='e')
        self._batch3d_pct_lbl.pack(side='right')

        
        # ── Status / Log card ─────────────────────────────────────────────
        log_card = tk.Frame(frame, bg=self.PANEL)
        log_card.pack(fill='both', expand=True, padx=20, pady=(10, 12))

        tk.Label(log_card, text='Status', bg=self.PANEL, fg=self.FG2,
                 font=(self.FONT, 9, 'bold')).pack(anchor='w', padx=16, pady=(10, 4))

        log_outer = tk.Frame(log_card, bg=self.BG)
        log_outer.pack(fill='both', expand=True, padx=10, pady=(0, 10))

        log_sb = ttk.Scrollbar(log_outer)
        log_sb.pack(side='right', fill='y')

        self.tab3_log_text = scrolledtext.ScrolledText(
            log_outer, height=18,
            bg='#181d22', fg='#b0bec9',
            font=(self.FONT_MONO, 9), relief='flat', bd=0,
            insertbackground=self.FG,
            yscrollcommand=log_sb.set)
        self.tab3_log_text.pack(fill='both', expand=True)
        log_sb.config(command=self.tab3_log_text.yview)

    def init_tab1(self):
        """Initialise ROI Selection variables (UI is opened via open_roi_window)."""
        self.tab1_image = None
        self.tab1_cv_image = None
        self.tab1_photo = None
        self.tab1_polygon_points = []
        self.tab1_image_path = None
        self.tab1_polygon_closed = False
        self.tab1_zoom_level = 1.0
        self._roi_win = None
        # Placeholder label – real UI lives in open_roi_window()
        self.tab1_info_label = tk.Label(self.root)  # dummy; replaced when window opens

    def init_tab2(self):
        """Initialize Single Image tab – Watershed Analysis with new GUI layout."""
        # Variables
        self.tab2_image = None
        self.tab2_cv_image = None
        self.tab2_roi_points = None
        self.tab2_image_path = None
        self.current_step = 0
        self.step_images = {}
        self.step_data = {}
        self.tab2_zoom_level = 1.0

        # Step 1 inline ROI drawing state
        self.step1_polygon_points = []
        self.step1_polygon_closed = False
        self._roi_save_dir = None

        # Default parameters for each step.
        # REGRESSION FIX (R3/R4): this used to be a hand-maintained literal
        # dict that drifted from the one in processing/batch.py (in
        # particular step_11_markers.enabled was False here vs True there).
        # Both now deep-copy the single source of truth in
        # utils/constants.py so Single Image and Batch processing can never
        # disagree on defaults again.
        self.params = copy.deepcopy(DEFAULT_PIPELINE_PARAMS)

        frame = self.tab2  # == self.tab_frames['single']
        frame.configure(bg=self.BG)

        # ── Top toolbar ──────────────────────────────────────────────────
        toolbar = tk.Frame(frame, bg=self.PANEL, height=46)
        toolbar.pack(side='top', fill='x')
        toolbar.pack_propagate(False)

        def _mk_btn(parent, text, cmd):
            return tk.Button(parent, text=text, command=cmd,
                             bg=self.BTN_BG, fg=self.FG, relief='flat',
                             font=(self.FONT, 9, 'bold'), padx=10, pady=4,
                             activebackground=self.HIGHLIGHT, cursor='hand2')

        _mk_btn(toolbar, 'Load Image',       self.tab2_upload_image    ).pack(side='left', padx=6, pady=7)
        _mk_btn(toolbar, 'Load Config',      self.tab2_load_config     ).pack(side='left', padx=2, pady=7)
        _mk_btn(toolbar, 'Save Config',      self.tab2_save_config     ).pack(side='left', padx=2, pady=7)
        _mk_btn(toolbar, 'Start Processing', self.tab2_start_processing).pack(side='left', padx=2, pady=7)

        self.tab2_info_label = tk.Label(toolbar,
            text="ORIGINAL IMAGE: Raw loaded greyscale image – no processing applied yet",
            bg=self.PANEL, fg=self.FG2, font=(self.FONT, 9))
        self.tab2_info_label.pack(side='left', padx=14)

        # ── Step number pills [1][2] [10] ───────────────────────────────
        step_bar = tk.Frame(frame, bg=self.BG)
        step_bar.pack(side='top', fill='x', padx=8, pady=(6, 2))

        self._step_pill_btns = {}
        for i in range(19):
            label = str(i) if i > 0 else '0'
            btn = tk.Button(step_bar, text=label, width=3,
                            bg=self.ACCENT, fg=self.FG2, relief='flat',
                            font=(self.FONT, 9, 'bold'),
                            activebackground=self.HIGHLIGHT,
                            cursor='hand2',
                            command=lambda s=i: self._jump_to_step(s))
            btn.pack(side='left', padx=2)
            self._step_pill_btns[i] = btn

        # ── Main content (image left, params right) ──────────────────────
        content = tk.Frame(frame, bg=self.BG)
        content.pack(fill='both', expand=True, padx=8, pady=(2, 4))

        # Left: image canvas
        img_frame = tk.Frame(content, bg=self.BG)
        img_frame.pack(side='left', fill='both', expand=True, padx=(0, 6))

        self.tab2_canvas = tk.Canvas(img_frame, bg='#181d22', highlightthickness=0)
        v_sb = ttk.Scrollbar(img_frame, orient='vertical', command=self.tab2_canvas.yview)
        h_sb = ttk.Scrollbar(img_frame, orient='horizontal', command=self.tab2_canvas.xview)
        self.tab2_canvas.configure(yscrollcommand=v_sb.set, xscrollcommand=h_sb.set)
        v_sb.pack(side='right', fill='y')
        h_sb.pack(side='bottom', fill='x')
        self.tab2_canvas.pack(side='left', fill='both', expand=True)

        self.tab2_canvas.bind('<MouseWheel>',
                              lambda e: self.tab2_canvas.yview_scroll(int(-1*(e.delta/120)), "units"))
        self.tab2_canvas.bind('<Shift-MouseWheel>',
                              lambda e: self.tab2_canvas.xview_scroll(int(-1*(e.delta/120)), "units"))
        self.tab2_canvas.bind('<Control-MouseWheel>', self.tab2_zoom)
        # Linux uses Button-4 (scroll up) and Button-5 (scroll down)
        self.tab2_canvas.bind('<Control-Button-4>', self.tab2_zoom)
        self.tab2_canvas.bind('<Control-Button-5>', self.tab2_zoom)
        self.tab2_canvas.bind('<plus>',  lambda e: self.tab2_zoom_button(1.1))
        self.tab2_canvas.bind('<minus>', lambda e: self.tab2_zoom_button(0.9))
        self.tab2_canvas.bind('<equal>', lambda e: self.tab2_zoom_button(1.1))
        self.tab2_canvas.bind('<Button-1>', self.tab2_step1_canvas_click)
        # Ctrl+drag to zoom
        self.tab2_canvas.bind('<Control-ButtonPress-1>',  self._tab2_drag_zoom_start)
        self.tab2_canvas.bind('<Control-B1-Motion>',      self._tab2_drag_zoom_motion)

        # Placeholder label when no image loaded
        self._img_placeholder = tk.Label(self.tab2_canvas,
            text='\nLoad Image to begin',
            bg='#181d22', fg='#3e4e5e',
            font=(self.FONT, 14), justify='center')
        self._img_placeholder.place(relx=0.5, rely=0.5, anchor='center')

        # Right: parameters panel
        right_panel = tk.Frame(content, bg=self.PANEL, width=320)
        right_panel.pack(side='right', fill='y')
        right_panel.pack_propagate(False)

        # Step info inside right panel
        step_info_frame = tk.Frame(right_panel, bg=self.PANEL)
        step_info_frame.pack(fill='x', padx=10, pady=(12, 4))

        self.step_name_label = tk.Label(step_info_frame, text="Step 0: Original Image",
                                        bg=self.PANEL, fg=self.HIGHLIGHT,
                                        font=(self.FONT, 11, 'bold'), wraplength=280, justify='left')
        self.step_name_label.pack(anchor='w')

        self.step_desc_label = tk.Label(step_info_frame, text="Load an image to begin",
                                        bg=self.PANEL, fg=self.FG2,
                                        font=(self.FONT, 9), wraplength=280, justify='left')
        self.step_desc_label.pack(anchor='w', pady=(4, 0))

        sep = tk.Frame(right_panel, bg=self.ACCENT, height=1)
        sep.pack(fill='x', padx=10, pady=8)

        # Parameters header
        tk.Label(right_panel, text='Parameters',
                 bg=self.PANEL, fg=self.FG,
                 font=(self.FONT, 10, 'bold')).pack(anchor='w', padx=12)

        # Scrollable params canvas
        params_outer = tk.Frame(right_panel, bg=self.PANEL)
        params_outer.pack(fill='both', expand=True, padx=6, pady=6)

        self.params_canvas = tk.Canvas(params_outer, bg=self.PANEL, highlightthickness=0)
        params_scrollbar = ttk.Scrollbar(params_outer, orient='vertical',
                                         command=self.params_canvas.yview)
        self.params_frame = tk.Frame(self.params_canvas, bg=self.PANEL)

        self.params_canvas.configure(yscrollcommand=params_scrollbar.set)
        params_scrollbar.pack(side='right', fill='y')
        self.params_canvas.pack(side='left', fill='both', expand=True)

        self.params_canvas_window = self.params_canvas.create_window(
            (0, 0), window=self.params_frame, anchor='nw')

        self.params_frame.bind('<Configure>',
                               lambda e: self.params_canvas.configure(
                                   scrollregion=self.params_canvas.bbox('all')))

        # ── Bottom navigation (Prev / Next) ─────────────────────────────
        nav_bar = tk.Frame(frame, bg=self.PANEL, height=44)
        nav_bar.pack(side='bottom', fill='x')
        nav_bar.pack_propagate(False)

        self.progress_label = tk.Label(nav_bar, text="Step 0 / 18",
                                       bg=self.PANEL, fg=self.FG2,
                                       font=(self.FONT, 10))
        self.progress_label.pack(side='left', padx=16)

        # ── Zoom controls in nav bar ─────────────────────────────────────
        zoom_frame = tk.Frame(nav_bar, bg=self.PANEL)
        zoom_frame.pack(side='left', padx=20)

        tk.Label(zoom_frame, text='Zoom:', bg=self.PANEL, fg=self.FG2,
                 font=(self.FONT, 9)).pack(side='left', padx=(0, 4))

        tk.Button(zoom_frame, text='−', width=3,
                  command=lambda: self.tab2_zoom_button(0.8),
                  bg=self.BTN_BG, fg=self.FG, relief='flat',
                  font=(self.FONT, 11, 'bold'), pady=2,
                  activebackground=self.HIGHLIGHT, cursor='hand2').pack(side='left', padx=2)

        tk.Button(zoom_frame, text='+', width=3,
                  command=lambda: self.tab2_zoom_button(1.25),
                  bg=self.BTN_BG, fg=self.FG, relief='flat',
                  font=(self.FONT, 11, 'bold'), pady=2,
                  activebackground=self.HIGHLIGHT, cursor='hand2').pack(side='left', padx=2)

        tk.Button(zoom_frame, text='Reset', width=5,
                  command=self.tab2_zoom_reset,
                  bg=self.BTN_BG, fg=self.FG, relief='flat',
                  font=(self.FONT, 9, 'bold'), pady=2,
                  activebackground=self.HIGHLIGHT, cursor='hand2').pack(side='left', padx=2)

        self.zoom_label = tk.Label(zoom_frame, text='100%', bg=self.PANEL, fg=self.FG2,
                                   font=(self.FONT, 9), width=5)
        self.zoom_label.pack(side='left', padx=(4, 0))

        self.next_button = tk.Button(nav_bar, text='Next  ›',
                                     command=self.tab2_next_step,
                                     bg=self.HIGHLIGHT, fg='#ffffff', relief='flat',
                                     font=(self.FONT, 10, 'bold'), padx=14, pady=6,
                                     activebackground=self.BTN_ACT, cursor='hand2',
                                     state='disabled')
        self.next_button.pack(side='right', padx=10, pady=6)

        self.prev_button = tk.Button(nav_bar, text='‹  Previous',
                                     command=self.tab2_previous_step,
                                     bg=self.BTN_BG, fg=self.FG, relief='flat',
                                     font=(self.FONT, 10, 'bold'), padx=14, pady=6,
                                     activebackground=self.HIGHLIGHT, cursor='hand2',
                                     state='disabled')
        self.prev_button.pack(side='right', padx=4, pady=6)

        self.tab2_photo = None

    def init_tab3(self):
        """Stub   the merged tab UI is built by _init_tab_batch_3d."""
        pass  # All GUI and state initialization moved to _init_tab_batch_3d

    def create_step1_controls(self):
        """Right-panel controls for Step 1: ROI Drawing."""
        tk.Label(self.params_frame,
                 text="Draw ROI Polygon",
                 bg=self.PANEL, fg=self.HIGHLIGHT,
                 font=(self.FONT, 10, 'bold')).pack(anchor='w', pady=(8, 4))

        tk.Label(self.params_frame,
                 text="1. Click on the image to place polygon points.\n"
                      "2. Point 1 is shown as a gold circle.\n"
                      "3. Click near point 1 to close the polygon.\n"
                      "4. Coordinates are auto-saved next to your image.\n"
                      "5. Click Next to run Steps 2-20.",
                 bg=self.PANEL, fg=self.FG2,
                 font=(self.FONT, 9), wraplength=280, justify='left').pack(anchor='w', padx=4, pady=(0, 12))

        tk.Frame(self.params_frame, bg=self.ACCENT, height=1).pack(fill='x', pady=6)

        # Points counter
        n = len(self.step1_polygon_points)
        status = "Closed" if self.step1_polygon_closed else f"{n} point(s) placed"
        self._step1_count_lbl = tk.Label(self.params_frame,
                 text=f"Status: {status}",
                 bg=self.PANEL, fg=self.FG,
                 font=(self.FONT, 9, 'bold')).pack(anchor='w', padx=4, pady=(0, 8))

        tk.Button(self.params_frame,
                  text="Clear Points",
                  command=self.tab2_step1_clear_points,
                  bg=self.BTN_BG, fg=self.FG, relief='flat',
                  font=(self.FONT, 9, 'bold'), padx=10, pady=4,
                  activebackground=self.HIGHLIGHT, cursor='hand2').pack(anchor='w', padx=4)

    def create_step2_controls(self):
        """Create controls for Step 2: Rotate / Flip"""
        skip_var = tk.BooleanVar(value=not self.params['step_2_rotate_flip']['enabled'])
        ttk.Checkbutton(self.params_frame, text="Skip this step",
                       variable=skip_var,
                       command=lambda: self.toggle_step_skip('step_2_rotate_flip', skip_var)).pack(anchor='w', pady=5)

        ttk.Separator(self.params_frame, orient='horizontal').pack(fill='x', pady=10)

        # Rotation angle
        ttk.Label(self.params_frame, text="Rotation Angle (°):").pack(anchor='w', pady=(5, 2))
        rot_frame = ttk.Frame(self.params_frame)
        rot_frame.pack(fill='x', pady=2)

        rot_var = tk.IntVar(value=self.params['step_2_rotate_flip']['rotate'])
        rot_scale = ttk.Scale(rot_frame, from_=-180, to=180, orient='horizontal',
                              variable=rot_var,
                              command=lambda v: self.update_step2_rotate(rot_var))
        rot_scale.pack(side='left', fill='x', expand=True, padx=(0, 5))
        rot_spinbox = ttk.Spinbox(rot_frame, from_=-180, to=180, textvariable=rot_var,
                                  width=6, command=lambda: self.update_step2_rotate(rot_var))
        rot_spinbox.pack(side='right')
        rot_spinbox.bind('<Return>', lambda e: self.update_step2_rotate(rot_var))
        rot_spinbox.bind('<FocusOut>', lambda e: self.update_step2_rotate(rot_var))

        ttk.Separator(self.params_frame, orient='horizontal').pack(fill='x', pady=10)

        # Flip horizontal
        flip_h_var = tk.BooleanVar(value=self.params['step_2_rotate_flip']['flip_h'])
        ttk.Checkbutton(self.params_frame, text="Flip Horizontal (left ↔ right)",
                        variable=flip_h_var,
                        command=lambda: self.update_step2_flip(flip_h_var, None)).pack(anchor='w', pady=3)

        # Flip vertical
        flip_v_var = tk.BooleanVar(value=self.params['step_2_rotate_flip']['flip_v'])
        ttk.Checkbutton(self.params_frame, text="Flip Vertical (top ↔ bottom)",
                        variable=flip_v_var,
                        command=lambda: self.update_step2_flip(None, flip_v_var)).pack(anchor='w', pady=3)

        self.param_widgets = {'rot_var': rot_var, 'flip_h_var': flip_h_var, 'flip_v_var': flip_v_var}

    def create_step3_controls(self):
        """Create controls for Step 3: Grayscale Conversion"""
        skip_var = tk.BooleanVar(value=not self.params['step_3_grayscale']['enabled'])
        ttk.Checkbutton(self.params_frame, text="Skip this step",
                       variable=skip_var,
                       command=lambda: self.toggle_step_skip('step_3_grayscale', skip_var)).pack(anchor='w', pady=5)

        ttk.Label(self.params_frame, text="Note: Skipping shows RGB but processes grayscale internally.",
                 wraplength=280, font=(self.FONT, 8)).pack(anchor='w', pady=10)

    def create_step4_controls(self):
        """Create controls for Step 4: Sobel Gradient"""
        skip_var = tk.BooleanVar(value=not self.params['step_4_sobel']['enabled'])
        ttk.Checkbutton(self.params_frame, text="Skip this step",
                       variable=skip_var,
                       command=lambda: self.toggle_step_skip('step_4_sobel', skip_var)).pack(anchor='w', pady=5)

        ttk.Label(self.params_frame, text="Note: Sobel computes image gradient as elevation map for watershed. High gradients form barriers between regions.",
                 wraplength=280, font=(self.FONT, 8)).pack(anchor='w', pady=10)

    # ================================================================
    # Steps 5-10 (NEW): PBF-engine defect conditioning controls.
    # Small shared helpers keep these six near-identical parameter pages
    # consistent with each other and with the rest of the wizard's
    # existing Scale+Spinbox widget style (see e.g. create_step12_controls
    # above), without duplicating the same ~15 lines six times over.
    # ================================================================

    def _pbf_skip_checkbox(self, step_key, note_text=None):
        skip_var = tk.BooleanVar(value=not self.params[step_key]['enabled'])
        ttk.Checkbutton(self.params_frame, text="Skip this step",
                        variable=skip_var,
                        command=lambda: self.toggle_step_skip(step_key, skip_var)).pack(anchor='w', pady=5)
        ttk.Separator(self.params_frame, orient='horizontal').pack(fill='x', pady=10)
        if note_text:
            ttk.Label(self.params_frame, text=note_text, wraplength=280,
                      font=(self.FONT, 8)).pack(anchor='w', pady=(0, 10))

    def _pbf_slider_row(self, label, step_key, param_key, lo, hi, increment=None, is_int=False):
        ttk.Label(self.params_frame, text=label + ":").pack(anchor='w', pady=(8, 2))
        row = ttk.Frame(self.params_frame)
        row.pack(fill='x', pady=2)
        current = self.params[step_key][param_key]
        var = tk.IntVar(value=current) if is_int else tk.DoubleVar(value=current)
        incr = increment if increment is not None else (1 if is_int else 0.1)

        def _commit(*_args):
            self._update_pbf_param(step_key, param_key, var, is_int, lo, hi)

        ttk.Scale(row, from_=lo, to=hi, orient='horizontal', variable=var,
                  command=lambda v: _commit()).pack(side='left', fill='x', expand=True, padx=(0, 5))
        sb = ttk.Spinbox(row, from_=lo, to=hi, increment=incr, textvariable=var, width=7,
                          command=_commit)
        sb.pack(side='right')
        sb.bind('<Return>', _commit)
        sb.bind('<FocusOut>', _commit)
        return var

    def _update_pbf_param(self, step_key, param_key, var, is_int, lo, hi):
        try:
            value = int(round(float(var.get()))) if is_int else float(var.get())
            value = max(lo, min(hi, value))
            var.set(value)
            self.params[step_key][param_key] = value
            self.process_all_steps()
            self.display_current_step()
        except (ValueError, tk.TclError):
            var.set(self.params[step_key][param_key])

    def create_step5_pbf_illum_controls(self):
        """Create controls for Step 5 (NEW): PBF Illumination & Denoise"""
        self._pbf_skip_checkbox(
            'step_5_pbf_illum',
            "Note: Large-sigma background estimate flattens uneven illumination/powder-tone; "
            "bilateral filter then denoises while preserving edges. Feeds the image used from "
            "Step 11 onward.")
        self._pbf_slider_row("Background Sigma", 'step_5_pbf_illum', 'bg_sigma', 0.5, 200.0)
        self._pbf_slider_row("Bilateral Filter Diameter", 'step_5_pbf_illum', 'bilat_d', 1, 25, is_int=True)
        self._pbf_slider_row("Bilateral Sigma Color", 'step_5_pbf_illum', 'bilat_sc', 1.0, 200.0)
        self._pbf_slider_row("Bilateral Sigma Space", 'step_5_pbf_illum', 'bilat_ss', 1.0, 200.0)

    def create_step6_pbf_dog_controls(self):
        """Create controls for Step 6 (NEW): PBF Multi-Scale DoG"""
        self._pbf_skip_checkbox(
            'step_6_pbf_dog',
            "Note: Difference-of-Gaussians band-pass filters at a fine and a coarse spatial "
            "scale, tuned for minute vs. mid-sized defects respectively.")
        self._pbf_slider_row("Fine Sigma 1", 'step_6_pbf_dog', 'fine_sigma1', 0.1, 10.0)
        self._pbf_slider_row("Fine Sigma 2", 'step_6_pbf_dog', 'fine_sigma2', 0.1, 20.0)
        self._pbf_slider_row("Coarse Sigma 1", 'step_6_pbf_dog', 'coarse_sigma1', 0.1, 20.0)
        self._pbf_slider_row("Coarse Sigma 2", 'step_6_pbf_dog', 'coarse_sigma2', 0.1, 40.0)
        self._pbf_slider_row("Opening-by-Reconstruction Radius", 'step_6_pbf_dog', 'recon_radius', 0, 10, is_int=True)

    def create_step7_pbf_sensitivity_controls(self):
        """Create controls for Step 7 (NEW): PBF Sensitivity & Watershed"""
        self._pbf_skip_checkbox(
            'step_7_pbf_sensitivity',
            "Note: Adaptive (image-driven) noise thresholds per band, minimum component area "
            "filters, and the watershed marker separation / compactness used to split touching "
            "candidates.")
        self._pbf_slider_row("Noise K (Fine)", 'step_7_pbf_sensitivity', 'noise_k_fine', 0.5, 10.0)
        self._pbf_slider_row("Noise K (Coarse)", 'step_7_pbf_sensitivity', 'noise_k_coarse', 0.5, 10.0)
        self._pbf_slider_row("Min Component Area (Fine)", 'step_7_pbf_sensitivity',
                              'min_component_area_fine', 0, 200, is_int=True)
        self._pbf_slider_row("Min Component Area (Coarse)", 'step_7_pbf_sensitivity',
                              'min_component_area_coarse', 0, 500, is_int=True)
        self._pbf_slider_row("Peak Marker Min Distance", 'step_7_pbf_sensitivity',
                              'local_max_min_dist', 1, 30, is_int=True)
        self._pbf_slider_row("Watershed Compactness", 'step_7_pbf_sensitivity', 'compactness', 0.0, 1.0)

    def create_step8_pbf_shape_controls(self):
        """Create controls for Step 8 (NEW): PBF Defect Shape Filtering"""
        self._pbf_skip_checkbox(
            'step_8_pbf_shape',
            "Note: Area / circularity / solidity / aspect-ratio / convexity discriminator "
            "applied to each watershed-segmented candidate region.")
        self._pbf_slider_row("Min Area", 'step_8_pbf_shape', 'min_area', 0, 2000, is_int=True)
        self._pbf_slider_row("Max Area", 'step_8_pbf_shape', 'max_area', 1000, 50000, is_int=True)
        self._pbf_slider_row("Min Circularity", 'step_8_pbf_shape', 'min_circularity', 0.0, 1.0)
        self._pbf_slider_row("Min Solidity", 'step_8_pbf_shape', 'min_solidity', 0.0, 1.0)
        self._pbf_slider_row("Max Aspect Ratio", 'step_8_pbf_shape', 'max_aspect_ratio', 1.0, 20.0)
        self._pbf_slider_row("Min Convexity", 'step_8_pbf_shape', 'min_convexity', 0.0, 1.0)

    def create_step9_pbf_extent_controls(self):
        """Create controls for Step 9 (NEW): PBF Full-Extent Band & Continuity"""
        self._pbf_skip_checkbox(
            'step_9_pbf_extent',
            "Note: h-dome full-extent band catches large, low-contrast defects that a band-pass "
            "DoG filter misses; morphological closing keeps contours continuous.")
        self._pbf_slider_row("Close Radius (Fine)", 'step_9_pbf_extent', 'close_radius_fine', 0, 10, is_int=True)
        self._pbf_slider_row("Close Radius (Coarse)", 'step_9_pbf_extent', 'close_radius_coarse', 0, 10, is_int=True)
        self._pbf_slider_row("Close Radius (Extent)", 'step_9_pbf_extent', 'close_radius_extent', 0, 10, is_int=True)
        self._pbf_slider_row("Extent Depth K", 'step_9_pbf_extent', 'extent_k', 0.5, 10.0)
        self._pbf_slider_row("Min Component Area (Extent)", 'step_9_pbf_extent',
                              'min_component_area_extent', 0, 1000, is_int=True)
        self._pbf_slider_row("Peak Marker Min Distance (Extent)", 'step_9_pbf_extent',
                              'local_max_min_dist_extent', 1, 50, is_int=True)

    def create_step10_pbf_rescue_controls(self):
        """Create controls for Step 10 (NEW): PBF Minute-Defect Rescue"""
        self._pbf_skip_checkbox(
            'step_10_pbf_rescue',
            "Note: Skipping this step truly disables minute-defect rescue in the PBF engine "
            "itself (not just a display toggle) -- sub-threshold candidates are validated by "
            "local-contrast z-score instead of being discarded outright.")
        self._pbf_slider_row("Local Contrast Ring (px)", 'step_10_pbf_rescue', 'micro_rescue_ring_px',
                              1, 30, is_int=True)
        self._pbf_slider_row("Min Z-Score", 'step_10_pbf_rescue', 'micro_rescue_min_z', 0.5, 10.0)
        self._pbf_slider_row("Max Rescue Seed Area", 'step_10_pbf_rescue', 'micro_rescue_max_area',
                              1, 500, is_int=True)

    def create_step11_controls(self):
        """Create controls for Step 11: Histogram Markers"""
        skip_var = tk.BooleanVar(value=not self.params['step_11_markers']['enabled'])
        ttk.Checkbutton(self.params_frame, text="Skip this step",
                       variable=skip_var,
                       command=lambda: self.toggle_step_skip('step_11_markers', skip_var)).pack(anchor='w', pady=5)

        ttk.Separator(self.params_frame, orient='horizontal').pack(fill='x', pady=10)

        # Low threshold
        ttk.Label(self.params_frame, text="Low Threshold (Background):").pack(anchor='w', pady=(5, 2))
        low_frame = ttk.Frame(self.params_frame)
        low_frame.pack(fill='x', pady=2)
        low_var = tk.IntVar(value=self.params['step_11_markers']['low_threshold'])
        ttk.Scale(low_frame, from_=0, to=255, orient='horizontal', variable=low_var,
                  command=lambda v: self.update_step11_markers(low_var, None)).pack(side='left', fill='x', expand=True, padx=(0, 5))
        low_spinbox = ttk.Spinbox(low_frame, from_=0, to=255, textvariable=low_var,
                                  width=6, command=lambda: self.update_step11_markers(low_var, None))
        low_spinbox.pack(side='right')
        low_spinbox.bind('<Return>', lambda e: self.update_step11_markers(low_var, None))
        low_spinbox.bind('<FocusOut>', lambda e: self.update_step11_markers(low_var, None))

        # High threshold
        ttk.Label(self.params_frame, text="High Threshold (Foreground):").pack(anchor='w', pady=(10, 2))
        high_frame = ttk.Frame(self.params_frame)
        high_frame.pack(fill='x', pady=2)
        high_var = tk.IntVar(value=self.params['step_11_markers']['high_threshold'])
        ttk.Scale(high_frame, from_=0, to=255, orient='horizontal', variable=high_var,
                  command=lambda v: self.update_step11_markers(None, high_var)).pack(side='left', fill='x', expand=True, padx=(0, 5))
        high_spinbox = ttk.Spinbox(high_frame, from_=0, to=255, textvariable=high_var,
                                   width=6, command=lambda: self.update_step11_markers(None, high_var))
        high_spinbox.pack(side='right')
        high_spinbox.bind('<Return>', lambda e: self.update_step11_markers(None, high_var))
        high_spinbox.bind('<FocusOut>', lambda e: self.update_step11_markers(None, high_var))
        self.param_widgets = {'low_var': low_var, 'high_var': high_var}

        ttk.Label(self.params_frame,
                  text="Note: markers are built as one connected-component id per "
                       "below-low-threshold (dark) or above-high-threshold (bright) blob, so "
                       "each defect region grows as a single, fully segmented watershed seed.",
                 wraplength=280, font=(self.FONT, 8)).pack(anchor='w', pady=10)

    def create_step12_controls(self):
        """Create controls for Step 12: Watershed"""
        skip_var = tk.BooleanVar(value=not self.params['step_12_watershed']['enabled'])
        ttk.Checkbutton(self.params_frame, text="Skip this step",
                       variable=skip_var,
                       command=lambda: self.toggle_step_skip('step_12_watershed', skip_var)).pack(anchor='w', pady=5)

        ttk.Label(self.params_frame, text="Note: Watershed floods elevation map from markers to segment regions.",
                 wraplength=280, font=(self.FONT, 8)).pack(anchor='w', pady=10)

    def create_step13_controls(self):
        """Create controls for Step 13: Morphological Close"""
        skip_var = tk.BooleanVar(value=not self.params['step_13_morph_close']['enabled'])
        ttk.Checkbutton(self.params_frame, text="Skip this step",
                       variable=skip_var,
                       command=lambda: self.toggle_step_skip('step_13_morph_close', skip_var)).pack(anchor='w', pady=5)

        ttk.Separator(self.params_frame, orient='horizontal').pack(fill='x', pady=10)
        ttk.Label(self.params_frame, text="Number of Iterations:").pack(anchor='w', pady=(5, 2))
        iter_frame = ttk.Frame(self.params_frame)
        iter_frame.pack(fill='x', pady=2)
        iter_var = tk.IntVar(value=self.params['step_13_morph_close']['iterations'])
        ttk.Scale(iter_frame, from_=1, to=10, orient='horizontal', variable=iter_var,
                  command=lambda v: self.update_step13_iterations(iter_var)).pack(side='left', fill='x', expand=True, padx=(0, 5))
        iter_spinbox = ttk.Spinbox(iter_frame, from_=1, to=10, textvariable=iter_var,
                                   width=6, command=lambda: self.update_step13_iterations(iter_var))
        iter_spinbox.pack(side='right')
        iter_spinbox.bind('<Return>', lambda e: self.update_step13_iterations(iter_var))
        iter_spinbox.bind('<FocusOut>', lambda e: self.update_step13_iterations(iter_var))
        self.param_widgets = {'iter_var': iter_var}

    def create_step14_controls(self):
        """Create controls for Step 14: Morphological Open"""
        skip_var = tk.BooleanVar(value=not self.params['step_14_morph_open']['enabled'])
        ttk.Checkbutton(self.params_frame, text="Skip this step",
                       variable=skip_var,
                       command=lambda: self.toggle_step_skip('step_14_morph_open', skip_var)).pack(anchor='w', pady=5)

        ttk.Separator(self.params_frame, orient='horizontal').pack(fill='x', pady=10)
        ttk.Label(self.params_frame, text="Number of Iterations:").pack(anchor='w', pady=(5, 2))
        iter_frame = ttk.Frame(self.params_frame)
        iter_frame.pack(fill='x', pady=2)
        iter_var = tk.IntVar(value=self.params['step_14_morph_open']['iterations'])
        ttk.Scale(iter_frame, from_=1, to=10, orient='horizontal', variable=iter_var,
                  command=lambda v: self.update_step14_iterations(iter_var)).pack(side='left', fill='x', expand=True, padx=(0, 5))
        iter_spinbox = ttk.Spinbox(iter_frame, from_=1, to=10, textvariable=iter_var,
                                   width=6, command=lambda: self.update_step14_iterations(iter_var))
        iter_spinbox.pack(side='right')
        iter_spinbox.bind('<Return>', lambda e: self.update_step14_iterations(iter_var))
        iter_spinbox.bind('<FocusOut>', lambda e: self.update_step14_iterations(iter_var))
        self.param_widgets = {'iter_var': iter_var}

    def create_step15_controls(self):
        """Create controls for Step 15: Fill Holes"""
        skip_var = tk.BooleanVar(value=not self.params['step_15_fillholes']['enabled'])
        ttk.Checkbutton(self.params_frame, text="Skip this step",
                       variable=skip_var,
                       command=lambda: self.toggle_step_skip('step_15_fillholes', skip_var)).pack(anchor='w', pady=5)

        ttk.Label(self.params_frame, text="Note: Fills small holes inside detected regions.",
                 wraplength=280, font=(self.FONT, 8)).pack(anchor='w', pady=10)

    def create_step16_controls(self):
        """Create controls for Step 16: Labeling"""
        skip_var = tk.BooleanVar(value=not self.params['step_16_labeling']['enabled'])
        ttk.Checkbutton(self.params_frame, text="Skip this step",
                       variable=skip_var,
                       command=lambda: self.toggle_step_skip('step_16_labeling', skip_var)).pack(anchor='w', pady=5)

        ttk.Separator(self.params_frame, orient='horizontal').pack(fill='x', pady=10)
        ttk.Label(self.params_frame, text="Minimum Size (pixels):").pack(anchor='w', pady=(5, 2))
        size_frame = ttk.Frame(self.params_frame)
        size_frame.pack(fill='x', pady=2)
        size_var = tk.IntVar(value=self.params['step_16_labeling']['min_size'])
        ttk.Scale(size_frame, from_=0, to=200, orient='horizontal', variable=size_var,
                  command=lambda v: self.update_step16_size(size_var)).pack(side='left', fill='x', expand=True, padx=(0, 5))
        size_spinbox = ttk.Spinbox(size_frame, from_=0, to=200, textvariable=size_var,
                                   width=6, command=lambda: self.update_step16_size(size_var))
        size_spinbox.pack(side='right')
        size_spinbox.bind('<Return>', lambda e: self.update_step16_size(size_var))
        size_spinbox.bind('<FocusOut>', lambda e: self.update_step16_size(size_var))
        self.param_widgets = {'size_var': size_var}

    def create_step17_controls(self):
        """Create controls for Step 17: Final Result"""
        ttk.Label(self.params_frame, text="Minimum Area (pixels):").pack(anchor='w', pady=(5, 2))
        min_area_frame = ttk.Frame(self.params_frame)
        min_area_frame.pack(fill='x', pady=2)
        min_area_var = tk.IntVar(value=self.params['step_17_final']['min_area'])
        ttk.Scale(min_area_frame, from_=0, to=1500, orient='horizontal', variable=min_area_var,
                  command=lambda v: self.update_step17_min_area(min_area_var)).pack(side='left', fill='x', expand=True, padx=(0, 5))
        min_spinbox = ttk.Spinbox(min_area_frame, from_=0, to=1500, textvariable=min_area_var,
                                  width=6, command=lambda: self.update_step17_min_area(min_area_var))
        min_spinbox.pack(side='right')
        min_spinbox.bind('<Return>', lambda e: self.update_step17_min_area(min_area_var))
        min_spinbox.bind('<FocusOut>', lambda e: self.update_step17_min_area(min_area_var))

        ttk.Label(self.params_frame, text="Maximum Area (pixels):").pack(anchor='w', pady=(10, 2))
        max_area_frame = ttk.Frame(self.params_frame)
        max_area_frame.pack(fill='x', pady=2)
        max_area_var = tk.IntVar(value=self.params['step_17_final']['max_area'])
        ttk.Scale(max_area_frame, from_=1000, to=50000, orient='horizontal', variable=max_area_var,
                  command=lambda v: self.update_step17_max_area(max_area_var)).pack(side='left', fill='x', expand=True, padx=(0, 5))
        max_spinbox = ttk.Spinbox(max_area_frame, from_=1000, to=50000, textvariable=max_area_var,
                                  width=6, command=lambda: self.update_step17_max_area(max_area_var))
        max_spinbox.pack(side='right')
        max_spinbox.bind('<Return>', lambda e: self.update_step17_max_area(max_area_var))
        max_spinbox.bind('<FocusOut>', lambda e: self.update_step17_max_area(max_area_var))
        ttk.Label(self.params_frame, text="Note: Segments are colored red.",
                 wraplength=280, font=(self.FONT, 8)).pack(anchor='w', pady=10)
        self.param_widgets = {'min_area_var': min_area_var, 'max_area_var': max_area_var}

    def create_step18_controls(self):
        """Create controls for Step 18: Perspective Warp"""
        skip_var = tk.BooleanVar(value=not self.params['step_18_perspective']['enabled'])
        ttk.Checkbutton(self.params_frame, text="Skip this step",
                        variable=skip_var,
                        command=lambda: self.toggle_step_skip('step_18_perspective', skip_var)).pack(anchor='w', pady=5)

        ttk.Separator(self.params_frame, orient='horizontal').pack(fill='x', pady=10)
        ttk.Label(self.params_frame,
                  text="Perspective warp rectifies the ROI polygon to a top-down view.\n\n"
                       "The 4 extreme corners of your ROI polygon (top-left, top-right, "
                       "bottom-right, bottom-left) are used as the source quad and mapped "
                       "to a fixed 272 × 272 px output (representing the 272 mm × 272 mm "
                       "panel at 10 mm height).",
                  wraplength=280, font=(self.FONT, 8)).pack(anchor='w', pady=5)


    def update_parameter_controls(self):
        """Update parameter controls based on current step"""
        # Clear existing controls
        for widget in self.params_frame.winfo_children():
            widget.destroy()

        step = self.current_step

        if step == 1:   # ROI Drawing
            self.create_step1_controls()
        elif step == 2:   # Rotate / Flip (NEW)
            self.create_step2_controls()
        elif step == 3:  # Grayscale
            self.create_step3_controls()
        elif step == 4:  # Sobel
            self.create_step4_controls()
        elif step == 5:  # PBF: Illumination & Denoise (NEW)
            self.create_step5_pbf_illum_controls()
        elif step == 6:  # PBF: Multi-Scale DoG (NEW)
            self.create_step6_pbf_dog_controls()
        elif step == 7:  # PBF: Sensitivity & Watershed (NEW)
            self.create_step7_pbf_sensitivity_controls()
        elif step == 8:  # PBF: Defect Shape Filtering (NEW)
            self.create_step8_pbf_shape_controls()
        elif step == 9:  # PBF: Full-Extent Band & Continuity (NEW)
            self.create_step9_pbf_extent_controls()
        elif step == 10:  # PBF: Minute-Defect Rescue (NEW)
            self.create_step10_pbf_rescue_controls()
        elif step == 11:  # Markers
            self.create_step11_controls()
        elif step == 12:  # Watershed
            self.create_step12_controls()
        elif step == 13:  # Morphological Close
            self.create_step13_controls()
        elif step == 14:  # Morphological Open
            self.create_step14_controls()
        elif step == 15:  # Fill Holes
            self.create_step15_controls()
        elif step == 16:  # Labeling
            self.create_step16_controls()
        elif step == 17:  # Final
            self.create_step17_controls()
        elif step == 18:  # Perspective Warp
            self.create_step18_controls()
        else:
            ttk.Label(self.params_frame, text="No adjustable parameters for this step.",
                     wraplength=280).pack(pady=10)

    def _jump_to_step(self, step):
        """Jump to a specific step when a pill button is clicked."""
        if step in self.step_images:
            self.current_step = step
            self.display_current_step()

    def _update_step_pills(self):
        """Highlight the currently active step pill."""
        for i, btn in self._step_pill_btns.items():
            if i == self.current_step:
                btn.configure(bg=self.HIGHLIGHT, fg='#ffffff')
            elif i in self.step_images or (i == 1 and len(self.step1_polygon_points) > 0):
                btn.configure(bg=self.ACCENT, fg=self.FG)
            else:
                btn.configure(bg=self.ACCENT, fg=self.FG2)

    def toggle_step_skip(self, step_key, skip_var):
        """Toggle skip for any step"""
        self.params[step_key]['enabled'] = not skip_var.get()
        self.process_all_steps()
        self.display_current_step()

    def tab2_previous_step(self):
        """Navigate to previous step"""
        if self.current_step > 0:
            self.current_step -= 1
            # Going back to Step 1 re-enters drawing mode (keep existing points)
            self.display_current_step()

    def tab2_next_step(self):
        """Navigate to next step"""
        # Moving from Step 1    Step 2: ROI must be drawn and closed first
        if self.current_step == 1:
            if not self.step1_polygon_closed or len(self.step1_polygon_points) < 3:
                messagebox.showwarning("Warning",
                    "Please complete the ROI polygon first.\n"
                    "Click points on the image, then click near the first point to close.")
                return
            # Run full pipeline (steps 2-18) now that ROI is confirmed
            self.process_all_steps()
            self.current_step = 2
            self.display_current_step()
            self.tab2_info_label.config(
                text="ROI confirmed. Processing complete. Navigate through steps.")
            return

        if self.current_step < 18:
            self.current_step += 1
            self.display_current_step()

    def _init_tab_reports(self):
        """Stub   Reports state initialized in _init_tab_batch_3d.
        The Reports UI itself is built on-demand inside a popup window by
        _open_reports_popup(), mirroring the existing independent 3D
        Visualise dialog, so no new tab/page is added to the application."""
        pass

