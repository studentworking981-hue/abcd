"""Popup windows: the login popup dialog and the Reports popup dialog.
Relocated verbatim from ImageAnalyzerApp in the original single-file app."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from PIL import Image, ImageTk
import cv2
import numpy as np
from scipy import ndimage as ndi
from skimage.segmentation import watershed as _skimage_watershed
from skimage.morphology import disk
import json
import math
import os
import sys
import gc
import threading
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from ..utils.fonts import _resolve_font_family, _resolve_font_mono


class DialogsMixin:
    """
    Mixin holding methods relocated verbatim from the original
    ``ImageAnalyzerApp`` god-class. It is combined with the other
    mixins in ``app.Application`` via multiple inheritance, so every
    method below still shares the same ``self`` (and therefore the
    same widgets / state) as before -- nothing about how these
    methods call each other or access ``self.*`` attributes changed.
    """

    def _open_login_popup(self):
        """Show a modal login dialog over the main window."""
        # If already logged in just switch to single tab directly
        if self._logged_in:
            self._switch_tab_direct('single')
            return

        popup = tk.Toplevel(self.root)
        popup.title("Login")
        popup.resizable(False, False)
        popup.configure(bg=self.BG)
        popup.grab_set()        # modal

        # Centre over main window
        self.root.update_idletasks()
        rx = self.root.winfo_x() + (self.root.winfo_width()  - 340) // 2
        ry = self.root.winfo_y() + (self.root.winfo_height() - 400) // 2
        popup.geometry(f"340x400+{rx}+{ry}")

        PANEL = self.PANEL; BLUE = self.HIGHLIGHT
        FG = self.FG; FG2 = self.FG2; ENTRY = self.ENTRY_BG

        card = tk.Frame(popup, bg=PANEL)
        card.place(relx=0.5, rely=0.5, anchor='center', width=300, height=360)

        tk.Label(card, text='', bg=PANEL, fg=BLUE,
                 font=(self.FONT, 32)).pack(pady=(28, 0))
        tk.Label(card, text='SINGLE IMAGE ACCESS', bg=PANEL, fg=FG,
                 font=(self.FONT, 11, 'bold')).pack()
        tk.Label(card, text='Login required', bg=PANEL, fg=FG2,
                 font=(self.FONT, 9)).pack(pady=(2, 20))

        tk.Label(card, text='Username', bg=PANEL, fg=FG2,
                 font=(self.FONT, 9), anchor='w').pack(fill='x', padx=30)
        user_var = tk.StringVar()
        user_entry = tk.Entry(card, textvariable=user_var,
                              bg=ENTRY, fg=FG, relief='flat',
                              font=(self.FONT, 11), insertbackground=FG, bd=0)
        user_entry.pack(fill='x', padx=30, ipady=7, pady=(3, 12))

        tk.Label(card, text='Password', bg=PANEL, fg=FG2,
                 font=(self.FONT, 9), anchor='w').pack(fill='x', padx=30)
        pass_var = tk.StringVar()
        pass_entry = tk.Entry(card, textvariable=pass_var, show='●',
                              bg=ENTRY, fg=FG, relief='flat',
                              font=(self.FONT, 11), insertbackground=FG, bd=0)
        pass_entry.pack(fill='x', padx=30, ipady=7, pady=(3, 6))

        err_lbl = tk.Label(card, text='', bg=PANEL, fg='#e05c5c',
                           font=(self.FONT, 9))
        err_lbl.pack(pady=(0, 10))

        def _try():
            if (user_var.get().strip() == 'admin' and
                    pass_var.get().strip() == 'admin'):
                self._logged_in = True
                popup.destroy()
                # Reveal Single Image tab button and logout button
                self._tab_buttons['single'].pack(side='left', padx=2)
                self._logout_btn.pack(side='right', padx=16, pady=10)
                self._switch_tab_direct('single')
            else:
                err_lbl.config(text='Invalid username or password.')
                pass_var.set('')

        tk.Button(card, text='Login', command=_try,
                  bg=BLUE, fg='#ffffff', relief='flat',
                  font=(self.FONT, 11, 'bold'), padx=20, pady=7,
                  activebackground=self.BTN_ACT, cursor='hand2').pack(
                  fill='x', padx=30)

        user_entry.bind('<Return>', lambda e: pass_entry.focus())
        pass_entry.bind('<Return>', lambda e: _try())
        user_entry.focus()

    def _open_reports_popup(self):
        """Reports   opens a dedicated dialog (mirrors the independent 3D
        Visualise popup pattern). Contains the exact Reports functionality
        ported from the reference implementation: select Predicted Results
        and Ground Truth folders, Generate Report (binary classification
        evaluation), and Save Excel (two-sheet workbook export)."""

        popup = tk.Toplevel(self.root)
        popup.title("Reports   Binary Classification Evaluation")
        popup.resizable(False, False)
        popup.configure(bg=self.BG)
        popup.grab_set()

        # Centre over main window
        self.root.update_idletasks()
        rx = self.root.winfo_x() + (self.root.winfo_width()  - 760) // 2
        ry = self.root.winfo_y() + (self.root.winfo_height() - 520) // 2
        popup.geometry(f"760x520+{rx}+{ry}")

        # ── Scrollable container (same pattern as final_app2 Reports tab) ──
        outer = tk.Frame(popup, bg=self.BG)
        outer.pack(fill='both', expand=True)

        _canvas = tk.Canvas(outer, bg=self.BG, highlightthickness=0)
        _vsb = ttk.Scrollbar(outer, orient='vertical', command=_canvas.yview)
        _canvas.configure(yscrollcommand=_vsb.set)
        _vsb.pack(side='right', fill='y')
        _canvas.pack(side='left', fill='both', expand=True)

        card = tk.Frame(_canvas, bg=self.PANEL, bd=0, relief='flat')
        _card_id = _canvas.create_window((0, 0), window=card, anchor='n')

        def _on_card_resize(e):
            _canvas.configure(scrollregion=_canvas.bbox('all'))

        def _on_canvas_resize(e):
            w = min(720, e.width)
            _canvas.itemconfig(_card_id, width=w)
            _canvas.coords(_card_id, e.width // 2, 0)
            card.configure(width=w)

        card.bind('<Configure>', _on_card_resize)
        _canvas.bind('<Configure>', _on_canvas_resize)

        def _on_mw(e):
            _canvas.yview_scroll(int(-1 * (e.delta / 120)), 'units')
        _canvas.bind_all('<MouseWheel>', _on_mw)

        # ── Title ────────────────────────────────────────────────────────
        tk.Label(card, text='Reports', bg=self.PANEL, fg=self.HIGHLIGHT,
                 font=(self.FONT, 18, 'bold')).pack(pady=(24, 2))
        tk.Label(card, text='Binary Classification Evaluation   Compare Predictions vs Ground Truth',
                 bg=self.PANEL, fg=self.FG2,
                 font=(self.FONT, 9)).pack(pady=(0, 6))
        tk.Frame(card, bg=self.ACCENT, height=1).pack(fill='x', padx=30, pady=10)

        # ── Helper: browse row ───────────────────────────────────────────
        def _browse_row(parent, label, var, pick_fn):
            tk.Label(parent, text=label, bg=self.PANEL, fg=self.FG2,
                     font=(self.FONT, 9, 'bold')).pack(anchor='w', padx=30)
            row = tk.Frame(parent, bg=self.PANEL)
            row.pack(fill='x', padx=30, pady=(2, 10))
            tk.Entry(row, textvariable=var, bg=self.ENTRY_BG, fg=self.FG2,
                     relief='flat', font=(self.FONT, 9), state='readonly',
                     readonlybackground=self.ENTRY_BG, bd=0
                     ).pack(side='left', fill='x', expand=True, ipady=6, padx=(0, 8))
            tk.Button(row, text='Browse', command=pick_fn,
                      bg=self.BTN_BG, fg=self.FG, relief='flat',
                      font=(self.FONT, 9, 'bold'), padx=10, pady=3,
                      activebackground=self.HIGHLIGHT, cursor='hand2').pack(side='right')

        # ── Folder inputs ────────────────────────────────────────────────
        self._rpt_pred_var = tk.StringVar(value='No folder selected')
        self._rpt_gt_var   = tk.StringVar(value='No folder selected')

        def _pick_pred():
            p = filedialog.askdirectory(
                title='Select Predicted Results Folder (contains Indicator / Non Indicator subfolders)',
                parent=popup)
            if p:
                self._rpt_pred_var.set(p)

        def _pick_gt():
            p = filedialog.askdirectory(
                title='Select Ground Truth Folder (contains Indicator / Non Indicator subfolders)',
                parent=popup)
            if p:
                self._rpt_gt_var.set(p)

        _browse_row(card, 'Predicted Results Folder', self._rpt_pred_var, _pick_pred)
        _browse_row(card, 'Ground Truth Folder',      self._rpt_gt_var,   _pick_gt)

        tk.Frame(card, bg=self.ACCENT, height=1).pack(fill='x', padx=30, pady=6)

        # ── Action buttons ───────────────────────────────────────────────
        btn_row = tk.Frame(card, bg=self.PANEL)
        btn_row.pack(pady=(8, 4))

        self._rpt_generate_btn = tk.Button(
            btn_row, text='  ▶  Generate Report',
            bg=self.HIGHLIGHT, fg='#ffffff', relief='flat',
            font=(self.FONT, 11, 'bold'), padx=22, pady=8,
            activebackground=self.BTN_ACT, cursor='hand2',
            command=self._rpt_generate)
        self._rpt_generate_btn.pack(side='left', padx=(0, 10))

        self._rpt_save_btn = tk.Button(
            btn_row, text='  Save Excel',
            bg=self.BTN_BG, fg=self.FG, relief='flat',
            font=(self.FONT, 11, 'bold'), padx=22, pady=8,
            activebackground=self.HIGHLIGHT, cursor='hand2',
            state='disabled',
            command=self._rpt_save_excel)
        self._rpt_save_btn.pack(side='left')

        tk.Frame(card, bg=self.ACCENT, height=1).pack(fill='x', padx=30, pady=(12, 6))

        # ── Status / log label ───────────────────────────────────────────
        self._rpt_status_var = tk.StringVar(value='Select both folders and click Generate Report.')
        tk.Label(card, textvariable=self._rpt_status_var,
                 bg=self.PANEL, fg=self.FG2,
                 font=(self.FONT, 9), wraplength=620, justify='left'
                 ).pack(anchor='w', padx=30, pady=(4, 24))

        close_row = tk.Frame(card, bg=self.PANEL)
        close_row.pack(pady=(0, 18))
        tk.Button(close_row, text='Close',
                  command=popup.destroy,
                  bg=self.BTN_BG, fg=self.FG, relief='flat',
                  font=(self.FONT, 10, 'bold'), padx=14, pady=7,
                  activebackground=self.HIGHLIGHT, cursor='hand2').pack()



# ── Standalone splash / intro screen shown at application startup ──────────
# (Not a Toplevel popup like the two dialogs above, but it lives here since
# the target project structure has no dedicated 'splash' module and this is
# the closest fit: a full-window, non-tab popup shown before the app proper.)

class SplashScreen:
    """Animated splash / intro screen shown before the login window."""

    def __init__(self, root):
        self.root = root
        #self.root.title("Indicator Detection System")
        self.root.title("")
        self.root.geometry("860x540")
        self.root.resizable(False, False)
        self.root.configure(bg='#0d1117')
        self.root.update_idletasks()
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        x  = (sw - 860) // 2
        y  = (sh - 540) // 2
        self.root.geometry(f"860x540+{x}+{y}")

        self.FONT = _resolve_font_family()
        self.FONT_MONO = _resolve_font_mono()


        BG     = '#0d1117'
        PANEL  = '#161b22'
        BLUE   = '#2d7dd2'
        BLUE2  = '#1a5fa8'
        CYAN   = '#58c4dd'
        FG     = '#e6edf3'
        FG2    = '#8b949e'
        ACCENT = '#21262d'

        self.canvas = tk.Canvas(self.root, width=860, height=540,
                                bg=BG, highlightthickness=0)
        self.canvas.pack(fill='both', expand=True)

        # Background grid
        for gx in range(0, 860, 40):
            self.canvas.create_line(gx, 0, gx, 540, fill='#161b22', width=1)
        for gy in range(0, 540, 40):
            self.canvas.create_line(0, gy, 860, gy, fill='#161b22', width=1)

        # Left accent bar
        self.canvas.create_rectangle(0, 0, 5, 540, fill=BLUE, outline='')

        # Org badge top-left
        self.canvas.create_text(28, 22, text='-iv \u00b7  IV',
                                fill=FG2, font=(self.FONT, 9, 'bold'), anchor='w')
        self.canvas.create_line(28, 34, 220, 34, fill=ACCENT, width=1)

        # Bottom status bar
        self.canvas.create_rectangle(0, 510, 860, 540, fill=PANEL, outline='')
        self.canvas.create_line(0, 510, 860, 510, fill=BLUE2, width=1)
        self._status_id = self.canvas.create_text(
            28, 525, text='Initialising system\u2026',
            fill=FG2, font=(self.FONT_MONO, 9), anchor='w')
        self.canvas.create_text(
            832, 525, text='v3.0  |  BUILD 2025',
            fill=FG2, font=(self.FONT_MONO, 9), anchor='e')

        # Hexagon logo
        cx, cy, r = 170, 265, 68
        import math as _math
        pts_outer = []
        for i in range(6):
            a = _math.radians(60 * i - 30)
            pts_outer += [cx + r * _math.cos(a), cy + r * _math.sin(a)]
        self.canvas.create_polygon(pts_outer, outline=BLUE, fill='#0d1a2a', width=2)
        pts_inner = []
        ri = 48
        for i in range(6):
            a = _math.radians(60 * i - 30)
            pts_inner += [cx + ri * _math.cos(a), cy + ri * _math.sin(a)]
        self.canvas.create_polygon(pts_inner, outline=CYAN, fill='#071020', width=1)
        self.canvas.create_text(cx, cy, text='\u2b21',
                                fill=BLUE, font=(self.FONT, 42))

        # Corner brackets around hex
        br_off, br_len, br_w = 84, 18, 2
        for bx, by, xs, ys in [(cx - br_off, cy - br_off, 1, 1),
                                (cx + br_off, cy - br_off, -1, 1),
                                (cx + br_off, cy + br_off, -1, -1),
                                (cx - br_off, cy + br_off, 1, -1)]:
            self.canvas.create_line(bx, by, bx + xs * br_len, by,
                                    fill=CYAN, width=br_w)
            self.canvas.create_line(bx, by, bx, by + ys * br_len,
                                    fill=CYAN, width=br_w)

        # Title block
        self.canvas.create_text(278, 222,
                                text='INDICATOR DETECTION SYSTEM',
                                fill=FG, font=(self.FONT, 22, 'bold'), anchor='w')
        self.canvas.create_text(278, 254,
                                text='Advanced Image Analysis Pipeline',
                                fill=CYAN, font=(self.FONT, 11), anchor='w')
        self.canvas.create_line(278, 272, 835, 272, fill=BLUE2, width=1)

        # Spec rows
        specs = [
            ('MODULE',   'Watershed Segmentation  \u00b7  Scikit-Image'),
            ('PIPELINE', '11-Step Analysis  \u00b7  ROI + Batch Processing'),
            ('OUTPUT',   'Indicator Classification  \u00b7  Perspective Warp'),
            ('PLATFORM', 'Python  \u00b7  OpenCV  \u00b7  Tkinter  \u00b7  NumPy'),
        ]
        sy = 292
        for lbl, val in specs:
            self.canvas.create_text(278, sy, text=lbl,
                                    fill=BLUE, font=(self.FONT_MONO, 8, 'bold'), anchor='w')
            self.canvas.create_text(368, sy, text=val,
                                    fill=FG2, font=(self.FONT_MONO, 8), anchor='w')
            sy += 18
       

        # Progress bar
        bx1, by1, bx2, by2 = 278, 410, 835, 424
        self.canvas.create_rectangle(bx1, by1, bx2, by2,
                                     fill=ACCENT, outline=BLUE2, width=1)
        self._bar = self.canvas.create_rectangle(
            bx1 + 1, by1 + 1, bx1 + 1, by2 - 1, fill=BLUE, outline='')
        self._bar_x1    = bx1 + 1
        self._bar_width = (bx2 - 1) - (bx1 + 1)
        self._pct_id = self.canvas.create_text(
            bx1, by1 - 10, text='0%',
            fill=CYAN, font=(self.FONT_MONO, 8, 'bold'), anchor='w')

        # Animation state
        self._progress = 0
        self._msg_idx  = 0
        self._step_msgs = [
            (0,   'Initialising system\u2026'),
            (12,  'Loading image processing modules\u2026'),
            (28,  'Configuring watershed pipeline\u2026'),
            (45,  'Preparing ROI segmentation engine\u2026'),
            (62,  'Loading batch processing routines\u2026'),
            (78,  'Calibrating indicator classifier\u2026'),
            (90,  'Finalising perspective warp module\u2026'),
            (100, 'System ready.'),
        ]
        self._animate()

    def _animate(self):
        if self._progress >= 100:
            self._finish()
            return
        self._progress = min(self._progress + 1, 100)
        pct = self._progress
        new_right = self._bar_x1 + int(self._bar_width * pct / 100)
        coords = self.canvas.coords(self._bar)
        self.canvas.coords(self._bar, coords[0], coords[1], new_right, coords[3])
        self.canvas.itemconfig(self._pct_id, text=f'{pct}%')
        while (self._msg_idx < len(self._step_msgs) - 1 and
               pct >= self._step_msgs[self._msg_idx + 1][0]):
            self._msg_idx += 1
        self.canvas.itemconfig(self._status_id,
                               text=self._step_msgs[self._msg_idx][1])
        delay = 18 if pct < 95 else 40
        self.root.after(delay, self._animate)

    def _finish(self):
        BLUE  = '#2d7dd2'
        BLUE2 = '#1a5fa8'
        FG    = '#e6edf3'
        btn_frame = tk.Frame(self.root, bg='#161b22', bd=0)
        self.canvas.create_window(557, 460, window=btn_frame)
        tk.Button(btn_frame,
                  text='  ENTER SYSTEM  \u203a',
                  command=self._open_login,
                  bg=BLUE, fg=FG, relief='flat',
                  font=(self.FONT, 11, 'bold'),
                  padx=28, pady=8,
                  activebackground=BLUE2,
                  activeforeground='#ffffff',
                  cursor='hand2', bd=0).pack()
        self.root.bind('<Return>', lambda e: self._open_login())

    def _open_login(self):
        from ..main import _launch_login
        self.root.destroy()
        _launch_login()
