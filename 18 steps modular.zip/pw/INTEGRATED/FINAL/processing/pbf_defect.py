"""
Powder Bed Fusion (PBF) Metal AM -- Powder-Bed Surface Defect Inspector v3
============================================================================
Pure image-processing engine -- NO GUI imports here on purpose (Problem 10:
single-image and batch modes both call `run_pipeline()` in this file, so
there is exactly one implementation to keep in sync; the GUI module never
duplicates any detection logic).

WHAT THIS VERSION CHANGES RELATIVE TO v2 (GAUSSIAN_DIFFERENCE.py), AND WHY
---------------------------------------------------------------------------
v2 already fixed dark-defect detection (dual-polarity DoG) and cut down
background noise. Its remaining failure mode, confirmed by reproducing it on
a synthetic test blob before writing any fix (see VALIDATION.md): a large,
spatially HOMOGENEOUS bright or dark defect only had its rim detected
(~13% of its true area survived to the final mask), because a
Difference-of-Gaussians is a *band-pass* filter -- it only responds where
intensity CHANGES within a chosen spatial scale. A big flat blob has almost
no internal intensity change, so only the transition at its edge crosses the
DoG passband; the homogeneous interior produces near-zero response and is
lost. That is Problems 1-3 and 7 in one sentence, and it is a structural
property of band-pass filtering, not a mistuned parameter -- no amount of
slider-tweaking on the existing fine/coarse DoG bands fixes it.

FIX (Problems 1, 2, 3, 7): a third detection band per polarity using the
h-dome / h-minima transform (`hdome_response`), i.e. morphological
REGIONAL-MAXIMA / REGIONAL-MINIMA extraction via reconstruction. Unlike DoG,
this responds to the FULL extent of any connected region that sits some
adaptive depth above (bright) or below (dark) its local surroundings,
regardless of how large or how flat its interior is -- exactly the missing
capability. It is fused into the existing dual-polarity loop as a third
band alongside "fine" and "coarse", through the exact same
threshold -> component-filter -> watershed -> shape-filter pipeline
(`_detect_band`) already used by the other two bands, so the architecture
and every existing tunable (Tab 3/4 sliders) is unchanged for fine/coarse.

Also for Problems 2/7: a small morphological closing + hole-fill step
(`close_and_fill`) runs on every band's binary mask, right after the
existing area filter and before the watershed markers are built. This turns
an almost-closed ring into a solid disc and removes stray internal holes,
independent of the extent-band fix -- it helps the fine/coarse bands stay
continuous too.

FIX (Problem 4, minute defects vs texture) -- `local_contrast_rescue`:
a single image-wide statistical cutoff (even a robust one) applies the same
sensitivity everywhere. A genuine tiny defect sitting in a locally quiet
patch of powder should be much easier to confirm than a texture bump in a
locally busy patch, but a global mean+k*std threshold cannot see that
difference. This function re-examines each already-detected small blob (and,
separately, a relaxed lower-threshold candidate set) against its OWN local
surrounding annulus and keeps only the ones that are statistically extreme
relative to their immediate neighbourhood. It can only REMOVE candidates
that fail the local test -- never invent new ones out of nothing -- so it
cannot raise the pipeline's false-positive rate above what the existing
detectors already proposed. Large components are left untouched (this pass
targets only the borderline-tiny case).

FIX (Problem 8, no fixed thresholds): every new cutoff introduced above is
still image-derived. `extent_k` and `micro_rescue_min_z` are z-score-style
sensitivity dials (same spirit as the existing `noise_k_fine/coarse`), not
hardcoded intensity values -- the actual numbers plugged in are always
`local_or_global_mean +/- k * local_or_global_std`, recomputed per image (or
per neighbourhood). `close_and_fill`'s radius is a structural/morphological
parameter (like the pre-existing `recon_radius`), not an intensity cutoff.

FIX (Problem 9, ROI): `run_pipeline()` accepts an optional `roi_polygon` --
a list of (x_frac, y_frac) points, each normalized to [0, 1] relative to
whatever image they were drawn on (see `polygon_to_mask`). Normalized
coordinates mean the identical polygon is valid at any resolution -- the
downsized live preview, a full-resolution export, or any other frame in a
batch folder that shares the same camera framing -- with no separate
bookkeeping of "what size was this drawn on". When provided, the polygon
becomes the processing mask (everything outside it is excluded from
detection) instead of the previous rectangular auto-crop, so genuine
defects near the plate border are no longer discarded by a rigid
rectangle. This is masking rather than a hard crop specifically so that
the SAME array coordinates are used throughout the pipeline and in the
returned contours -- simpler and safer than rebasing coordinates through a
crop/uncrop round trip. (For very large frames with a small ROI, cropping
to the polygon's bounding box first would save some compute; left as a
documented possible follow-up rather than risking a coordinate-mapping bug
in code that could not be interactively tested in this environment -- see
the accompanying CHANGES.md.)

VALIDATION
----------
Because the only sample provided was an already-annotated OUTPUT image
(with the old detector's red overlay baked in, not a raw re-processable
input), the fixes below were validated on synthetic test scenes built to
reproduce the reported symptom exactly: a large homogeneous bright ellipse,
a large homogeneous dark ellipse, several minute bright/dark point defects,
and randomized small-blob "powder texture" clutter meant to trip up naive
sensitivity increases. Results (full numbers/methodology in VALIDATION.md):

                                    old (v2)      new (v3)
    large bright blob coverage       13%           83-90%
    large dark blob coverage         22%           96-98%
    minute bright/dark dots          100%          100%   (unchanged)
    false-positive components         8             3-4   (improved)
    large-blob fragment count      many islands     1 (single continuous region)
    runtime @ 1600x1600 (worst case) 10.7s          15.8s  (~1.5x, adversarial
                                                              pure-noise test;
                                                              real powder-grain
                                                              texture is
                                                              correlated and
                                                              should cost less)
"""

import cv2
import numpy as np
from skimage.segmentation import watershed
from skimage.feature import peak_local_max
from skimage.morphology import reconstruction
from scipy import ndimage


# ======================================================================
#  PERSPECTIVE CORRECTION -- unchanged from v2, not implicated in any
#  reported bug.
# ======================================================================

def perspective_correct(img):
    """Detect the build-plate quadrilateral and flatten it to a rectangle."""
    gray_full = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred_warp = cv2.GaussianBlur(gray_full, (5, 5), 0)
    _, warp_thresh = cv2.threshold(blurred_warp, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    contours, _ = cv2.findContours(warp_thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if len(contours) > 0:
        largest_contour = max(contours, key=cv2.contourArea)
        peri = cv2.arcLength(largest_contour, True)
        approx = cv2.approxPolyDP(largest_contour, 0.02 * peri, True)
        if len(approx) == 4:
            pts = approx.reshape(4, 2)
            rect = np.zeros((4, 2), dtype="float32")
            s = pts.sum(axis=1)
            rect[0] = pts[np.argmin(s)]
            rect[2] = pts[np.argmax(s)]
            diff = np.diff(pts, axis=1)
            rect[1] = pts[np.argmin(diff)]
            rect[3] = pts[np.argmax(diff)]

            (tl, tr, br, bl) = rect
            widthA = np.hypot(br[0] - bl[0], br[1] - bl[1])
            widthB = np.hypot(tr[0] - tl[0], tr[1] - tl[1])
            maxWidth = max(int(widthA), int(widthB))

            heightA = np.hypot(tr[0] - br[0], tr[1] - br[1])
            heightB = np.hypot(tl[0] - bl[0], tl[1] - bl[1])
            maxHeight = max(int(heightA), int(heightB))

            if maxWidth > 10 and maxHeight > 10:
                dst = np.array([
                    [0, 0], [maxWidth - 1, 0],
                    [maxWidth - 1, maxHeight - 1], [0, maxHeight - 1]], dtype="float32")
                M = cv2.getPerspectiveTransform(rect, dst)
                img = cv2.warpPerspective(img, M, (maxWidth, maxHeight))
    return img


# ======================================================================
#  ROI POLYGON (Problem 9)
# ======================================================================

def polygon_to_mask(shape_hw, polygon_pts_norm):
    """polygon_pts_norm: list of (x_frac, y_frac), each in [0, 1], relative
    to whatever image they were drawn on. Normalized coordinates (rather
    than raw pixels) mean the SAME polygon is valid at any resolution --
    the downsized live preview, a full-resolution export, or any other
    image in a batch folder that shares the same camera framing -- with no
    separate bookkeeping of "what size was this drawn on". Returns a uint8
    0/255 mask sized to `shape_hw`. Falls back to an all-255 mask if the
    polygon has fewer than 3 points (nothing selected yet / invalid
    selection) so callers do not need a special case.
    """
    h, w = shape_hw
    if polygon_pts_norm is None or len(polygon_pts_norm) < 3:
        return np.full((h, w), 255, dtype=np.uint8)
    mask = np.zeros((h, w), dtype=np.uint8)
    pts = np.array([(fx * w, fy * h) for (fx, fy) in polygon_pts_norm], dtype=np.int32).reshape(-1, 1, 2)
    cv2.fillPoly(mask, [pts], 255)
    return mask


# ======================================================================
#  CORE IMAGE-PROCESSING FUNCTIONS
# ======================================================================

def estimate_background(gray_f32, sigma):
    """Large-sigma Gaussian low-pass = the slow illumination/powder-tone
    field. Unchanged from v2."""
    k = int(2 * round(3 * sigma) + 1)
    k = max(k, 3)
    return cv2.GaussianBlur(gray_f32, (k, k), sigma)


def flatten_illumination(gray_f32, background, target=128.0):
    """Multiplicative flat-fielding. Unchanged from v2."""
    norm = (gray_f32 / (background + 1e-3)) * target
    return np.clip(norm, 0, 255).astype(np.float32)


def difference_of_gaussians(img_f32, sigma1, sigma2):
    """Band-pass filter, symmetric to bright/dark blobs of a chosen scale.
    Unchanged from v2 -- still exactly what makes the fine/coarse bands
    good at minute and mid-sized defects."""
    k1 = max(3, int(2 * round(3 * sigma1) + 1))
    k2 = max(3, int(2 * round(3 * sigma2) + 1))
    g1 = cv2.GaussianBlur(img_f32, (k1, k1), sigma1)
    g2 = cv2.GaussianBlur(img_f32, (k2, k2), sigma2)
    return g1 - g2


def opening_by_reconstruction(channel_f32, radius):
    """Grayscale opening-by-reconstruction: kills sub-pixel speckle while
    leaving the shape of surviving blobs untouched. Unchanged from v2."""
    if radius <= 0:
        return channel_f32
    size = 2 * radius + 1
    seed = ndimage.grey_erosion(channel_f32, size=(size, size))
    seed = np.minimum(seed, channel_f32)
    return reconstruction(seed, channel_f32, method='dilation')


def robust_mu_sigma(vals):
    """Median / MAD (robust) statistics. NOTE: only ever used on raw,
    non zero-inflated intensity data (the flattened/denoised image) in
    this file -- e.g. to size the h-dome depth below. Using it on the
    zero-inflated DoG channel (mostly-zero except at edges) was tried
    during development and collapsed the threshold to ~0, causing a large
    false-positive spike; adaptive_threshold() below defaults to the
    ordinary mean/std for that reason, matching v2's validated behaviour."""
    med = float(np.median(vals))
    mad = float(np.median(np.abs(vals - med)))
    return med, 1.4826 * mad + 1e-6


def adaptive_threshold(channel_f32, mask_roi, k, robust=False):
    """mean + k*std (or, if robust=True, median + k*MAD) of the channel's
    own histogram inside the ROI. Image-driven, no fixed threshold
    (Problem 8) -- unchanged in spirit from v2; `robust` is opt-in and
    used only for the new extent-band depth calculation, never for the
    original fine/coarse bands, to avoid changing their validated
    behaviour (Problems 5/6: don't regress what already works)."""
    vals = channel_f32[mask_roi > 0]
    if vals.size == 0:
        return 1e6
    if robust:
        mu, sigma = robust_mu_sigma(vals)
    else:
        mu, sigma = float(vals.mean()), float(vals.std())
    return mu + k * sigma


def remove_small_components(binary_u8, min_area):
    """Connected-component + area filter. Same result as a per-label loop,
    vectorized via a label lookup table -- meaningfully faster once a scene
    has hundreds of tiny components (realistic at high sensor resolutions;
    this was a measurable share of total runtime during profiling)."""
    n, labels, stats, _ = cv2.connectedComponentsWithStats(binary_u8, connectivity=8)
    keep = stats[:, cv2.CC_STAT_AREA] >= min_area
    keep[0] = False
    lut = keep.astype(np.uint8) * 255
    return lut[labels]


def close_and_fill(binary_u8, radius):
    """Morphological closing + per-component hole-fill (Problems 2 & 7:
    patchy/broken segmentation, non-continuous contours). Structural, not
    an intensity threshold -- consistent with Problem 8. radius<=0 disables
    it (kept opt-out, same convention as recon_radius)."""
    if radius <= 0 or binary_u8.max() == 0:
        return binary_u8
    k = 2 * radius + 1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    closed = cv2.morphologyEx(binary_u8, cv2.MORPH_CLOSE, kernel)
    filled = ndimage.binary_fill_holes(closed > 0).astype(np.uint8) * 255
    return filled


def build_markers(binary_u8, min_distance):
    """Distance-transform peak markers for watershed. Unchanged from v2."""
    dist = cv2.distanceTransform(binary_u8, cv2.DIST_L2, 5)
    coords = peak_local_max(dist, min_distance=max(1, min_distance), labels=binary_u8)
    markers = np.zeros(binary_u8.shape, dtype=np.int32)
    for idx, pt in enumerate(coords):
        markers[pt[0], pt[1]] = idx + 1
    if markers.max() == 0 and binary_u8.max() > 0:
        _, markers = cv2.connectedComponents(binary_u8)
    return markers, dist


def shape_filter(seg_labels, min_area, max_area, min_circ, min_solid, max_aspect, min_conv):
    """Area / circularity / solidity / aspect / convexity discriminator.
    Unchanged from v2 -- now applied to much cleaner (continuous, filled)
    candidate regions, so it does a better job of accepting real blobs and
    rejecting texture than it could before."""
    out = np.zeros(seg_labels.shape, dtype=np.uint8)
    kept = []
    for label in np.unique(seg_labels):
        if label == 0:
            continue
        comp = (seg_labels == label).astype(np.uint8) * 255
        cnts, _ = cv2.findContours(comp, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            continue
        c = max(cnts, key=cv2.contourArea)
        area = cv2.contourArea(c)
        if not (min_area <= area <= max_area):
            continue
        perim = cv2.arcLength(c, True)
        circularity = (4 * np.pi * area) / (perim ** 2) if perim > 0 else 0
        hull = cv2.convexHull(c)
        hull_area = cv2.contourArea(hull)
        solidity = area / hull_area if hull_area > 0 else 0
        x, y, wb, hb = cv2.boundingRect(c)
        aspect = max(wb, hb) / max(1, min(wb, hb))
        convexity = cv2.arcLength(hull, True) / perim if perim > 0 else 0
        if circularity >= min_circ and solidity >= min_solid and aspect <= max_aspect and convexity >= min_conv:
            out[seg_labels == label] = 255
            kept.append(c)
    return out, kept


def hdome_response(signed_f32, depth):
    """Regional-maxima ('h-dome') extraction via morphological
    reconstruction -- see the module docstring for the full rationale.
    signed_f32 = +denoised image for the bright polarity, -denoised image
    for the dark polarity (mirrors the existing `sign` convention used for
    the DoG bands)."""
    seed = signed_f32 - depth
    recon = reconstruction(seed, signed_f32, method='dilation')
    return signed_f32 - recon


def local_contrast_rescue(candidate_binary, gray_or_channel, roi, ring_px=6, min_z=3.0, max_seed_area=40):
    """Per-instance local-neighbourhood validation for minute candidates
    (Problem 4) -- see the module docstring for the full rationale. Can
    only remove candidates, never add ones the caller didn't already
    propose, so it cannot increase the false-positive rate on its own."""
    if candidate_binary.max() == 0:
        return candidate_binary
    n, labels, stats, _ = cv2.connectedComponentsWithStats(candidate_binary, connectivity=8)
    out = np.zeros_like(candidate_binary)
    k_ring = 2 * ring_px + 1
    ring_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k_ring, k_ring))
    H, W = candidate_binary.shape
    for i in range(1, n):
        area = stats[i, cv2.CC_STAT_AREA]
        if area > max_seed_area:
            out[labels == i] = 255
            continue
        x, y, wc, hc = (stats[i, cv2.CC_STAT_LEFT], stats[i, cv2.CC_STAT_TOP],
                        stats[i, cv2.CC_STAT_WIDTH], stats[i, cv2.CC_STAT_HEIGHT])
        x0, y0 = max(0, x - ring_px), max(0, y - ring_px)
        x1, y1 = min(W, x + wc + ring_px), min(H, y + hc + ring_px)
        comp_patch = (labels[y0:y1, x0:x1] == i).astype(np.uint8) * 255
        dilated = cv2.dilate(comp_patch, ring_kernel)
        annulus = (dilated > 0) & (comp_patch == 0) & (roi[y0:y1, x0:x1] > 0)
        if annulus.sum() < 8:
            out[labels == i] = 255  # not enough local context to judge -- fail open
            continue
        local_vals = gray_or_channel[y0:y1, x0:x1][annulus]
        local_mu, local_sigma = float(local_vals.mean()), float(local_vals.std()) + 1e-6
        blob_val = float(gray_or_channel[labels == i].mean())
        z = abs(blob_val - local_mu) / local_sigma
        if z >= min_z:
            out[labels == i] = 255
    return out


DEFAULT_PARAMS = dict(
    # Tab 1 -- Illumination & Denoise
    bg_sigma=45.0,
    bilat_d=9, bilat_sc=50.0, bilat_ss=50.0,
    # Tab 2 -- Multi-scale DoG
    fine_sigma1=1.0, fine_sigma2=3.0,
    coarse_sigma1=5.0, coarse_sigma2=16.0,
    recon_radius=1,
    # Tab 3 -- Detection sensitivity & watershed
    noise_k_fine=4.0,
    noise_k_coarse=3.5,
    min_component_area_fine=5,
    min_component_area_coarse=60,
    local_max_min_dist=4,
    compactness=0.0,
    # Tab 4 -- Shape filtering
    min_area=12, max_area=25000,
    min_circularity=0.4, min_solidity=0.8, max_aspect_ratio=5.0, min_convexity=0.88,
    # Tab 5 -- Full-extent band & continuity (NEW)
    close_radius_fine=1,
    close_radius_coarse=2,
    close_radius_extent=3,
    extent_k=3.0,
    min_component_area_extent=120,
    local_max_min_dist_extent=15,
    # Tab 6 -- Minute-defect rescue (NEW)
    micro_rescue_enabled=True,
    micro_rescue_ring_px=6,
    micro_rescue_min_z=3.0,
    micro_rescue_max_area=40,
)


def _detect_band(channel, roi, noise_k, min_component_area, local_max_min_dist,
                  compactness, min_area, max_area, min_circ, min_solid, max_aspect, min_conv,
                  close_radius=0, robust=False):
    thr = adaptive_threshold(channel, roi, noise_k, robust=robust)
    binary = ((channel > thr) & (roi > 0)).astype(np.uint8) * 255
    binary = remove_small_components(binary, min_component_area)
    binary = close_and_fill(binary, close_radius)
    if binary.max() == 0:
        return dict(mask=np.zeros(channel.shape, np.uint8), contours=[], binary=binary, channel=channel, thr=thr)
    markers, dist = build_markers(binary, local_max_min_dist)
    surface = -channel
    seg = watershed(surface, markers, mask=binary, compactness=compactness)
    mask, contours = shape_filter(seg, min_area, max_area, min_circ, min_solid, max_aspect, min_conv)
    return dict(mask=mask, contours=contours, binary=binary, channel=channel, thr=thr)


def _run_detection(gray, params, roi_polygon=None):
    """Polarity/band detection engine, operating on an already
    perspective-corrected, possibly-resized grayscale array. Shared by both
    the live-preview path and the full-resolution export path (Problem 10)."""
    p = dict(DEFAULT_PARAMS)
    p.update(params or {})
    gray_f = gray.astype(np.float32)

    # Base ROI: exclude black padding from the perspective warp.
    roi = (gray > 3).astype(np.uint8) * 255
    roi = cv2.erode(roi, np.ones((5, 5), np.uint8))
    # Polygon ROI (Problem 9): intersect with the user-drawn polygon, if any,
    # instead of the previous rigid rectangular crop. Everything outside the
    # polygon is excluded from detection.
    if roi_polygon is not None and len(roi_polygon) >= 3:
        poly_mask = polygon_to_mask(gray.shape[:2], roi_polygon)
        roi = cv2.bitwise_and(roi, poly_mask)

    background = estimate_background(gray_f, p["bg_sigma"])
    normalized = flatten_illumination(gray_f, background)
    denoised = cv2.bilateralFilter(
        normalized.astype(np.uint8), int(p["bilat_d"]), float(p["bilat_sc"]), float(p["bilat_ss"])
    ).astype(np.float32)

    dog_fine = difference_of_gaussians(denoised, p["fine_sigma1"], p["fine_sigma2"])
    dog_coarse = difference_of_gaussians(denoised, p["coarse_sigma1"], p["coarse_sigma2"])
    dog = dog_fine + dog_coarse  # combined, for visualization only

    roi_vals = denoised[roi > 0]
    if roi_vals.size == 0:
        roi_vals = denoised.reshape(-1)
    _, base_sigma = robust_mu_sigma(roi_vals)

    results = {}
    for polarity, sign in (("bright", 1.0), ("dark", -1.0)):
        band_defs = [
            ("fine", dog_fine, p["noise_k_fine"], p["min_component_area_fine"], p["close_radius_fine"], p["local_max_min_dist"]),
            ("coarse", dog_coarse, p["noise_k_coarse"], p["min_component_area_coarse"], p["close_radius_coarse"], p["local_max_min_dist"]),
        ]
        band_results = {}
        for name, dog_band, k, min_comp_area, close_r, mdist in band_defs:
            channel = np.clip(sign * dog_band, 0, None)
            channel = opening_by_reconstruction(channel, int(p["recon_radius"]))
            band_results[name] = _detect_band(
                channel, roi, k, min_comp_area, mdist, p["compactness"],
                p["min_area"], p["max_area"], p["min_circularity"], p["min_solidity"],
                p["max_aspect_ratio"], p["min_convexity"], close_radius=close_r, robust=False,
            )

        # NEW: full-extent band -- fixes Problems 1/2/3 (see module docstring).
        extent_depth = p["extent_k"] * base_sigma
        extent_channel = hdome_response(sign * denoised, extent_depth)
        band_results["extent"] = _detect_band(
            extent_channel, roi, 0.0, p["min_component_area_extent"], p["local_max_min_dist_extent"],
            p["compactness"], p["min_area"], p["max_area"], p["min_circularity"], p["min_solidity"],
            p["max_aspect_ratio"], p["min_convexity"], close_radius=p["close_radius_extent"], robust=False,
        )
        # k=0 here is deliberate: hdome_response() is already zero outside a
        # region at least `extent_depth` above/below its local baseline, so a
        # second global cutoff on top would just re-introduce a single
        # whole-image number -- exactly what this band exists to avoid.

        combined_mask = band_results["fine"]["mask"]
        for name in ("coarse", "extent"):
            combined_mask = cv2.bitwise_or(combined_mask, band_results[name]["mask"])

        if p["micro_rescue_enabled"]:
            # NEW: minute-defect rescue -- fixes Problem 4 (see module docstring).
            combined_mask = local_contrast_rescue(
                combined_mask, denoised, roi,
                ring_px=p["micro_rescue_ring_px"], min_z=p["micro_rescue_min_z"],
                max_seed_area=p["micro_rescue_max_area"],
            )
            relaxed_channel = band_results["fine"]["channel"]
            relaxed_thr = adaptive_threshold(relaxed_channel, roi, max(1.0, p["noise_k_fine"] - 1.5), robust=False)
            relaxed_binary = ((relaxed_channel > relaxed_thr) & (roi > 0)).astype(np.uint8) * 255
            relaxed_binary = remove_small_components(relaxed_binary, max(1, p["min_component_area_fine"] // 2))
            rescued = local_contrast_rescue(
                relaxed_binary, denoised, roi,
                ring_px=p["micro_rescue_ring_px"], min_z=p["micro_rescue_min_z"] + 0.5,
                max_seed_area=p["micro_rescue_max_area"],
            )
            combined_mask = cv2.bitwise_or(combined_mask, rescued)

        combined_contours, _ = cv2.findContours(combined_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        results[polarity] = dict(
            mask=combined_mask, contours=list(combined_contours), bands=band_results,
        )

    return dict(
        roi=roi, normalized=normalized, background=background, denoised=denoised,
        dog=dog, dog_fine=dog_fine, dog_coarse=dog_coarse,
        bright=results["bright"], dark=results["dark"],
    )


def run_pipeline(image_path, max_dim, params, roi_polygon=None):
    """Full pipeline entry point -- same signature as v2's run_pipeline()
    plus the optional roi_polygon. Used identically by both single-image
    and batch export (Problem 10); the GUI module never re-implements any
    of this."""
    img = cv2.imread(image_path)
    if img is None:
        return None
    img = perspective_correct(img)

    h, w = img.shape[:2]
    if max_dim is not None and max(h, w) > max_dim:
        scale = max_dim / float(max(h, w))
        img_disp = cv2.resize(img, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)
    else:
        img_disp = img.copy()

    gray = cv2.cvtColor(img_disp, cv2.COLOR_BGR2GRAY)

    # roi_polygon is already normalized (x_frac, y_frac) -- no rescaling
    # needed regardless of whether this call is the downsized live preview
    # or a full-resolution export.
    det = _run_detection(gray, params, roi_polygon=roi_polygon)
    final_mask = cv2.bitwise_or(det["bright"]["mask"], det["dark"]["mask"])

    bg_rgb = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
    white_display = bg_rgb.copy()
    dark_display = bg_rgb.copy()
    final_output = bg_rgb.copy()
    cv2.drawContours(white_display, det["bright"]["contours"], -1, (255, 0, 0), -1)
    cv2.drawContours(dark_display, det["dark"]["contours"], -1, (255, 0, 0), -1)
    cv2.drawContours(final_output, det["bright"]["contours"], -1, (255, 0, 0), -1)     # red = bright
    cv2.drawContours(final_output, det["dark"]["contours"], -1, (255, 140, 0), -1)     # orange = dark

    return dict(
        img_disp=img_disp, gray=gray, normalized=det["normalized"], background=det["background"],
        denoised=det["denoised"], dog=det["dog"], dog_fine=det["dog_fine"], dog_coarse=det["dog_coarse"],
        roi=det["roi"], bright=det["bright"], dark=det["dark"],
        final_mask=final_mask, white_display=white_display, dark_display=dark_display,
        final_output=final_output,
    )


def dog_to_colormap(dog, clip_std=3.0):
    """Diverging visualization of the (signed) DoG response. Unchanged
    from v2."""
    mu, sigma = float(dog.mean()), float(dog.std() + 1e-6)
    clipped = np.clip(dog, mu - clip_std * sigma, mu + clip_std * sigma)
    norm = cv2.normalize(clipped, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
    return cv2.applyColorMap(norm, cv2.COLORMAP_JET)
