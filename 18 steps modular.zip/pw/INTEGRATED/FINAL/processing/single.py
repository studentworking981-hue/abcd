"""Single-image processing pipeline (the original 'Tab 2'): step-by-step
watershed segmentation, topography, parameter update handlers, and
pipeline config save/load. Relocated verbatim from ImageAnalyzerApp in
the original single-file app."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from PIL import Image, ImageTk
import cv2
import numpy as np
from scipy import ndimage as ndi
import copy
import json
import math
import os
import sys
import gc
import threading
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from ..utils.constants import DEFAULT_PIPELINE_PARAMS
from . import pbf_defect


class SingleImageMixin:
    """
    Mixin holding methods relocated verbatim from the original
    ``ImageAnalyzerApp`` god-class. It is combined with the other
    mixins in ``app.Application`` via multiple inheritance, so every
    method below still shares the same ``self`` (and therefore the
    same widgets / state) as before -- nothing about how these
    methods call each other or access ``self.*`` attributes changed.
    """

    @staticmethod
    def _merge_pipeline_params(loaded_params):
        """Deep-merge a loaded pipeline_params dict onto a fresh copy of
        DEFAULT_PIPELINE_PARAMS.

        REGRESSION FIX (R6): previously config loading did a straight
        ``self.params = data['pipeline_params']`` replacement. Any config
        file saved under a different/older key schema (missing keys, or
        still using the retired step_11_topography / step_12_topo_watershed
        / step_20_perspective keys from an earlier pipeline layout) would
        then raise a KeyError the next time process_all_steps() ran.
        Merging keeps every default key present, only overriding the
        sub-keys the loaded file actually provides, and silently ignores
        unrecognized legacy keys instead of crashing.
        """
        merged = copy.deepcopy(DEFAULT_PIPELINE_PARAMS)
        if not isinstance(loaded_params, dict):
            return merged
        for step_key, step_defaults in merged.items():
            loaded_step = loaded_params.get(step_key)
            if isinstance(loaded_step, dict):
                step_defaults.update(loaded_step)
        return merged

    def tab2_upload_image(self):
        """Upload image for watershed analysis"""
        file_path = filedialog.askopenfilename(
            title="Select Image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png"),
                       ("All files", "*.*")]
        )

        if file_path:
            self.tab2_image_path = file_path
            self.tab2_cv_image = cv2.imread(file_path)
            self.tab2_image = cv2.cvtColor(self.tab2_cv_image, cv2.COLOR_BGR2RGB)

            # Display the image immediately
            self.step_images = {}
            self.step_images[0] = self.tab2_image.copy()
            self.current_step = 0
            self.display_current_step()

            self.tab2_info_label.config(text="Image loaded. Load ROI coordinates and click Start Processing.")

    def tab2_load_roi(self):
        """Load ROI coordinates from JSON file"""
        file_path = filedialog.askopenfilename(
            title="Select ROI Coordinates File",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )

        if file_path:
            with open(file_path, 'r') as f:
                data = json.load(f)

            self.tab2_roi_points = np.array(data['polygon_points'], dtype=np.int32)

            # Load parameters if they exist in the file.
            # REGRESSION FIX (R6): merge onto a fresh copy of the defaults
            # instead of replacing self.params outright, so a file saved
            # under an older/incomplete key schema (e.g. missing keys, or
            # still carrying the retired step_11_topography /
            # step_12_topo_watershed keys) fills in the gaps and drops the
            # obsolete ones instead of causing a KeyError deep inside
            # process_all_steps().
            if 'pipeline_params' in data:
                self.params = self._merge_pipeline_params(data['pipeline_params'])

            self.tab2_info_label.config(
                text=f"ROI loaded with {len(self.tab2_roi_points)} points. Click Start Processing."
            )

    def tab2_zoom(self, event):
        """Zoom image with Ctrl+MouseWheel (Windows/macOS: delta; Linux: num)"""
        if self.tab2_image is None:
            return
        # event.delta works on Windows/macOS; on Linux Button-4/5 give delta=0
        if event.delta != 0:
            factor = 1.1 if event.delta > 0 else 0.9
        else:
            # Linux scroll up = Button-4, scroll down = Button-5
            factor = 1.1 if getattr(event, 'num', 0) == 4 else 0.9
        self.tab2_zoom_level *= factor
        self.tab2_zoom_level = max(0.1, min(10.0, self.tab2_zoom_level))
        self._tab2_update_zoom_label()
        if self.current_step == 1:
            self._display_step1_drawing()
        elif self.current_step in self.step_images:
            self.display_current_step()

    def tab2_zoom_button(self, factor):
        """Zoom image with +/- buttons or keys"""
        if self.current_step != 1 and self.current_step not in self.step_images:
            return
        self.tab2_zoom_level *= factor
        self.tab2_zoom_level = max(0.1, min(10.0, self.tab2_zoom_level))
        self._tab2_update_zoom_label()
        self.display_current_step()

    def tab2_zoom_reset(self):
        """Reset zoom to 100%."""
        self.tab2_zoom_level = 1.0
        self._tab2_update_zoom_label()
        self.display_current_step()

    def _tab2_update_zoom_label(self):
        """Refresh the zoom % label in the nav bar."""
        if hasattr(self, 'zoom_label'):
            self.zoom_label.config(text=f"{int(self.tab2_zoom_level * 100)}%")

    def _tab2_drag_zoom_start(self, event):
        """Record start Y position for Ctrl+drag zoom."""
        self._drag_zoom_start_y = event.y
        self._drag_zoom_start_level = self.tab2_zoom_level

    def _tab2_drag_zoom_motion(self, event):
        """Ctrl+drag up = zoom in, drag down = zoom out."""
        if not hasattr(self, '_drag_zoom_start_y'):
            return
        delta = self._drag_zoom_start_y - event.y   # positive = dragged up
        factor = 1.0 + delta * 0.005                # 0.5% per pixel
        new_level = self._drag_zoom_start_level * factor
        self.tab2_zoom_level = max(0.1, min(10.0, new_level))
        self._tab2_update_zoom_label()
        if self.current_step != 1 and self.current_step not in self.step_images:
            return
        self.display_current_step()

    def tab2_step1_canvas_click(self, event):
        """Handle canvas click: only active during Step 1 ROI drawing."""
        if self.current_step != 1:
            return
        if self.tab2_image is None:
            return
        if self.step1_polygon_closed:
            return

        # Convert canvas coords    image coords (account for zoom)
        cx = int(self.tab2_canvas.canvasx(event.x))
        cy = int(self.tab2_canvas.canvasy(event.y))
        x = int(cx / self.tab2_zoom_level)
        y = int(cy / self.tab2_zoom_level)

        # Clamp to image bounds
        h, w = self.tab2_image.shape[:2]
        x = max(0, min(w - 1, x))
        y = max(0, min(h - 1, y))

        # Check if clicking near first point to close polygon
        if len(self.step1_polygon_points) >= 3:
            fp = self.step1_polygon_points[0]
            dist = math.sqrt((x - fp[0])**2 + (y - fp[1])**2)
            if dist <= int(15 / self.tab2_zoom_level):
                self.step1_polygon_closed = True
                self.tab2_roi_points = np.array(self.step1_polygon_points, dtype=np.int32)
                self._step1_auto_save()
                self._display_step1_drawing()
                return

        self.step1_polygon_points.append((x, y))
        self._display_step1_drawing()

    def _step1_auto_save(self):
        """Auto-save ROI coordinates JSON next to the loaded image.
           The config JSON (Save Config) will use the same folder."""
        if self.tab2_image_path is None:
            return
        img_dir  = os.path.dirname(os.path.abspath(self.tab2_image_path))
        img_stem = Path(self.tab2_image_path).stem
        roi_path = os.path.join(img_dir, f"{img_stem}_roi.json")

        data = {
            "image_path":  self.tab2_image_path,
            "image_shape": list(self.tab2_image.shape[:2]),
            "polygon_points": self.step1_polygon_points,
            "pipeline_params": self.params
        }
        with open(roi_path, 'w') as f:
            json.dump(data, f, indent=4)

        # ── Also write a copy to configurations/conf.json so Batch tab
        #    can auto-load it on next startup ──────────────────────────
        try:
            conf_dir = Path(__file__).resolve().parent / 'configurations'
            conf_dir.mkdir(exist_ok=True)
            with open(conf_dir / 'conf.json', 'w') as _cf:
                json.dump(data, _cf, indent=4)
        except Exception:
            pass  # never block the main save if this fails

        # Remember save folder so Save Config lands in same place
        self._roi_save_dir = img_dir
        self.tab2_info_label.config(
            text=f"ROI auto-saved    {roi_path}  |  Click Next to run pipeline.")
        messagebox.showinfo("ROI Saved",
            f"Polygon closed!\n\nCoordinates auto-saved to:\n{roi_path}\n\nClick Next to run the pipeline.")

    def tab2_step1_clear_points(self):
        """Clear Step 1 polygon drawing."""
        self.step1_polygon_points = []
        self.step1_polygon_closed = False
        self.tab2_roi_points = None
        self._display_step1_drawing()

    def tab2_start_processing(self):
        """Start the step-by-step watershed processing.

        Behaviour:
        - If the user has previously clicked 'Load Config' and the config
          contained polygon_points, those points are already stored in
          self.step1_polygon_points / self.step1_polygon_closed.
             Step 1 will open with the saved polygon pre-drawn so the user
            can verify or modify it before proceeding.
        - If no config was loaded (or the config had no polygon), the Step 1
          polygon state is empty and the user draws manually as before.
        """
        if self.tab2_image is None:
            messagebox.showwarning("Warning", "Please upload an image first")
            return

        # ── Determine whether a pre-loaded ROI is available ──────────────
        # (populated by tab2_load_config when JSON contains polygon_points)
        roi_pre_loaded = (
            self.step1_polygon_closed and
            len(self.step1_polygon_points) >= 3
        )

        # If no config was loaded at all, make sure the drawing state is clean
        if not roi_pre_loaded:
            self.tab2_roi_points      = None
            self.step1_polygon_points = []
            self.step1_polygon_closed = False

        # Show Step 0: original image only
        self.step_images = {}
        self.step_images[0] = self.tab2_image.copy()
        self.current_step = 0
        self.display_current_step()

        # Allow moving to Step 1 (ROI draw/review)
        self.next_button.config(state='normal')
        self.prev_button.config(state='disabled')

        if roi_pre_loaded:
            self.tab2_info_label.config(
                text=f"ROI from loaded config pre-filled "
                     f"({len(self.step1_polygon_points)} points). "
                     f"Click Next to review / edit in Step 1, then proceed.")
        else:
            self.tab2_info_label.config(
                text="Step 0 loaded. Click Next to draw ROI polygon in Step 1.")

    def process_all_steps(self):
        """Process all watershed steps using Scikit-Image approach (Sobel + Histogram Markers)"""
        self.step_images = {}
        self.step_data = {}

        # Step 0: Original Image
        self.step_images[0] = self.tab2_image.copy()

        # Step 1: RoI Masked Image (4-point polygon)
        mask = np.zeros(self.tab2_image.shape[:2], dtype=np.uint8)
        cv2.fillPoly(mask, [self.tab2_roi_points], 255)
        masked_image = self.tab2_cv_image.copy()
        masked_image[mask == 0] = [0, 0, 0]
        self.step_images[1] = cv2.cvtColor(masked_image, cv2.COLOR_BGR2RGB)
        self.step_data['mask'] = mask
        self.step_data['masked_bgr'] = masked_image

        # Step 2: Rotate / Flip  (NEW)
        rotated_bgr = masked_image.copy()
        if self.params['step_2_rotate_flip']['enabled']:
            angle = self.params['step_2_rotate_flip']['rotate']
            if angle != 0:
                h, w = rotated_bgr.shape[:2]
                cx, cy = w // 2, h // 2
                M_rot = cv2.getRotationMatrix2D((cx, cy), -angle, 1.0)
                rotated_bgr = cv2.warpAffine(rotated_bgr, M_rot, (w, h),
                                             borderMode=cv2.BORDER_CONSTANT,
                                             borderValue=(0, 0, 0))
            if self.params['step_2_rotate_flip']['flip_h']:
                rotated_bgr = cv2.flip(rotated_bgr, 1)
            if self.params['step_2_rotate_flip']['flip_v']:
                rotated_bgr = cv2.flip(rotated_bgr, 0)
        self.step_images[2] = cv2.cvtColor(rotated_bgr, cv2.COLOR_BGR2RGB)
        self.step_data['rotated_bgr'] = rotated_bgr

        # Step 3: Grayscale Conversion  (was Step 2)
        if self.params['step_3_grayscale']['enabled']:
            gray = cv2.cvtColor(rotated_bgr, cv2.COLOR_BGR2GRAY)
            self.step_images[3] = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
        else:
            gray = cv2.cvtColor(rotated_bgr, cv2.COLOR_BGR2GRAY)
            self.step_images[3] = self.step_images[2].copy()
        self.step_data['gray'] = gray

        # Step 4: Sobel Gradient (Elevation Map)  (was Step 3)
        if self.params['step_4_sobel']['enabled']:
            sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
            sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
            elevation_map = np.hypot(sobel_x, sobel_y)
            elevation_display = cv2.normalize(elevation_map, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        else:
            elevation_map = gray.astype(np.float64)
            elevation_display = gray
        self.step_images[4] = cv2.cvtColor(elevation_display, cv2.COLOR_GRAY2RGB)
        self.step_data['elevation_map'] = elevation_map

        # ================================================================
        # Steps 5-10 (NEW): PBF-engine defect conditioning, inserted
        # between the original Step 4 and Step 5. Ported unchanged from
        # processing/pbf_defect.py (the standalone PBF inspector engine --
        # see that module for the full algorithm). All six sub-steps run
        # together as ONE detection pass; only the resulting denoised
        # grayscale image is handed to Step 11 onward as the new `gray`,
        # so every downstream step (11-20) is completely unaffected by
        # whether this block ran or what it produced. If every one of the
        # six is disabled, `gray` passes through untouched.
        # ================================================================
        pbf_illum = self.params['step_5_pbf_illum']
        pbf_dog = self.params['step_6_pbf_dog']
        pbf_sens = self.params['step_7_pbf_sensitivity']
        pbf_shape = self.params['step_8_pbf_shape']
        pbf_extent = self.params['step_9_pbf_extent']
        pbf_rescue = self.params['step_10_pbf_rescue']

        pbf_active = any(p['enabled'] for p in
                          (pbf_illum, pbf_dog, pbf_sens, pbf_shape, pbf_extent, pbf_rescue))

        if pbf_active:
            pbf_params = dict(pbf_defect.DEFAULT_PARAMS)
            if pbf_illum['enabled']:
                pbf_params.update(bg_sigma=pbf_illum['bg_sigma'], bilat_d=pbf_illum['bilat_d'],
                                   bilat_sc=pbf_illum['bilat_sc'], bilat_ss=pbf_illum['bilat_ss'])
            if pbf_dog['enabled']:
                pbf_params.update(fine_sigma1=pbf_dog['fine_sigma1'], fine_sigma2=pbf_dog['fine_sigma2'],
                                   coarse_sigma1=pbf_dog['coarse_sigma1'], coarse_sigma2=pbf_dog['coarse_sigma2'],
                                   recon_radius=pbf_dog['recon_radius'])
            if pbf_sens['enabled']:
                pbf_params.update(noise_k_fine=pbf_sens['noise_k_fine'], noise_k_coarse=pbf_sens['noise_k_coarse'],
                                   min_component_area_fine=pbf_sens['min_component_area_fine'],
                                   min_component_area_coarse=pbf_sens['min_component_area_coarse'],
                                   local_max_min_dist=pbf_sens['local_max_min_dist'],
                                   compactness=pbf_sens['compactness'])
            if pbf_shape['enabled']:
                pbf_params.update(min_area=pbf_shape['min_area'], max_area=pbf_shape['max_area'],
                                   min_circularity=pbf_shape['min_circularity'], min_solidity=pbf_shape['min_solidity'],
                                   max_aspect_ratio=pbf_shape['max_aspect_ratio'], min_convexity=pbf_shape['min_convexity'])
            if pbf_extent['enabled']:
                pbf_params.update(close_radius_fine=pbf_extent['close_radius_fine'],
                                   close_radius_coarse=pbf_extent['close_radius_coarse'],
                                   close_radius_extent=pbf_extent['close_radius_extent'],
                                   extent_k=pbf_extent['extent_k'],
                                   min_component_area_extent=pbf_extent['min_component_area_extent'],
                                   local_max_min_dist_extent=pbf_extent['local_max_min_dist_extent'])
            pbf_params['micro_rescue_enabled'] = bool(pbf_rescue['enabled'])
            if pbf_rescue['enabled']:
                pbf_params.update(micro_rescue_ring_px=pbf_rescue['micro_rescue_ring_px'],
                                   micro_rescue_min_z=pbf_rescue['micro_rescue_min_z'],
                                   micro_rescue_max_area=pbf_rescue['micro_rescue_max_area'])

            # `gray` is already masked to the existing 4-point ROI (Step 1),
            # so the PBF engine's own "gray > 3" ROI derivation lines up
            # with the app's existing ROI with no separate bookkeeping.
            pbf_det = pbf_defect._run_detection(gray, pbf_params, roi_polygon=None)
            self.step_data['pbf_detection'] = pbf_det

            denoised_u8 = np.clip(pbf_det['denoised'], 0, 255).astype(np.uint8)

            # Step 5: Illumination & Denoise
            self.step_images[5] = cv2.cvtColor(denoised_u8, cv2.COLOR_GRAY2RGB)
            # Step 6: Multi-Scale DoG (diverging colormap, informational)
            self.step_images[6] = cv2.cvtColor(
                pbf_defect.dog_to_colormap(pbf_det['dog']), cv2.COLOR_BGR2RGB)
            # Step 7: Sensitivity & Watershed -- fine+coarse band mask overlay
            band_mask = np.zeros(gray.shape, dtype=np.uint8)
            for pol in ('bright', 'dark'):
                for name in ('fine', 'coarse'):
                    band_mask = cv2.bitwise_or(band_mask, pbf_det[pol]['bands'][name]['mask'])
            step7_disp = cv2.cvtColor(denoised_u8, cv2.COLOR_GRAY2RGB)
            step7_disp[band_mask > 0] = [255, 80, 0]
            self.step_images[7] = step7_disp
            # Step 8: Defect Shape Filtering -- same bands, post shape-filter
            # (shape filtering happens inside each band above, so this is
            # the same mask; shown again post-label for clarity)
            step8_disp = cv2.cvtColor(denoised_u8, cv2.COLOR_GRAY2RGB)
            cv2.drawContours(step8_disp,
                              pbf_det['bright']['bands']['fine']['contours'] +
                              pbf_det['bright']['bands']['coarse']['contours'] +
                              pbf_det['dark']['bands']['fine']['contours'] +
                              pbf_det['dark']['bands']['coarse']['contours'],
                              -1, (0, 255, 0), 1)
            self.step_images[8] = step8_disp
            # Step 9: Full-Extent Band & Continuity
            extent_mask = cv2.bitwise_or(pbf_det['bright']['bands']['extent']['mask'],
                                          pbf_det['dark']['bands']['extent']['mask'])
            step9_disp = cv2.cvtColor(denoised_u8, cv2.COLOR_GRAY2RGB)
            step9_disp[extent_mask > 0] = [255, 200, 0]
            self.step_images[9] = step9_disp
            # Step 10: Minute-Defect Rescue -- final PBF combined result
            # (reference only; not consumed by Step 11 onward)
            step10_disp = cv2.cvtColor(denoised_u8, cv2.COLOR_GRAY2RGB)
            cv2.drawContours(step10_disp, pbf_det['bright']['contours'], -1, (255, 0, 0), -1)
            cv2.drawContours(step10_disp, pbf_det['dark']['contours'], -1, (255, 140, 0), -1)
            self.step_images[10] = step10_disp

            # Feed the cleaned-up image forward; everything below this
            # line (Step 11 onward) is unmodified and unaware of the PBF
            # engine -- it just receives a (possibly) different `gray`.
            gray = denoised_u8
        else:
            gray_display = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
            for i in range(5, 11):
                self.step_images[i] = gray_display

        # Step 11: Histogram-based Markers  (was Step 4, then Step 13)
        #
        # Data propagation: this step always operates on `gray`, which by
        # this point already holds the output of the most recently executed
        # upstream step (either the PBF-denoised image from Steps 5-10, or
        # the plain grayscale conversion from Step 3 if every PBF step was
        # skipped) -- never a fixed/original image.
        #
        # BRIGHT/DARK SEGMENTATION FIX: the marker array previously stored
        # each foreground pixel's own grey value as its watershed marker id
        # (`gray[foreground_mask] + 1`). Because a real bright or dark
        # region is rarely perfectly flat, adjacent pixels inside the SAME
        # blob almost always carry different grey values, so cv2.watershed
        # saw them as competing seeds and carved thin, unlabeled ridge
        # lines through the interior of otherwise-uniform bright regions --
        # the defect was detected (its pixels crossed the threshold) but
        # never came out as one fully-segmented region. Building one marker
        # id per connected foreground/background blob (via
        # cv2.connectedComponents) instead of one id per grey level fixes
        # that: every pixel of a given blob now shares a single seed, so it
        # grows into one contiguous labeled region with no interior gaps,
        # and distinct blobs still get distinct ids -- so this does not
        # merge separate defects together or introduce over-segmentation.
        if self.params['step_11_markers']['enabled']:
            low_thresh  = self.params['step_11_markers']['low_threshold']
            high_thresh = self.params['step_11_markers']['high_threshold']

            inv = 255 - gray
            background = cv2.GaussianBlur(inv, (0, 0), sigmaX=50, sigmaY=50)
            gbImg = cv2.subtract(inv, background)
            _, gb = cv2.threshold(gbImg, 10, 255, cv2.THRESH_BINARY)

            background_mask = (gray < low_thresh) & (gb > 0)
            foreground_mask = gray > high_thresh

            n_bg, bg_labels = cv2.connectedComponents(background_mask.astype(np.uint8))
            n_fg, fg_labels = cv2.connectedComponents(foreground_mask.astype(np.uint8))

            markers = np.zeros_like(gray, dtype=np.int32)
            markers[background_mask] = bg_labels[background_mask]

            fg_offset = int(n_bg)  # keep foreground ids disjoint from background ids
            markers[foreground_mask] = fg_labels[foreground_mask] + fg_offset
            foreground_label_set = set(
                int(v) + fg_offset for v in np.unique(fg_labels[foreground_mask]) if v > 0
            )

            markers_display = np.zeros_like(gray)
            markers_display[background_mask] = gb[background_mask]
            markers_display[foreground_mask] = gray[foreground_mask]
        else:
            foreground_mask = gray > 0
            n_fg, fg_labels = cv2.connectedComponents(foreground_mask.astype(np.uint8))
            markers = np.zeros_like(gray, dtype=np.int32)
            markers[foreground_mask] = fg_labels[foreground_mask]
            foreground_label_set = set(int(v) for v in np.unique(fg_labels[foreground_mask]) if v > 0)
            markers_display = gray.copy()

        self.step_images[11] = cv2.cvtColor(markers_display, cv2.COLOR_GRAY2RGB)
        self.step_data['markers'] = markers
        self.step_data['foreground_label_set'] = foreground_label_set

        # Step 12: Watershed Application  (was Step 5, then Step 14)
        if self.params['step_12_watershed']['enabled']:
            elevation_map_uint8 = elevation_display
            elevation_map_color = cv2.cvtColor(elevation_map_uint8, cv2.COLOR_GRAY2BGR)
            markers_watershed = markers.copy()
            segmentation = cv2.watershed(elevation_map_color, markers_watershed)

            watershed_display = np.zeros_like(self.step_data['rotated_bgr'])
            watershed_display[segmentation == 1]  = [50, 50, 50]
            watershed_display[segmentation == 2]  = [0, 200, 0]
            watershed_display[segmentation == -1] = [255, 0, 0]
            watershed_display[segmentation == 0]  = [0, 0, 0]
        else:
            segmentation = markers.copy()
            watershed_display = self.step_data['rotated_bgr'].copy()

        self.step_images[12] = cv2.cvtColor(watershed_display, cv2.COLOR_BGR2RGB)
        self.step_data['segmentation'] = segmentation

        # Convert segmentation to binary. Membership in `foreground_label_set`
        # (rather than a raw intensity compare on the label field) is what
        # keeps a fully-grown bright/dark region intact end to end.
        if self.params['step_11_markers']['enabled']:
            if foreground_label_set:
                binary_seg = np.isin(segmentation, list(foreground_label_set)).astype(np.uint8)
            else:
                binary_seg = np.zeros_like(segmentation, dtype=np.uint8)
        else:
            binary_seg = (segmentation > 0).astype(np.uint8)

        # Step 13: Morphological Close  (was Step 6, then Step 15)
        if self.params['step_13_morph_close']['enabled']:
            iterations = self.params['step_13_morph_close']['iterations']
            kernel = np.ones((3, 3), np.uint8)
            morph_close = cv2.morphologyEx(binary_seg, cv2.MORPH_CLOSE, kernel, iterations=iterations)
        else:
            morph_close = binary_seg.copy()

        self.step_images[13] = cv2.cvtColor(morph_close * 255, cv2.COLOR_GRAY2RGB)
        self.step_data['morph_close'] = morph_close

        # Step 14: Morphological Open  (was Step 7, then Step 16)
        if self.params['step_14_morph_open']['enabled']:
            iterations = self.params['step_14_morph_open']['iterations']
            kernel = np.ones((3, 3), np.uint8)
            morph_open = cv2.morphologyEx(morph_close, cv2.MORPH_OPEN, kernel, iterations=iterations)
        else:
            morph_open = morph_close.copy()

        self.step_images[14] = cv2.cvtColor(morph_open * 255, cv2.COLOR_GRAY2RGB)
        self.step_data['morph_open'] = morph_open

        # Step 15: Fill Holes  (was Step 8, then Step 17)
        if self.params['step_15_fillholes']['enabled']:
            filled = ndi.binary_fill_holes(morph_open).astype(np.uint8) * 255
        else:
            filled = morph_open * 255

        self.step_images[15] = cv2.cvtColor(filled, cv2.COLOR_GRAY2RGB)
        self.step_data['filled'] = filled

        # Step 16: Label Connected Components  (was Step 9, then Step 18)
        if self.params['step_16_labeling']['enabled']:
            labeled_array, num_features = ndi.label(filled)
            min_size = self.params['step_16_labeling']['min_size']
            sizes = np.bincount(labeled_array.ravel())
            mask_sizes = sizes > min_size
            mask_sizes[0] = 0
            cleaned_labels = mask_sizes[labeled_array]
            labeled_cleaned, num_cleaned = ndi.label(cleaned_labels)
            labeled_display = cv2.normalize(labeled_cleaned, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            labeled_colored = cv2.applyColorMap(labeled_display, cv2.COLORMAP_JET)
        else:
            labeled_cleaned, num_cleaned = ndi.label(filled)
            labeled_display = cv2.normalize(labeled_cleaned, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            labeled_colored = cv2.applyColorMap(labeled_display, cv2.COLORMAP_JET)

        self.step_images[16] = cv2.cvtColor(labeled_colored, cv2.COLOR_BGR2RGB)
        self.step_data['labeled'] = labeled_cleaned
        self.step_data['num_labels'] = num_cleaned

        # Step 17: Final Result with Colored Segments  (was Step 10, then Step 19)
        result = self.tab2_cv_image.copy()
        min_area = self.params['step_17_final']['min_area']
        max_area = self.params['step_17_final']['max_area']
        segment_color = (0, 0, 255)

        for region_label in range(1, self.step_data['num_labels'] + 1):
            region_mask = (labeled_cleaned == region_label).astype(np.uint8) * 255
            contours, _ = cv2.findContours(region_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            if contours:
                for contour in contours:
                    area = cv2.contourArea(contour)
                    if min_area <= area <= max_area:
                        cv2.drawContours(result, [contour], -1, segment_color, -1)

        self.step_images[17] = cv2.cvtColor(result, cv2.COLOR_BGR2RGB)

        # Step 18: Perspective Warp  (was Step 11, then Step 20)
        if self.params['step_18_perspective']['enabled'] and self.tab2_roi_points is not None:
            roi_pts = self.tab2_roi_points.reshape(-1, 2).astype(np.float32)
            s = roi_pts.sum(axis=1)
            d = np.diff(roi_pts, axis=1).ravel()
            tl = roi_pts[np.argmin(s)]
            br = roi_pts[np.argmax(s)]
            tr = roi_pts[np.argmin(d)]
            bl = roi_pts[np.argmax(d)]
            src_quad = np.array([tl, tr, br, bl], dtype=np.float32)
            out_w = 272*8
            out_h = 272*8
            dst_quad = np.array([[0, 0], [out_w - 1, 0],
                                 [out_w - 1, out_h - 1], [0, out_h - 1]], dtype=np.float32)
            M = cv2.getPerspectiveTransform(src_quad, dst_quad)
            warped = cv2.warpPerspective(result, M, (out_w, out_h),
                                         flags=cv2.INTER_LINEAR,
                                         borderMode=cv2.BORDER_CONSTANT,
                                         borderValue=(0, 0, 0))
        else:
            warped = result.copy()

        self.step_images[18] = cv2.cvtColor(warped, cv2.COLOR_BGR2RGB)
        self.step_data['warped'] = warped

    def display_current_step(self):
        """Display the current step's image and parameters"""
        # Step 1 is interactive: display it even before step_images[1] exists
        if self.current_step == 1:
            self._display_step1_drawing()
            return

        if self.current_step not in self.step_images:
            return

        # Update step info
        step_names = [
            "Step 0: Original Image",
            "Step 1: RoI Selection (4-Point Polygon)",
            "Step 2: Rotate / Flip",
            "Step 3: Grayscale Conversion",
            "Step 4: Sobel Gradient (Elevation Map)",
            "Step 5: PBF Illumination & Denoise",
            "Step 6: PBF Multi-Scale DoG",
            "Step 7: PBF Sensitivity & Watershed",
            "Step 8: PBF Defect Shape Filtering",
            "Step 9: PBF Full-Extent Band & Continuity",
            "Step 10: PBF Minute-Defect Rescue",
            "Step 11: Histogram Markers",
            "Step 12: Watershed Application",
            "Step 13: Morphological Close",
            "Step 14: Morphological Open",
            "Step 15: Fill Holes",
            "Step 16: Connected Component Labeling",
            "Step 17: Final Result",
            "Step 18: Perspective Warp"
        ]

        step_descriptions = [
            "Original loaded image without any processing.",
            "Image with Area of Interest applied. Regions outside the 4-point polygon are blacked out.",
            "Rotate and/or flip the masked image before further processing.",
            "Image converted to grayscale for processing.",
            "Sobel gradient (elevation map) computed. High gradient values form barriers between regions.",
            "PBF engine: illumination flattened (large-sigma background division) and bilateral-denoised. "
            "The cleaned-up grayscale image below is what continues into Step 11 onward.",
            "PBF engine: fine and coarse Difference-of-Gaussians bands computed on the denoised image "
            "(visualized here as a diverging colormap). Feeds the watershed/shape stages below.",
            "PBF engine: adaptive-threshold + watershed segmentation applied per DoG band "
            "(bright and dark polarity).",
            "PBF engine: candidate regions filtered by area, circularity, solidity, aspect ratio "
            "and convexity.",
            "PBF engine: full-extent h-dome band added for continuity across low-contrast/large defects.",
            "PBF engine: minute (sub-threshold) defect candidates rescued via local-contrast z-score "
            "validation, if enabled. This is the PBF engine's own combined bright/dark result, shown "
            "for reference only -- it is not used by the steps below.",
            "Markers built as one connected-component id per below-low-threshold (dark) or "
            "above-high-threshold (bright) blob, so each defect region grows as a single, fully "
            "segmented watershed seed instead of fragmenting along internal intensity variation.",
            "Watershed algorithm floods elevation map from markers. Boundaries marked in red.",
            "Morphological closing to fill small holes and connect nearby objects.",
            "Morphological opening to remove small noise and separate touching objects.",
            "Binary fill holes removes small holes in detected foreground regions.",
            "Connected component labeling identifies individual objects. Small objects filtered out.",
            "Final result with detected segments colored in red.",
            "Perspective warp: ROI polygon corners mapped to a flat rectangle for top-down indicator view."
        ]

        self.step_name_label.config(text=step_names[self.current_step])
        self.step_desc_label.config(text=step_descriptions[self.current_step])
        self.progress_label.config(text=f"Step {self.current_step} / 18")

        # Hide placeholder
        self._img_placeholder.place_forget()

        # Display image
        image = self.step_images[self.current_step]
        pil_img = Image.fromarray(image)
        new_width = int(pil_img.width * self.tab2_zoom_level)
        new_height = int(pil_img.height * self.tab2_zoom_level)
        pil_img = pil_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        self.tab2_photo = ImageTk.PhotoImage(pil_img)

        self.tab2_canvas.delete("all")
        self.tab2_canvas.create_image(0, 0, anchor='nw', image=self.tab2_photo)
        self.tab2_canvas.configure(scrollregion=self.tab2_canvas.bbox("all"))

        # Update parameter controls
        self.update_parameter_controls()

        # Update navigation buttons
        self.prev_button.config(state='normal' if self.current_step > 0 else 'disabled')
        self.next_button.config(state='normal' if self.current_step < 20 else 'disabled')

        # Update step pills
        self._update_step_pills()

    def _display_step1_drawing(self):
        """Render Step 1 interactive ROI drawing on the main tab2 canvas."""
        step_names = ["Step 0: Original Image",
                      "Step 1: RoI Selection (Draw Polygon)",]
        self.step_name_label.config(text="Step 1: RoI Selection (Draw Polygon)")
        self.step_desc_label.config(
            text="Click on the image to place polygon points. "
                 "Click near the first point (green circle) to close the polygon.")
        self.progress_label.config(text="Step 1 / 18")
        self._img_placeholder.place_forget()

        # Draw original image with polygon overlay
        display_img = self.tab2_image.copy()
        pts = self.step1_polygon_points
        zoom = self.tab2_zoom_level

        if len(pts) > 0:
            # Draw lines between consecutive points
            for i in range(len(pts) - 1):
                p1 = (int(pts[i][0] * zoom), int(pts[i][1] * zoom))
                p2 = (int(pts[i+1][0] * zoom), int(pts[i+1][1] * zoom))
                cv2.line(display_img, pts[i], pts[i+1], (0, 255, 0), 2)
            if self.step1_polygon_closed:
                cv2.line(display_img, pts[-1], pts[0], (0, 255, 0), 2)
                # Fill polygon overlay semi-transparent style (solid tint)
                overlay = display_img.copy()
                pts_arr = np.array(pts, dtype=np.int32)
                cv2.fillPoly(overlay, [pts_arr], (0, 255, 0))
                cv2.addWeighted(overlay, 0.15, display_img, 0.85, 0, display_img)
                cv2.polylines(display_img, [pts_arr], True, (0, 255, 0), 2)
            # Draw point circles
            for idx, pt in enumerate(pts):
                color = (255, 215, 0) if idx == 0 else (255, 0, 0)
                cv2.circle(display_img, pt, 7, color, -1)
                cv2.circle(display_img, pt, 8, (255, 255, 255), 2)
                cv2.putText(display_img, str(idx + 1), (pt[0]+10, pt[1]-6),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)

        pil_img = Image.fromarray(display_img)
        new_width  = int(pil_img.width  * self.tab2_zoom_level)
        new_height = int(pil_img.height * self.tab2_zoom_level)
        pil_img = pil_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        self.tab2_photo = ImageTk.PhotoImage(pil_img)

        self.tab2_canvas.delete("all")
        self.tab2_canvas.create_image(0, 0, anchor='nw', image=self.tab2_photo)
        self.tab2_canvas.configure(scrollregion=self.tab2_canvas.bbox("all"))

        # Update right panel controls for step 1
        self.update_parameter_controls()

        # Nav buttons
        self.prev_button.config(state='normal')
        self.next_button.config(state='normal')
        self._update_step_pills()

        # Update info label
        if self.step1_polygon_closed:
            self.tab2_info_label.config(
                text=f"Polygon closed with {len(pts)} points. "
                     f"Coordinates auto-saved. Click Next to run pipeline.")
        elif len(pts) == 0:
            self.tab2_info_label.config(
                text="Step 1: Click on the image to place ROI polygon points.")
        elif len(pts) < 3:
            self.tab2_info_label.config(
                text=f"Points placed: {len(pts)}. Need at least 3 points.")
        else:
            self.tab2_info_label.config(
                text=f"Points placed: {len(pts)}. Click near point 1 (gold circle) to close polygon.")

    def update_step2_rotate(self, rot_var):
        """Update step 2 rotation angle"""
        try:
            value = int(rot_var.get())
            value = max(-180, min(180, value))
            rot_var.set(value)
            self.params['step_2_rotate_flip']['rotate'] = value
            self.process_all_steps()
            self.display_current_step()
        except ValueError:
            rot_var.set(self.params['step_2_rotate_flip']['rotate'])

    def update_step2_flip(self, flip_h_var, flip_v_var):
        """Update step 2 flip flags"""
        if flip_h_var is not None:
            self.params['step_2_rotate_flip']['flip_h'] = flip_h_var.get()
        if flip_v_var is not None:
            self.params['step_2_rotate_flip']['flip_v'] = flip_v_var.get()
        self.process_all_steps()
        self.display_current_step()

    def update_step11_markers(self, low_var, high_var):
        """Update step 11 (histogram markers) low/high threshold parameters"""
        try:
            if low_var:
                value = max(0, min(255, int(low_var.get())))
                low_var.set(value)
                self.params['step_11_markers']['low_threshold'] = value
            if high_var:
                value = max(0, min(255, int(high_var.get())))
                high_var.set(value)
                self.params['step_11_markers']['high_threshold'] = value
            self.process_all_steps()
            self.display_current_step()
        except ValueError:
            if low_var:
                low_var.set(self.params['step_11_markers']['low_threshold'])
            if high_var:
                high_var.set(self.params['step_11_markers']['high_threshold'])

    def update_step13_iterations(self, iter_var):
        """Update step 13 morphological close iterations"""
        try:
            value = max(1, min(10, int(iter_var.get())))
            iter_var.set(value)
            self.params['step_13_morph_close']['iterations'] = value
            self.process_all_steps()
            self.display_current_step()
        except ValueError:
            iter_var.set(self.params['step_13_morph_close']['iterations'])

    def update_step14_iterations(self, iter_var):
        """Update step 14 morphological open iterations"""
        try:
            value = max(1, min(10, int(iter_var.get())))
            iter_var.set(value)
            self.params['step_14_morph_open']['iterations'] = value
            self.process_all_steps()
            self.display_current_step()
        except ValueError:
            iter_var.set(self.params['step_14_morph_open']['iterations'])

    def update_step16_size(self, size_var):
        """Update step 16 minimum size"""
        try:
            value = max(0, min(200, int(size_var.get())))
            size_var.set(value)
            self.params['step_16_labeling']['min_size'] = value
            self.process_all_steps()
            self.display_current_step()
        except ValueError:
            size_var.set(self.params['step_16_labeling']['min_size'])

    def update_step17_min_area(self, area_var):
        """Update step 17 minimum area"""
        try:
            value = max(0, min(1500, int(area_var.get())))
            area_var.set(value)
            self.params['step_17_final']['min_area'] = value
            self.process_all_steps()
            self.display_current_step()
        except ValueError:
            area_var.set(self.params['step_17_final']['min_area'])

    def update_step17_max_area(self, area_var):
        """Update step 17 maximum area"""
        try:
            value = max(1000, min(50000, int(area_var.get())))
            area_var.set(value)
            self.params['step_17_final']['max_area'] = value
            self.process_all_steps()
            self.display_current_step()
        except ValueError:
            area_var.set(self.params['step_17_final']['max_area'])

    def tab2_save_config(self):
        """Save current configuration to JSON.
           Defaults to the same folder as the auto-saved ROI JSON."""
        if self.tab2_roi_points is None:
            messagebox.showwarning("Warning",
                "No ROI defined yet. Please complete Step 1 ROI drawing first.")
            return

        # Default save directory = same as ROI auto-save (next to image)
        init_dir = getattr(self, '_roi_save_dir', None)
        if init_dir is None and self.tab2_image_path:
            init_dir = os.path.dirname(os.path.abspath(self.tab2_image_path))

        img_stem = Path(self.tab2_image_path).stem if self.tab2_image_path else "config"
        default_name = f"{img_stem}_config.json"

        save_path = filedialog.asksaveasfilename(
            title="Save Configuration",
            initialdir=init_dir,
            initialfile=default_name,
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )

        if save_path:
            data = {
                "image_path": self.tab2_image_path,
                "polygon_points": self.tab2_roi_points.tolist(),
                "pipeline_params": self.params
            }

            with open(save_path, 'w') as f:
                json.dump(data, f, indent=4)

            # ── Also write a copy to configurations/conf.json so Batch tab
            #    can auto-load it on next startup ──────────────────────────
            try:
                conf_dir = Path(__file__).resolve().parent / 'configurations'
                conf_dir.mkdir(exist_ok=True)
                with open(conf_dir / 'conf.json', 'w') as _cf:
                    json.dump(data, _cf, indent=4)
            except Exception:
                pass  # never block the main save if this fails

            messagebox.showinfo("Success", f"Configuration saved to {save_path}")

    def tab2_load_config(self):
        """Load configuration from JSON.
        When polygon_points are present, pre-loads them into the Step 1 drawing
        state so that clicking 'Start Processing' will show the saved polygon
        in Step 1 rather than an empty canvas.
        """
        file_path = filedialog.askopenfilename(
            title="Load Configuration",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )

        if file_path:
            with open(file_path, 'r') as f:
                data = json.load(f)

            # Load ROI points into BOTH the roi_points array AND the Step 1
            # polygon drawing state so Start Processing can restore them.
            if 'polygon_points' in data:
                pts = data['polygon_points']
                self.tab2_roi_points       = np.array(pts, dtype=np.int32)
                # Pre-fill Step 1 drawing state
                self.step1_polygon_points  = [tuple(p) for p in pts]
                self.step1_polygon_closed  = True
            else:
                # Config has no polygon   clear any previously loaded ROI
                self.tab2_roi_points      = None
                self.step1_polygon_points = []
                self.step1_polygon_closed = False

            # Load pipeline parameters.
            # REGRESSION FIX (R6): merge onto defaults rather than replace
            # outright -- see _merge_pipeline_params for why.
            if 'pipeline_params' in data:
                self.params = self._merge_pipeline_params(data['pipeline_params'])

            messagebox.showinfo("Success", "Configuration loaded successfully")
            self.tab2_info_label.config(
                text=f"Configuration loaded "
                     f"({'ROI ready – click Start Processing to review in Step 1' if self.tab2_roi_points is not None else 'No ROI in file – draw ROI in Step 1'}).")

