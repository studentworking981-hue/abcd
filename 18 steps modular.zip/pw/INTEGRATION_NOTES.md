# Integration Summary — PBF Engine → Indicator Detection

## What changed
- Pipeline renumbered: old Step 5–14 → Step 11–20 (Step 2–4 untouched).
- New Steps 5–10 inserted, ported unchanged from TRY1's PBF engine
  (`processing/pbf_defect.py`, byte-for-byte copy of `pbf_pipeline.py`):
  - Step 5 — Illumination & Denoise
  - Step 6 — Multi-Scale DoG
  - Step 7 — Sensitivity & Watershed
  - Step 8 — Defect Shape Filtering
  - Step 9 — Full-Extent Band & Continuity
  - Step 10 — Minute-Defect Rescue
- All six run as **one** detection pass (`pbf_defect._run_detection`), same
  as in TRY1 — they are not six independent hand-off stages. Only the
  **denoised grayscale image** it produces is passed forward into (renumbered)
  Step 11 onward. Step 11–20 are completely unmodified and unaware the PBF
  stage exists.
- If every one of Steps 5–10 is skipped, the grayscale image passes through
  untouched and the rest of the pipeline behaves exactly as the original
  14-step app did.
- Step 10's skip checkbox is a **true** algorithmic skip (disables
  `micro_rescue_enabled` inside the engine itself). Steps 5–9's skip
  checkboxes fall back to the PBF engine's own default parameters for that
  group rather than disabling a pipeline stage outright — the underlying
  algorithm doesn't have independent on/off points for those stages (see the
  design-decision note below).
- Config load/save, ROI, export, and reports required **no changes** — the
  existing `_merge_pipeline_params` merge logic is already generic and
  back-fills the six new PBF parameter groups with defaults when loading an
  old config file.
- Fixed a pre-existing bug in the exact code block being rewritten: the
  original `step_descriptions` list was one element short of
  `step_names` (a missing comma had silently merged two entries), which
  would have raised `IndexError` on the old Step 14 / new Step 20. Fixed as
  part of reconstructing that list — no other unrelated code was touched.

## Design decision (flagged before building)
TRY1's 6 tabs aren't 6 sequential hand-off steps internally — they're one
atomic detection call. Rather than force an artificial restructuring of your
detection algorithm (which you asked me not to modify), I inserted the
whole engine as one combined stage, displayed as 6 steps in the wizard, and
only forwarded its cleaned-up image downstream. Its own final defect
mask/contours are shown at Step 10 for reference but aren't consumed by
Step 11+.

## Testing performed
- `py_compile` on every modified/new file — clean.
- Direct algorithmic tests of `process_all_steps()` (single image) and
  `tab3_process_single_image()` (batch) across multiple enable/disable
  combinations of the new steps and several old steps — no exceptions, all
  21 step images always populated.
- Old-style config (missing the 6 new keys) loaded through both the batch
  path and the GUI `_merge_pipeline_params` path — defaults backfilled
  correctly, no crash.
- Full headless GUI smoke test (Xvfb): instantiated the real `Application`,
  navigated all 21 steps via `Next`/`Previous`, toggled all 6 new skip
  checkboxes on and off, and ran a save → load config round trip. All clean.

## Not yet done
- I haven't tested against one of your real sample images/ROIs, only a
  synthetic test image — worth a real-image pass before trusting output
  values.
- I didn't visually inspect the new tabs' on-screen layout (only confirmed
  they build and update without exceptions) — worth a quick look for any
  spacing/wrapping issues once you open the app.
