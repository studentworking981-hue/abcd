"""
Powder Bed Fusion (PBF) Metal AM -- Powder-Bed Surface Defect Inspector v4
============================================================================
GUI layer only. All detection logic lives in pbf_pipeline.py and is
imported, never re-implemented here -- this is what guarantees single-image
and batch processing always run the identical pipeline.

WHAT CHANGED IN v4
-------------------
pbf_pipeline.py's detection engine was rewritten to contain no threshold
parameters or threshold-based logic of any kind (see that file's module
docstring for the full rationale) -- every "mean + k*std" / z-score /
adaptive-cutoff slider from v3 has been replaced with a marker-controlled
watershed control of the same *kind* v3 already used for its structural
knobs (`recon_radius`, closing radii): a plain, fixed number the user sets
by hand, never one recomputed from the image's own statistics. Concretely:
  * Tab 3 ("Sensitivity & Watershed" in v3) is now "Marker Generation &
    Watershed": `noise_k_fine` / `noise_k_coarse` (mean+k*std) are gone,
    replaced by `dome_height_fine` / `dome_height_coarse` (morphological
    reconstruction depth) and `basin_merge_radius_fine` / `_coarse`
    (marker-merging radius, replacing the old per-band closing radii).
  * Tab 5 ("Full-Extent Band & Continuity") no longer has an `extent_k`
    z-score-style dial -- just `dome_height_extent` and a matching basin
    merge radius.
  * Tab 6, "Minute-Defect Rescue" in v3 (a z-score re-test against each
    candidate's local neighbourhood), is now "Micro-Scale Marker
    Refinement": a small-scale marker-controlled-watershed band tuned to
    contribute only tiny candidates (small dome height, tight marker
    spacing, small max-area cap) -- no statistical re-validation step.
  * A polygon ROI editor: "Define ROI" opens a click-to-place,
    drag-to-move, right-click-to-delete vertex editor; "Confirm" stores a
    normalized polygon that becomes the processing mask for both the live
    preview and batch/single export.
  * The Raw Input preview panel outlines the active ROI polygon (if any).

TESTING NOTE: this file could not be executed in the sandboxed environment
this was developed in -- neither tkinter nor customtkinter are installed
there, and there is no display server available even if they were, so no
tkinter GUI can be instantiated to click-test it. Every function in
pbf_pipeline.py WAS executed and validated there against synthetic test
scenes (see VALIDATION.md). Please run this file locally and confirm the
ROI editor and the renamed/re-ranged sliders behave as expected -- report
anything odd.
"""

import os
import json
import cv2
import numpy as np
import tkinter as tk
import customtkinter as ctk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import threading
from concurrent.futures import ThreadPoolExecutor

from pbf_pipeline import run_pipeline, dog_to_colormap, perspective_correct, DEFAULT_PARAMS

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")


# ======================================================================
#  Spinbox widget -- unchanged from v2
# ======================================================================

class CTkSpinbox(ctk.CTkFrame):
    def __init__(self, parent, from_val, to_val, current_val, is_float=False, resolution=1, linked_var=None, on_update_callback=None):
        super().__init__(parent, fg_color="transparent")
        self.from_val = from_val
        self.to_val = to_val
        self.is_float = is_float
        self.resolution = resolution
        self.linked_var = linked_var
        self.callback = on_update_callback

        self.btn_down = ctk.CTkButton(self, text="\u25bc", width=28, height=28, font=("Arial", 10),
                                       fg_color="#37474f", hover_color="#263238", command=self.decrement)
        self.btn_down.pack(side=tk.LEFT, padx=2)

        self.entry = ctk.CTkEntry(self, width=65, height=28, font=('Helvetica', 12), justify='center')
        self.entry.insert(0, f"{current_val:.2f}" if self.is_float else str(int(current_val)))
        self.entry.pack(side=tk.LEFT, padx=2)

        self.btn_up = ctk.CTkButton(self, text="\u25b2", width=28, height=28, font=("Arial", 10),
                                     fg_color="#37474f", hover_color="#263238", command=self.increment)
        self.btn_up.pack(side=tk.LEFT, padx=2)

    def get_value(self):
        try:
            return float(self.entry.get()) if self.is_float else int(float(self.entry.get()))
        except ValueError:
            return self.from_val

    def set_value(self, val):
        self.entry.delete(0, tk.END)
        self.entry.insert(0, f"{val:.2f}" if self.is_float else str(int(val)))
        if self.linked_var:
            self.linked_var.set(val)

    def increment(self):
        curr = self.get_value()
        new_val = np.clip(curr + self.resolution, self.from_val, self.to_val)
        self.set_value(new_val)
        if self.callback:
            self.callback()

    def decrement(self):
        curr = self.get_value()
        new_val = np.clip(curr - self.resolution, self.from_val, self.to_val)
        self.set_value(new_val)
        if self.callback:
            self.callback()


# ======================================================================
#  NEW: Polygon ROI editor (Problem 9)
# ======================================================================

class ROIPolygonEditor(ctk.CTkToplevel):
    """Click-to-add / drag-to-move / right-click-to-delete polygon editor.

    Left click on empty canvas   -> add a vertex at that point
    Left click + drag a vertex   -> move that vertex
    Right click near a vertex    -> delete that vertex
    'Clear Points'                -> discard all vertices (start over)
    'Confirm ROI'                 -> apply the polygon (or, if empty,
                                      apply "no ROI restriction")
    'Cancel'                      -> close without changing anything

    Calls `on_confirm(normalized_points_or_None)` exactly once, only if the
    user actually confirms or clears -- Cancel calls nothing.
    """

    HANDLE_RADIUS = 5
    HIT_RADIUS = 10
    MAX_DISPLAY_DIM = 900

    def __init__(self, parent, cv_img_bgr, existing_polygon_norm, on_confirm):
        super().__init__(parent)
        self.title("Define Processing ROI \u2014 click to add points, drag to move, right-click to delete")
        self.on_confirm = on_confirm
        self.dragging_idx = None

        h, w = cv_img_bgr.shape[:2]
        scale = self.MAX_DISPLAY_DIM / float(max(h, w)) if max(h, w) > self.MAX_DISPLAY_DIM else 1.0
        self.disp_w, self.disp_h = max(1, int(w * scale)), max(1, int(h * scale))

        disp_img = cv2.resize(cv_img_bgr, (self.disp_w, self.disp_h), interpolation=cv2.INTER_AREA)
        rgb = cv2.cvtColor(disp_img, cv2.COLOR_BGR2RGB)
        # Kept as an instance attribute -- PhotoImage is garbage-collected
        # (and the canvas goes blank) if no Python reference survives.
        self.tk_photo = ImageTk.PhotoImage(Image.fromarray(rgb))

        self.canvas = tk.Canvas(self, width=self.disp_w, height=self.disp_h,
                                 cursor="tcross", bg="black", highlightthickness=0)
        self.canvas.pack(padx=10, pady=10)
        self.canvas.create_image(0, 0, anchor="nw", image=self.tk_photo)

        if existing_polygon_norm:
            self.points = [(fx * self.disp_w, fy * self.disp_h) for (fx, fy) in existing_polygon_norm]
        else:
            self.points = []

        hint = ctk.CTkLabel(
            self, text="Left-click: add point   |   Drag: move point   |   Right-click: delete point",
            font=('Helvetica', 11, 'italic'), text_color="#90a4ae")
        hint.pack(pady=(0, 5))

        btn_row = ctk.CTkFrame(self, fg_color="transparent")
        btn_row.pack(pady=(0, 10))
        ctk.CTkButton(btn_row, text="Clear Points", fg_color="#546e7a", hover_color="#37474f",
                      command=self.clear_points).pack(side=tk.LEFT, padx=8)
        ctk.CTkButton(btn_row, text="\u2713 Confirm ROI", fg_color="#2e7d32", hover_color="#1b5e20",
                      command=self.confirm).pack(side=tk.LEFT, padx=8)
        ctk.CTkButton(btn_row, text="Cancel", fg_color="#8d1e1e", hover_color="#5c1414",
                      command=self.destroy).pack(side=tk.LEFT, padx=8)

        self.canvas.bind("<Button-1>", self.on_left_click)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)
        self.canvas.bind("<Button-3>", self.on_right_click)

        self.redraw()
        self.grab_set()  # modal-ish: keep focus on the editor while it's open

    def find_nearest_point(self, x, y):
        best_idx, best_dist = None, self.HIT_RADIUS
        for i, (px, py) in enumerate(self.points):
            d = ((px - x) ** 2 + (py - y) ** 2) ** 0.5
            if d <= best_dist:
                best_dist, best_idx = d, i
        return best_idx

    def on_left_click(self, event):
        idx = self.find_nearest_point(event.x, event.y)
        if idx is not None:
            self.dragging_idx = idx
        else:
            self.points.append((event.x, event.y))
            self.redraw()

    def on_drag(self, event):
        if self.dragging_idx is not None:
            x = min(max(event.x, 0), self.disp_w)
            y = min(max(event.y, 0), self.disp_h)
            self.points[self.dragging_idx] = (x, y)
            self.redraw()

    def on_release(self, _event):
        self.dragging_idx = None

    def on_right_click(self, event):
        idx = self.find_nearest_point(event.x, event.y)
        if idx is not None:
            del self.points[idx]
            self.redraw()

    def redraw(self):
        self.canvas.delete("roi_shape")
        if len(self.points) >= 3:
            flat = [c for pt in self.points for c in pt]
            self.canvas.create_polygon(flat, outline="#00e5ff", fill="#00e5ff", stipple="gray12",
                                        width=2, tags="roi_shape")
        elif len(self.points) == 2:
            flat = [c for pt in self.points for c in pt]
            self.canvas.create_line(flat, fill="#00e5ff", width=2, tags="roi_shape")
        for (x, y) in self.points:
            r = self.HANDLE_RADIUS
            self.canvas.create_oval(x - r, y - r, x + r, y + r, fill="#ff4081",
                                     outline="white", tags="roi_shape")

    def clear_points(self):
        self.points = []
        self.redraw()

    def confirm(self):
        if len(self.points) == 0:
            self.on_confirm(None)  # explicit clear -- no ROI restriction
            self.destroy()
            return
        if len(self.points) < 3:
            messagebox.showwarning("ROI", "Place at least 3 points to define a polygon (or clear all points for no ROI restriction).")
            return
        norm = [(x / self.disp_w, y / self.disp_h) for (x, y) in self.points]
        self.on_confirm(norm)
        self.destroy()


# ======================================================================
#  Main application window
# ======================================================================

class PBFInspectorWorkstation(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("PBF Powder-Bed Inspection Workstation \u2014 Marker-Controlled Watershed Engine v4 (No Thresholds)")
        self.geometry("1650x1040")
        self.image_path = None
        self.folder_path = None
        self.max_display_dim = 420
        self.updating_ui = False
        self.params = {}
        self.roi_polygon = None  # normalized (x_frac, y_frac) points, or None = no restriction

        self.setup_ui_architecture()

    # ---------------- UI construction ----------------

    def setup_ui_architecture(self):
        top_bar = ctk.CTkFrame(self, height=60, corner_radius=0)
        top_bar.pack(side=tk.TOP, fill=tk.X)

        load_btn = ctk.CTkButton(top_bar, text="\U0001F4C2 Load Single Image", command=self.load_image_action,
                                  font=('Helvetica', 12, 'bold'), fg_color="#0288d1", hover_color="#01579b")
        load_btn.pack(side=tk.LEFT, padx=15, pady=10)

        load_folder_btn = ctk.CTkButton(top_bar, text="\U0001F4C1 Load Batch Folder", command=self.load_folder_action,
                                         font=('Helvetica', 12, 'bold'), fg_color="#ff8f00", hover_color="#c67100")
        load_folder_btn.pack(side=tk.LEFT, padx=10, pady=10)

        roi_btn = ctk.CTkButton(top_bar, text="\U0001F53A Define ROI", command=self.open_roi_editor,
                                 font=('Helvetica', 12, 'bold'), fg_color="#6a1b9a", hover_color="#4a148c")
        roi_btn.pack(side=tk.LEFT, padx=10, pady=10)

        clear_roi_btn = ctk.CTkButton(top_bar, text="\u2715 Clear ROI", command=self.clear_roi,
                                       font=('Helvetica', 12), fg_color="#546e7a", hover_color="#37474f", width=90)
        clear_roi_btn.pack(side=tk.LEFT, padx=(0, 10), pady=10)

        self.path_lbl = ctk.CTkLabel(top_bar, text="No source files loaded.", font=('Helvetica', 12, 'italic'), text_color="#90a4ae")
        self.path_lbl.pack(side=tk.LEFT, padx=15)

        self.viewport_frame = ctk.CTkFrame(self, corner_radius=10, fg_color="#1e1e1e")
        self.viewport_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=15, pady=10)

        for i in range(6):
            self.viewport_frame.columnconfigure(i, weight=1, uniform="viewport")
        self.viewport_frame.rowconfigure(1, weight=1)

        titles = [
            "1. Raw Input (ROI outlined)",
            "2. Illumination-Normalized",
            "3. DoG Response (warm=bright / cool=dark)",
            "4. Bright Defects (Red)",
            "5. Dark Defects (Red)",
            "6. Unified Output (Bright=Red, Dark=Orange)",
        ]
        self.view_labels = []
        for i, t in enumerate(titles):
            lbl = ctk.CTkLabel(self.viewport_frame, text=t, font=('Helvetica', 11, 'bold'), text_color="white")
            lbl.grid(row=0, column=i, pady=(10, 5), sticky="ew")
            view = ctk.CTkLabel(self.viewport_frame, text="Awaiting Data...", text_color="#616161")
            view.grid(row=1, column=i, padx=3, pady=5, sticky="nsew")
            self.view_labels.append(view)

        control_panel = ctk.CTkFrame(self, height=400)
        control_panel.pack(side=tk.BOTTOM, fill=tk.X, padx=15, pady=15)

        self.tabview = ctk.CTkTabview(control_panel, height=380)
        self.tabview.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=5)

        self.tab_illum = self.tabview.add(" Tab 1 \u2014 Illumination & Denoise ")
        self.tab_dog = self.tabview.add(" Tab 2 \u2014 Multi-Scale Gradient Bands ")
        self.tab_sens = self.tabview.add(" Tab 3 \u2014 Marker Generation & Watershed ")
        self.tab_filter = self.tabview.add(" Tab 4 \u2014 Defect Shape Filtering ")
        self.tab_extent = self.tabview.add(" Tab 5 \u2014 Full-Extent Band & Continuity ")
        self.tab_rescue = self.tabview.add(" Tab 6 \u2014 Micro-Scale Marker Refinement ")

        self.build_tabs_layout()

        right_bar = ctk.CTkFrame(control_panel, width=240, fg_color="transparent")
        right_bar.pack(side=tk.RIGHT, fill=tk.Y, padx=10, pady=10)

        self.export_btn = ctk.CTkButton(right_bar, text="\U0001F4BE Export Output\n(Single or Batch Folder)", command=self.start_async_export,
                                         font=('Helvetica', 12, 'bold'), fg_color="#2e7d32", hover_color="#1b5e20")
        self.export_btn.pack(fill=tk.BOTH, expand=True, pady=10)

    def create_parameter_row(self, parent, key, label_text, from_val, to_val, current_val, row_idx, is_float=False, resolution=1):
        lbl = ctk.CTkLabel(parent, text=label_text, font=('Helvetica', 11), anchor='w')
        lbl.grid(row=row_idx, column=0, sticky='w', pady=3, padx=10)

        var = tk.DoubleVar(value=current_val) if is_float else tk.IntVar(value=current_val)
        self.params[key] = var

        slider = ctk.CTkSlider(parent, from_=from_val, to=to_val, number_of_steps=max(1, int((to_val - from_val) / resolution)), variable=var)
        slider.grid(row=row_idx, column=1, sticky='ew', padx=20, pady=3)

        spinbox = CTkSpinbox(parent, from_val, to_val, current_val, is_float, resolution, linked_var=var, on_update_callback=self.trigger_pipeline_refresh)
        spinbox.grid(row=row_idx, column=2, padx=10, pady=3)

        slider.bind("<ButtonRelease-1>", lambda event: self.sync_slider_to_spinbox(var, spinbox))
        spinbox.entry.bind("<Return>", lambda event: self.sync_spinbox_to_slider(spinbox, var, from_val, to_val))

        parent.columnconfigure(1, weight=1)
        return var, spinbox

    def create_toggle_row(self, parent, key, label_text, current_val, row_idx):
        """New: boolean on/off row (used for micro_enabled). Registered
        in the same self.params dict as the numeric sliders -- BooleanVar.get()
        also returns a plain value, so get_current_params_dict() needs no
        special-casing."""
        lbl = ctk.CTkLabel(parent, text=label_text, font=('Helvetica', 11), anchor='w')
        lbl.grid(row=row_idx, column=0, sticky='w', pady=3, padx=10)
        var = tk.BooleanVar(value=current_val)
        self.params[key] = var
        switch = ctk.CTkSwitch(parent, text="", variable=var, command=self.trigger_pipeline_refresh)
        switch.grid(row=row_idx, column=1, sticky='w', padx=20, pady=3)
        return var

    def sync_slider_to_spinbox(self, var, spinbox):
        if self.updating_ui:
            return
        self.updating_ui = True
        spinbox.set_value(var.get())
        self.updating_ui = False
        self.trigger_pipeline_refresh()

    def sync_spinbox_to_slider(self, spinbox, var, from_val, to_val):
        if self.updating_ui:
            return
        self.updating_ui = True
        val = spinbox.get_value()
        if from_val <= val <= to_val:
            var.set(val)
            self.updating_ui = False
            self.trigger_pipeline_refresh()
            return
        else:
            messagebox.showwarning("Out of Bounds", f"Value must be between {from_val} and {to_val}")
        self.updating_ui = False

    def build_tabs_layout(self):
        dp = DEFAULT_PARAMS

        # Tab 1 -- Illumination & Denoise
        self.create_parameter_row(self.tab_illum, "bg_sigma", "Background Gaussian Sigma (Illumination Scale):", 10.0, 150.0, dp["bg_sigma"], 0, is_float=True, resolution=5.0)
        self.create_parameter_row(self.tab_illum, "bilat_d", "Bilateral Filter Diameter:", 1, 25, dp["bilat_d"], 1, resolution=1)
        self.create_parameter_row(self.tab_illum, "bilat_sc", "Bilateral Sigma Color:", 5.0, 200.0, dp["bilat_sc"], 2, is_float=True, resolution=5.0)
        self.create_parameter_row(self.tab_illum, "bilat_ss", "Bilateral Sigma Space:", 5.0, 200.0, dp["bilat_ss"], 3, is_float=True, resolution=5.0)

        # Tab 2 -- Multi-Scale DoG
        self.create_parameter_row(self.tab_dog, "fine_sigma1", "Fine Band Sigma 1 (Small Defect Inner Scale):", 0.3, 5.0, dp["fine_sigma1"], 0, is_float=True, resolution=0.1)
        self.create_parameter_row(self.tab_dog, "fine_sigma2", "Fine Band Sigma 2 (Small Defect Outer Scale):", 1.0, 10.0, dp["fine_sigma2"], 1, is_float=True, resolution=0.2)
        self.create_parameter_row(self.tab_dog, "coarse_sigma1", "Coarse Band Sigma 1 (Large Defect Inner Scale):", 1.0, 20.0, dp["coarse_sigma1"], 2, is_float=True, resolution=0.5)
        self.create_parameter_row(self.tab_dog, "coarse_sigma2", "Coarse Band Sigma 2 (Large Defect Outer Scale):", 5.0, 60.0, dp["coarse_sigma2"], 3, is_float=True, resolution=1.0)
        self.create_parameter_row(self.tab_dog, "recon_radius", "Speckle Reconstruction Radius (px):", 0, 5, dp["recon_radius"], 4, resolution=1)

        # Tab 3 -- Marker Generation & Watershed
        self.create_parameter_row(self.tab_sens, "dome_height_fine", "Fine-Band Marker Dome Height:", 1.0, 60.0, dp["dome_height_fine"], 0, is_float=True, resolution=1.0)
        self.create_parameter_row(self.tab_sens, "dome_height_coarse", "Coarse-Band Marker Dome Height:", 1.0, 60.0, dp["dome_height_coarse"], 1, is_float=True, resolution=1.0)
        self.create_parameter_row(self.tab_sens, "min_component_area_fine", "Fine-Band Min Component Area (px):", 1, 100, dp["min_component_area_fine"], 2, resolution=1)
        self.create_parameter_row(self.tab_sens, "min_component_area_coarse", "Coarse-Band Min Component Area (px):", 5, 500, dp["min_component_area_coarse"], 3, resolution=5)
        self.create_parameter_row(self.tab_sens, "local_max_min_dist", "Watershed Marker Min Distance (px):", 1, 30, dp["local_max_min_dist"], 4, resolution=1)
        self.create_parameter_row(self.tab_sens, "basin_merge_radius_fine", "Fine-Band Basin Merge Radius (px):", 0, 8, dp["basin_merge_radius_fine"], 5, resolution=1)
        self.create_parameter_row(self.tab_sens, "basin_merge_radius_coarse", "Coarse-Band Basin Merge Radius (px):", 0, 8, dp["basin_merge_radius_coarse"], 6, resolution=1)
        self.create_parameter_row(self.tab_sens, "compactness", "Watershed Compactness:", 0.0, 5.0, dp["compactness"], 7, is_float=True, resolution=0.1)

        # Tab 4 -- Defect Shape Filtering
        self.create_parameter_row(self.tab_filter, "min_area", "Minimum Area (Pixels):", 1, 5000, dp["min_area"], 0, resolution=1)
        self.create_parameter_row(self.tab_filter, "max_area", "Maximum Area (Pixels):", 100, 50000, dp["max_area"], 1, resolution=100)
        self.create_parameter_row(self.tab_filter, "min_circularity", "Minimum Circularity:", 0.0, 1.0, dp["min_circularity"], 2, is_float=True, resolution=0.05)
        self.create_parameter_row(self.tab_filter, "min_solidity", "Minimum Solidity:", 0.0, 1.0, dp["min_solidity"], 3, is_float=True, resolution=0.05)
        self.create_parameter_row(self.tab_filter, "max_aspect_ratio", "Maximum Aspect Ratio:", 1.0, 20.0, dp["max_aspect_ratio"], 4, is_float=True, resolution=0.5)
        self.create_parameter_row(self.tab_filter, "min_convexity", "Minimum Convexity:", 0.0, 1.0, dp["min_convexity"], 5, is_float=True, resolution=0.05)

        # Tab 5 -- Full-Extent Band & Continuity (large homogeneous defects
        # keep their full extent instead of only a detected rim)
        self.create_parameter_row(self.tab_extent, "dome_height_extent", "Full-Extent Marker Dome Height:", 1.0, 120.0, dp["dome_height_extent"], 0, is_float=True, resolution=1.0)
        self.create_parameter_row(self.tab_extent, "min_component_area_extent", "Full-Extent Min Component Area (px):", 10, 2000, dp["min_component_area_extent"], 1, resolution=10)
        self.create_parameter_row(self.tab_extent, "local_max_min_dist_extent", "Full-Extent Watershed Marker Min Distance (px):", 1, 60, dp["local_max_min_dist_extent"], 2, resolution=1)
        self.create_parameter_row(self.tab_extent, "basin_merge_radius_extent", "Full-Extent Basin Merge Radius (px):", 0, 12, dp["basin_merge_radius_extent"], 3, resolution=1)

        # Tab 6 -- Micro-Scale Marker Refinement (minute defects: a small
        # dome height / tight marker spacing / small max-area cap so this
        # band only ever contributes tiny candidates)
        self.create_toggle_row(self.tab_rescue, "micro_enabled", "Enable Micro-Scale Marker Band:", dp["micro_enabled"], 0)
        self.create_parameter_row(self.tab_rescue, "dome_height_micro", "Micro-Band Marker Dome Height:", 1.0, 40.0, dp["dome_height_micro"], 1, is_float=True, resolution=1.0)
        self.create_parameter_row(self.tab_rescue, "min_component_area_micro", "Micro-Band Min Component Area (px):", 1, 50, dp["min_component_area_micro"], 2, resolution=1)
        self.create_parameter_row(self.tab_rescue, "local_max_min_dist_micro", "Micro-Band Watershed Marker Min Distance (px):", 1, 10, dp["local_max_min_dist_micro"], 3, resolution=1)
        self.create_parameter_row(self.tab_rescue, "basin_merge_radius_micro", "Micro-Band Basin Merge Radius (px):", 0, 5, dp["basin_merge_radius_micro"], 4, resolution=1)
        self.create_parameter_row(self.tab_rescue, "micro_max_area", "Max Area Considered 'Minute' (px):", 5, 300, dp["micro_max_area"], 5, resolution=5)

    # ---------------- ROI editor wiring (Problem 9) ----------------

    def open_roi_editor(self):
        if not self.image_path:
            messagebox.showwarning("Define ROI", "Load a single image or batch folder first.")
            return
        img = cv2.imread(self.image_path)
        if img is None:
            messagebox.showerror("Define ROI", f"Could not read image:\n{self.image_path}")
            return
        img = perspective_correct(img)
        ROIPolygonEditor(self, img, self.roi_polygon, self.on_roi_confirmed)

    def on_roi_confirmed(self, normalized_points_or_none):
        self.roi_polygon = normalized_points_or_none
        self.trigger_pipeline_refresh()

    def clear_roi(self):
        self.roi_polygon = None
        self.trigger_pipeline_refresh()

    # ---------------- File loading ----------------

    def load_image_action(self):
        file_path = filedialog.askopenfilename(filetypes=[("All Image Formats", "*.jpg *.jpeg *.png *.bmp *.tiff *.pgm")])
        if file_path:
            self.folder_path = None
            self.image_path = file_path
            self.path_lbl.configure(text=os.path.basename(file_path))
            self.trigger_pipeline_refresh()

    def load_folder_action(self):
        folder_path = filedialog.askdirectory(title="Select Batch Folder of AM Images")
        if folder_path:
            self.image_path = None
            self.folder_path = folder_path
            files = [f for f in os.listdir(folder_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp'))]
            self.path_lbl.configure(text=f"Batch Folder: {os.path.basename(folder_path)} ({len(files)} target images)")
            if len(files) > 0:
                self.image_path = os.path.join(folder_path, files[0])
                self.trigger_pipeline_refresh()

    def get_current_params_dict(self):
        return {k: v.get() for k, v in self.params.items()}

    # ---------------- Live preview ----------------

    def trigger_pipeline_refresh(self):
        if not self.image_path or self.updating_ui:
            return
        p_dict = self.get_current_params_dict()
        result = run_pipeline(self.image_path, self.max_display_dim, p_dict, roi_polygon=self.roi_polygon)
        if result is not None:
            self.update_native_viewports(result)

    def convert_to_ctk_image(self, cv_img_bgr_or_rgb, source="bgr"):
        if source == "bgr":
            rgb = cv2.cvtColor(cv_img_bgr_or_rgb, cv2.COLOR_BGR2RGB)
        elif source == "gray":
            rgb = cv2.cvtColor(cv_img_bgr_or_rgb, cv2.COLOR_GRAY2RGB)
        else:
            rgb = cv_img_bgr_or_rgb
        h, w = rgb.shape[:2]
        pil_img = Image.fromarray(rgb)
        return ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(w, h))

    def draw_roi_outline(self, img_bgr):
        """NEW: outline the active ROI polygon on the Raw Input panel so the
        current processing mask is visible at a glance while tuning. Purely
        cosmetic -- does not affect any detection result."""
        if not self.roi_polygon or len(self.roi_polygon) < 3:
            return img_bgr
        h, w = img_bgr.shape[:2]
        pts = np.array([(fx * w, fy * h) for (fx, fy) in self.roi_polygon], dtype=np.int32)
        out = img_bgr.copy()
        cv2.polylines(out, [pts], isClosed=True, color=(255, 229, 0), thickness=2)
        return out

    def update_native_viewports(self, result):
        normalized_u8 = np.clip(result["normalized"], 0, 255).astype(np.uint8)
        dog_colored = dog_to_colormap(result["dog"])
        raw_with_roi = self.draw_roi_outline(result["img_disp"])

        panels = [
            self.convert_to_ctk_image(raw_with_roi, source="bgr"),
            self.convert_to_ctk_image(normalized_u8, source="gray"),
            self.convert_to_ctk_image(dog_colored, source="bgr"),
            self.convert_to_ctk_image(result["white_display"], source="rgb"),
            self.convert_to_ctk_image(result["dark_display"], source="rgb"),
            self.convert_to_ctk_image(result["final_output"], source="rgb"),
        ]
        for lbl, img in zip(self.view_labels, panels):
            lbl.configure(image=img, text="")
            lbl.image = img

    # ---------------- Export ----------------

    def start_async_export(self):
        if not self.image_path and not self.folder_path:
            messagebox.showwarning("Export Error", "Please load a single image or batch folder first.")
            return

        selected_parent_dir = filedialog.askdirectory(title="Select Destination Folder")
        if not selected_parent_dir:
            return

        self.export_btn.configure(state="disabled", text="\u23f3 Running High-Res Batch Pool...")

        export_thread = threading.Thread(target=self.background_export_worker, args=(selected_parent_dir,))
        export_thread.daemon = True
        export_thread.start()

    def background_export_worker(self, target_base_path):
        try:
            p_dict = self.get_current_params_dict()
            roi_polygon = self.roi_polygon  # same ROI for every file in a batch (Problem 10):
            # a fixed PBF camera rig means every frame in a batch shares the
            # same framing, so one polygon drawn once is valid for all of
            # them. If a given rig's framing varies image-to-image, redraw
            # the ROI between batches rather than relying on one polygon
            # for a mixed-framing folder.

            if self.folder_path:
                output_dir = os.path.join(target_base_path, "Output_Images_DoG_Watershed")
                os.makedirs(output_dir, exist_ok=True)
                files_to_process = [
                    os.path.join(self.folder_path, f)
                    for f in os.listdir(self.folder_path)
                    if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp'))
                ]
            else:
                base_filename = os.path.splitext(os.path.basename(self.image_path))[0]
                output_dir = os.path.join(target_base_path, f"pbf_inspection_{base_filename}_outputs")
                os.makedirs(output_dir, exist_ok=True)
                files_to_process = [self.image_path]

            def process_single_file(file_path):
                file_name_only = os.path.splitext(os.path.basename(file_path))[0]
                r = run_pipeline(file_path, None, p_dict, roi_polygon=roi_polygon)
                if r is None:
                    return

                if self.folder_path:
                    cv2.imwrite(os.path.join(output_dir, f"{file_name_only}_segmented.png"),
                                cv2.cvtColor(r["final_output"], cv2.COLOR_RGB2BGR))
                else:
                    # Full stage dump -- satisfies "visualization for every stage" (spec item 11)
                    cv2.imwrite(os.path.join(output_dir, "01_original.png"), cv2.imread(file_path))
                    cv2.imwrite(os.path.join(output_dir, "02_illumination_normalized.png"),
                                np.clip(r["normalized"], 0, 255).astype(np.uint8))
                    cv2.imwrite(os.path.join(output_dir, "03_background_estimate.png"),
                                np.clip(r["background"], 0, 255).astype(np.uint8))
                    cv2.imwrite(os.path.join(output_dir, "04_denoised.png"),
                                np.clip(r["denoised"], 0, 255).astype(np.uint8))
                    cv2.imwrite(os.path.join(output_dir, "05_dog_combined.png"), dog_to_colormap(r["dog"]))
                    cv2.imwrite(os.path.join(output_dir, "06_dog_fine_band.png"), dog_to_colormap(r["dog_fine"]))
                    cv2.imwrite(os.path.join(output_dir, "07_dog_coarse_band.png"), dog_to_colormap(r["dog_coarse"]))
                    cv2.imwrite(os.path.join(output_dir, "08_bright_defect_mask.png"), r["bright"]["mask"])
                    cv2.imwrite(os.path.join(output_dir, "09_dark_defect_mask.png"), r["dark"]["mask"])
                    cv2.imwrite(os.path.join(output_dir, "10_final_binary_mask.png"), r["final_mask"])
                    cv2.imwrite(os.path.join(output_dir, "10b_roi_mask.png"), r["roi"])
                    cv2.imwrite(os.path.join(output_dir, "11_white_defects_overlay.png"), cv2.cvtColor(r["white_display"], cv2.COLOR_RGB2BGR))
                    cv2.imwrite(os.path.join(output_dir, "12_dark_defects_overlay.png"), cv2.cvtColor(r["dark_display"], cv2.COLOR_RGB2BGR))
                    cv2.imwrite(os.path.join(output_dir, "13_final_overlay.png"), cv2.cvtColor(r["final_output"], cv2.COLOR_RGB2BGR))

                    with open(os.path.join(output_dir, "parameters.json"), "w") as f:
                        json.dump({
                            "configured_parameters": p_dict,
                            "roi_polygon_normalized": roi_polygon,
                            "engine": "dual_polarity_marker_controlled_watershed_v4_no_threshold",
                            "bright_defect_count": len(r["bright"]["contours"]),
                            "dark_defect_count": len(r["dark"]["contours"]),
                        }, f, indent=4)

            with ThreadPoolExecutor() as executor:
                executor.map(process_single_file, files_to_process)

            self.after(0, lambda: self.on_export_complete(output_dir))

        except Exception as e:
            self.after(0, lambda: self.on_export_failed(str(e)))

    def on_export_complete(self, output_dir):
        self.export_btn.configure(state="normal", text="\U0001F4BE Export Output\n(Single or Batch Folder)")
        messagebox.showinfo("Export Successful", f"Operations completed successfully!\nTarget Directory:\n{output_dir}")

    def on_export_failed(self, error_msg):
        self.export_btn.configure(state="normal", text="\U0001F4BE Export Output\n(Single or Batch Folder)")
        messagebox.showerror("Export Error", f"An execution error occurred:\n{error_msg}")


if __name__ == "__main__":
    app = PBFInspectorWorkstation()
    app.mainloop()
