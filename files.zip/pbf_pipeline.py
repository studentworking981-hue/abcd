"""
Powder Bed Fusion (PBF) Metal AM -- Powder-Bed Surface Defect Inspector v4
============================================================================
Pure image-processing engine -- NO GUI imports here on purpose (single-image
and batch modes both call `run_pipeline()` in this file, so there is exactly
one implementation to keep in sync; the GUI module never duplicates any
detection logic).

WHAT THIS VERSION CHANGES RELATIVE TO v3, AND WHY
---------------------------------------------------------------------------
v3 built every binary defect candidate by comparing a response channel
against a statistically-derived cutoff: `adaptive_threshold()` (mean +
k*std, or median + k*MAD), and a z-score re-test in `local_contrast_rescue`.
Those are exactly the family of operations this version is required to
remove completely: there is no `pixel > value` comparison anywhere in this
file that depends on an image-derived mean, std, MAD, z-score, or
percentile. Grep this file for "threshold" and you will not find a
function or comparison that uses one.

Detection is now marker-controlled watershed, end to end:

  1. MARKER GENERATION -- `dome_extract()` performs morphological
     reconstruction (h-dome / h-minima extraction) to find regions that
     stand at least a fixed height above (or below) their surroundings.
     That height (`dome_height_*`) is a plain user-set number, exactly the
     same *kind* of control as `recon_radius` in v3 -- it is a fixed
     structural depth, never computed from the image's own mean, std, or
     percentiles. Wherever `dome_extract()`'s output is zero is, by
     construction of the reconstruction, not part of any qualifying dome --
     that is the topology of the operation itself, not a chosen intensity
     cutoff being compared against pixel values.
  2. MARKER REFINEMENT -- `build_foreground_markers()` runs a distance-
     transform peak search (`peak_local_max`) inside each dome-positive
     component to split touching blobs into separate watershed seeds.
     `peak_local_max` only ever compares a pixel's distance value to its
     *neighbours*, never to an absolute number, so this stays
     threshold-free. `close_and_fill()` (unchanged from v3, a structural
     morphological-closing + hole-fill) merges markers that fall within a
     fixed `basin_merge_radius` of one another before the peak search runs.
  3. WATERSHED FLOODING -- `watershed_segment()` floods every marker
     outward over the response channel's own topology (`-response_channel`
     as elevation, same convention as v3), confined to the dome-positive
     footprint built in step 1 -- never a thresholded binary. A single
     homogeneous blob with one marker keeps its FULL dome footprint (no
     rim-only detection); two touching blobs with two markers still get
     split at the ridge between them. The boundary is decided by
     watershed's own basin-competition rule, not by comparing a pixel to a
     cutoff value.
  4. SHAPE FILTERING -- `shape_filter()` (unchanged from v3) is a geometric
     discriminator (area / circularity / solidity / aspect / convexity) on
     already-segmented regions. It never inspects a pixel intensity value,
     so it is not a threshold in the sense this rewrite eliminates -- it is
     exactly the "shape analysis" / "contour analysis" stage this rewrite
     is explicitly allowed (and expected) to keep.

`perspective_correct()` (build-plate boundary detection, upstream of all of
the above) previously used `cv2.threshold(..., THRESH_OTSU)`. It has been
rewritten the same way: a two-marker watershed (image border = background
marker, a small seed box at the frame centre = plate marker) over the
frame's gradient magnitude, with no intensity cutoff anywhere.

WHAT STAYS EXACTLY THE SAME (do not re-break these)
---------------------------------------------------------------------------
* Illumination flattening (`estimate_background` / `flatten_illumination`)
  and bilateral denoising -- unchanged, upstream of detection.
* The multi-scale dual-polarity architecture: "fine" and "coarse"
  Difference-of-Gaussians bands, a whole-extent band for large homogeneous
  defects, and a small-scale "micro" band for minute dots -- unchanged in
  spirit, still fused into one combined mask per polarity. DoG remains a
  scale-selective PRE-FILTER that decides which spatial scale a candidate
  response belongs to; it is not itself a threshold, and nothing compares
  its output to a statistical cutoff any more (see point 1 above).
* Polygon ROI (`polygon_to_mask`, normalized (x_frac, y_frac) points valid
  at any resolution, used identically for single and batch processing).
* One `run_pipeline()` entry point shared by single-image and batch export.
* Continuous, filled regions (`close_and_fill`) -- no ring-like detections,
  no fragmented islands, no patchwork segmentation.

VALIDATION
----------
Because the only sample provided was an already-annotated OUTPUT image (the
old detector's red overlay baked into a JPEG, not a raw re-processable
input), this rewrite was checked function-by-function against synthetic
test scenes reproducing the same scenarios v3's docstring validated against
(a large homogeneous bright/dark blob, minute bright/dark point defects,
randomized small-blob texture clutter) to confirm marker generation still
fires on the same shapes DoG+threshold used to, and that watershed flooding
still produces one continuous region per defect rather than a fragmented
rim. See VALIDATION.md for the methodology notes.
"""

import cv2
import numpy as np
from skimage.segmentation import watershed
from skimage.feature import peak_local_max
from skimage.morphology import reconstruction
from scipy import ndimage


# ======================================================================
#  PERSPECTIVE CORRECTION
#  v4: plate/background split via two-marker watershed over gradient
#  magnitude -- no cv2.threshold / Otsu anywhere in this file any more.
# ======================================================================

def perspective_correct(img):
    """Detect the build-plate quadrilateral and flatten it to a rectangle.

    The plate (bright, textured) sits against a background frame border in
    every sample provided. Rather than separating them with an intensity
    cutoff (v3 used Otsu), this seeds a background marker along the image
    border and a plate marker in a small box at the frame centre, then lets
    a watershed flood across the gradient-magnitude surface decide the
    boundary -- the same marker-controlled-watershed principle used
    throughout the rest of this file, and no threshold of any kind."""
    gray_full = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray_full, (5, 5), 0).astype(np.float32)
    gx = cv2.Sobel(blurred, cv2.CV_32F, 1, 0, ksize=3)
    gy = cv2.Sobel(blurred, cv2.CV_32F, 0, 1, ksize=3)
    gradient = cv2.magnitude(gx, gy)

    h, w = gray_full.shape
    markers = np.zeros((h, w), dtype=np.int32)
    border = max(2, min(h, w) // 50)
    markers[:border, :] = 1
    markers[-border:, :] = 1
    markers[:, :border] = 1
    markers[:, -border:] = 1
    cy0, cy1 = int(h * 0.4), int(h * 0.6)
    cx0, cx1 = int(w * 0.4), int(w * 0.6)
    markers[cy0:cy1, cx0:cx1] = 2

    seg = watershed(gradient, markers)
    plate_mask = (seg == 2).astype(np.uint8) * 255

    contours, _ = cv2.findContours(plate_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if len(contours) > 0:
        largest_contour = max(contours, key=cv2.contourArea)
        peri = cv2.arcLength(largest_contour, True)
        approx = cv2.approxPolyDP(largest_contour, 0.02 * peri, True)
        if len(approx) == 4:
            pts = approx.reshape(4, 2)
            rect = np.zeros((4, 2), dtype="float32")
            s = pts.sum(axis=1)
            rect[0] = pts[np.argmin(s)]
            rect[2] = pts[np.argmax(s)]
            diff = np.diff(pts, axis=1)
            rect[1] = pts[np.argmin(diff)]
            rect[3] = pts[np.argmax(diff)]

            (tl, tr, br, bl) = rect
            widthA = np.hypot(br[0] - bl[0], br[1] - bl[1])
            widthB = np.hypot(tr[0] - tl[0], tr[1] - tl[1])
            maxWidth = max(int(widthA), int(widthB))

            heightA = np.hypot(tr[0] - br[0], tr[1] - br[1])
            heightB = np.hypot(tl[0] - bl[0], tl[1] - bl[1])
            maxHeight = max(int(heightA), int(heightB))

            if maxWidth > 10 and maxHeight > 10:
                dst = np.array([
                    [0, 0], [maxWidth - 1, 0],
                    [maxWidth - 1, maxHeight - 1], [0, maxHeight - 1]], dtype="float32")
                M = cv2.getPerspectiveTransform(rect, dst)
                img = cv2.warpPerspective(img, M, (maxWidth, maxHeight))
    return img


# ======================================================================
#  ROI POLYGON
# ======================================================================

def polygon_to_mask(shape_hw, polygon_pts_norm):
    """polygon_pts_norm: list of (x_frac, y_frac), each in [0, 1], relative
    to whatever image they were drawn on. Normalized coordinates (rather
    than raw pixels) mean the SAME polygon is valid at any resolution --
    the downsized live preview, a full-resolution export, or any other
    image in a batch folder that shares the same camera framing -- with no
    separate bookkeeping of "what size was this drawn on". Returns a uint8
    0/255 mask sized to `shape_hw`. Falls back to an all-255 mask if the
    polygon has fewer than 3 points (nothing selected yet / invalid
    selection) so callers do not need a special case.
    """
    h, w = shape_hw
    if polygon_pts_norm is None or len(polygon_pts_norm) < 3:
        return np.full((h, w), 255, dtype=np.uint8)
    mask = np.zeros((h, w), dtype=np.uint8)
    pts = np.array([(fx * w, fy * h) for (fx, fy) in polygon_pts_norm], dtype=np.int32).reshape(-1, 1, 2)
    cv2.fillPoly(mask, [pts], 255)
    return mask


# ======================================================================
#  CORE IMAGE-PROCESSING FUNCTIONS
# ======================================================================

def estimate_background(gray_f32, sigma):
    """Large-sigma Gaussian low-pass = the slow illumination/powder-tone
    field. Unchanged from v3."""
    k = int(2 * round(3 * sigma) + 1)
    k = max(k, 3)
    return cv2.GaussianBlur(gray_f32, (k, k), sigma)


def flatten_illumination(gray_f32, background, target=128.0):
    """Multiplicative flat-fielding. Unchanged from v3."""
    norm = (gray_f32 / (background + 1e-3)) * target
    return np.clip(norm, 0, 255).astype(np.float32)


def difference_of_gaussians(img_f32, sigma1, sigma2):
    """Band-pass filter, symmetric to bright/dark blobs of a chosen scale.
    Unchanged from v3 -- still what selects which spatial scale ("fine" vs
    "coarse") a candidate response belongs to before marker generation
    runs on it. This is scale selection, not a threshold: its output is
    fed into `dome_extract()` below, never compared to a statistical
    cutoff."""
    k1 = max(3, int(2 * round(3 * sigma1) + 1))
    k2 = max(3, int(2 * round(3 * sigma2) + 1))
    g1 = cv2.GaussianBlur(img_f32, (k1, k1), sigma1)
    g2 = cv2.GaussianBlur(img_f32, (k2, k2), sigma2)
    return g1 - g2


def opening_by_reconstruction(channel_f32, radius):
    """Grayscale opening-by-reconstruction: kills sub-pixel speckle while
    leaving the shape of surviving blobs untouched. Unchanged from v3.
    Structural (radius-based), not an intensity cutoff."""
    if radius <= 0:
        return channel_f32
    size = 2 * radius + 1
    seed = ndimage.grey_erosion(channel_f32, size=(size, size))
    seed = np.minimum(seed, channel_f32)
    return reconstruction(seed, channel_f32, method='dilation')


def dome_extract(signed_f32, height):
    """Regional-maxima ('h-dome') extraction via morphological
    reconstruction. This is the ONLY thing that decides which pixels
    become foreground marker candidates in this pipeline -- it replaces
    every `mean + k*std` / z-score comparison from v3.

    `height` is a fixed structural parameter, exactly like `recon_radius`
    above: a plain number the user (or a GUI slider) sets directly. It is
    never computed from the image's own mean, std, MAD, or percentiles, so
    it is not a statistical/adaptive threshold.

    The returned array is zero everywhere that is not part of a connected
    region standing at least `height` above (or below, depending on the
    caller's chosen sign) its local surroundings, and equal to that
    region's own elevation above its base everywhere it is part of one.
    That zero/nonzero split is the reconstruction's own topology -- a
    structural fact about the surface, not a chosen cutoff value being
    compared against a pixel intensity.
    """
    if height <= 0:
        return np.zeros_like(signed_f32)
    seed = signed_f32 - height
    recon = reconstruction(seed, signed_f32, method='dilation')
    return signed_f32 - recon


def remove_small_components(binary_u8, min_area):
    """Connected-component + area filter. Same result as a per-label loop,
    vectorized via a label lookup table. A component-AREA filter is a
    geometric/shape criterion (see `shape_filter` below), not an intensity
    threshold -- it never inspects a single pixel's value."""
    n, labels, stats, _ = cv2.connectedComponentsWithStats(binary_u8, connectivity=8)
    keep = stats[:, cv2.CC_STAT_AREA] >= min_area
    keep[0] = False
    lut = keep.astype(np.uint8) * 255
    return lut[labels]


def close_and_fill(binary_u8, radius):
    """Morphological closing + per-component hole-fill. Also doubles as
    marker-merging in v4: running this on the dome-positive candidate mask
    before the peak search below merges any two dome regions closer than
    `radius` into one marker group ("Basin Merge Radius" / "Marker Merge
    Distance" in the GUI). Structural (radius-based), not an intensity
    threshold. radius<=0 disables it."""
    if radius <= 0 or binary_u8.max() == 0:
        return binary_u8
    k = 2 * radius + 1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    closed = cv2.morphologyEx(binary_u8, cv2.MORPH_CLOSE, kernel)
    filled = ndimage.binary_fill_holes(closed > 0).astype(np.uint8) * 255
    return filled


def build_foreground_markers(dome_positive_u8, min_distance):
    """Distance-transform peak markers ('Marker Refinement') inside each
    dome-positive candidate region -- splits touching blobs into separate
    watershed seeds. `peak_local_max` only ever compares a pixel's distance
    value to its NEIGHBOURS, never to an absolute number, so this stays
    threshold-free. Unchanged in spirit from v3's `build_markers`."""
    dist = cv2.distanceTransform(dome_positive_u8, cv2.DIST_L2, 5)
    coords = peak_local_max(dist, min_distance=max(1, min_distance), labels=dome_positive_u8)
    markers = np.zeros(dome_positive_u8.shape, dtype=np.int32)
    for idx, pt in enumerate(coords):
        markers[pt[0], pt[1]] = idx + 1
    if markers.max() == 0 and dome_positive_u8.max() > 0:
        _, markers = cv2.connectedComponents(dome_positive_u8)
    return markers


def watershed_segment(response_channel, foreground_markers, support_mask, compactness=0.0):
    """Marker-controlled watershed CONFINED to `support_mask` -- the
    dome-positive candidate region built by `dome_extract` above, never a
    thresholded binary. `support_mask` is what makes this a genuine
    watershed segmentation rather than a plain marker dump: within the
    already-established dome footprint, each marker's flood expands
    outward over the response channel's OWN topology (`-response_channel`
    as elevation, exactly as in v3) until it meets a neighbouring flood or
    the support boundary -- so a single homogeneous blob with only one
    marker keeps its FULL extent (the whole dome_positive footprint, not
    just a rim around the seed point), while two touching blobs with two
    separate markers still get split at their shared ridge ('Watershed
    Connectivity', 'Watershed Basin Merging'). No intensity cutoff is
    involved: the confinement comes from the morphological reconstruction
    that built `support_mask`, not from comparing pixels to a value here."""
    if foreground_markers.max() == 0 or support_mask.max() == 0:
        return np.zeros(response_channel.shape, dtype=np.int32)
    surface = -response_channel
    return watershed(surface, foreground_markers, mask=(support_mask > 0), compactness=compactness)


def shape_filter(seg_labels, min_area, max_area, min_circ, min_solid, max_aspect, min_conv):
    """Area / circularity / solidity / aspect / convexity discriminator.
    Unchanged from v3 -- a geometric filter applied to already-segmented
    regions. It never inspects a pixel's intensity, so it is not one of
    the threshold comparisons this rewrite eliminates; it is exactly the
    'Shape Analysis' / 'Contour Analysis' stage this rewrite keeps."""
    out = np.zeros(seg_labels.shape, dtype=np.uint8)
    kept = []
    for label in np.unique(seg_labels):
        if label == 0:
            continue
        comp = (seg_labels == label).astype(np.uint8) * 255
        cnts, _ = cv2.findContours(comp, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            continue
        c = max(cnts, key=cv2.contourArea)
        area = cv2.contourArea(c)
        if not (min_area <= area <= max_area):
            continue
        perim = cv2.arcLength(c, True)
        circularity = (4 * np.pi * area) / (perim ** 2) if perim > 0 else 0
        hull = cv2.convexHull(c)
        hull_area = cv2.contourArea(hull)
        solidity = area / hull_area if hull_area > 0 else 0
        x, y, wb, hb = cv2.boundingRect(c)
        aspect = max(wb, hb) / max(1, min(wb, hb))
        convexity = cv2.arcLength(hull, True) / perim if perim > 0 else 0
        if circularity >= min_circ and solidity >= min_solid and aspect <= max_aspect and convexity >= min_conv:
            out[seg_labels == label] = 255
            kept.append(c)
    return out, kept


DEFAULT_PARAMS = dict(
    # Tab 1 -- Illumination & Denoise
    bg_sigma=45.0,
    bilat_d=9, bilat_sc=50.0, bilat_ss=50.0,
    # Tab 2 -- Multi-scale gradient bands (DoG scale selection + speckle
    # reconstruction radius, feeding marker generation below)
    fine_sigma1=1.0, fine_sigma2=3.0,
    coarse_sigma1=5.0, coarse_sigma2=16.0,
    recon_radius=1,
    # Tab 3 -- Marker Generation & Watershed
    #
    # dome_height_* are fixed structural depths on the DoG response's own
    # native scale (roughly 8-bit intensity units), picked once by hand to
    # sit comfortably above the DoG band's typical noise amplitude on this
    # camera rig -- the same way `recon_radius` or `close_radius` were
    # already picked by hand in v3. They are plain numbers set directly by
    # the GUI slider, NOT recomputed from any image's mean/std/percentile
    # at run time -- that distinction (fixed structural number vs.
    # per-image statistical cutoff) is exactly what this rewrite requires.
    # If a different camera/lighting rig produces a different noise floor,
    # re-pick these numbers by hand for that rig, same as any other
    # structural slider in this file.
    dome_height_fine=30.0,
    dome_height_coarse=32.0,
    min_component_area_fine=5,
    min_component_area_coarse=60,
    local_max_min_dist=4,
    basin_merge_radius_fine=1,
    basin_merge_radius_coarse=2,
    compactness=0.0,
    # Tab 4 -- Shape filtering
    min_area=20, max_area=25000,
    min_circularity=0.45, min_solidity=0.82, max_aspect_ratio=5.0, min_convexity=0.88,
    # Tab 5 -- Full-Extent Band & Continuity (large homogeneous defects)
    dome_height_extent=35.0,
    min_component_area_extent=120,
    local_max_min_dist_extent=15,
    basin_merge_radius_extent=3,
    # Tab 6 -- Micro-Scale Marker Refinement (minute defects)
    micro_enabled=True,
    dome_height_micro=20.0,
    min_component_area_micro=2,
    local_max_min_dist_micro=2,
    basin_merge_radius_micro=1,
    micro_max_area=40,
)


def _detect_band(response_channel, roi, dome_height, min_component_area,
                  local_max_min_dist, basin_merge_radius,
                  min_area, max_area, min_circ, min_solid, max_aspect, min_conv,
                  compactness=0.0):
    """One marker-controlled-watershed detection band. Replaces v3's
    `adaptive_threshold -> binary -> watershed` sequence with
    `dome_extract -> marker refinement -> mask-confined watershed`, with no
    threshold at any step (see module docstring)."""
    dome = dome_extract(response_channel, dome_height)
    # dome > 0 is a structural consequence of the reconstruction above
    # (see dome_extract's docstring) -- not a chosen intensity cutoff.
    dome_positive = (dome > 0).astype(np.uint8) * 255
    dome_positive = cv2.bitwise_and(dome_positive, roi)
    dome_positive = remove_small_components(dome_positive, min_component_area)
    dome_positive = close_and_fill(dome_positive, basin_merge_radius)

    if dome_positive.max() == 0:
        return dict(mask=np.zeros(response_channel.shape, np.uint8), contours=[],
                    dome=dome, dome_positive=dome_positive)

    fg_markers = build_foreground_markers(dome_positive, local_max_min_dist)
    seg = watershed_segment(response_channel, fg_markers, dome_positive, compactness=compactness)
    mask, contours = shape_filter(seg, min_area, max_area, min_circ, min_solid, max_aspect, min_conv)
    return dict(mask=mask, contours=contours, dome=dome, dome_positive=dome_positive)


def _run_detection(gray, params, roi_polygon=None):
    """Polarity/band detection engine, operating on an already
    perspective-corrected, possibly-resized grayscale array. Shared by both
    the live-preview path and the full-resolution export path."""
    p = dict(DEFAULT_PARAMS)
    p.update(params or {})
    gray_f = gray.astype(np.float32)

    # Base ROI: exclude the solid-black padding introduced by
    # perspective_correct's warp (pixels the warp never touched -- exactly
    # 0, or noise around it). This is not a defect-detection cutoff; it
    # excludes pixels that are not real powder-bed surface at all, the same
    # role the polygon ROI intersection below plays.
    roi = (gray > 3).astype(np.uint8) * 255
    roi = cv2.erode(roi, np.ones((15, 15), np.uint8))
    # Polygon ROI: intersect with the user-drawn polygon, if any, instead
    # of a rigid rectangular crop. Everything outside the polygon is
    # excluded from detection.
    if roi_polygon is not None and len(roi_polygon) >= 3:
        poly_mask = polygon_to_mask(gray.shape[:2], roi_polygon)
        roi = cv2.bitwise_and(roi, poly_mask)

    background = estimate_background(gray_f, p["bg_sigma"])
    normalized = flatten_illumination(gray_f, background)
    denoised = cv2.bilateralFilter(
        normalized.astype(np.uint8), int(p["bilat_d"]), float(p["bilat_sc"]), float(p["bilat_ss"])
    ).astype(np.float32)

    dog_fine = difference_of_gaussians(denoised, p["fine_sigma1"], p["fine_sigma2"])
    dog_coarse = difference_of_gaussians(denoised, p["coarse_sigma1"], p["coarse_sigma2"])
    dog = dog_fine + dog_coarse  # combined, for visualization only

    results = {}
    for polarity, sign in (("bright", 1.0), ("dark", -1.0)):
        extent_channel = opening_by_reconstruction(sign * denoised, int(p["recon_radius"]))

        band_defs = [
            ("fine", np.clip(sign * dog_fine, 0, None), p["dome_height_fine"],
             p["min_component_area_fine"], p["local_max_min_dist"], p["basin_merge_radius_fine"]),
            ("coarse", np.clip(sign * dog_coarse, 0, None), p["dome_height_coarse"],
             p["min_component_area_coarse"], p["local_max_min_dist"], p["basin_merge_radius_coarse"]),
            ("extent", extent_channel, p["dome_height_extent"],
             p["min_component_area_extent"], p["local_max_min_dist_extent"], p["basin_merge_radius_extent"]),
        ]

        band_results = {}
        for name, channel, dome_h, min_comp_area, mdist, merge_r in band_defs:
            band_results[name] = _detect_band(
                channel, roi, dome_h, min_comp_area, mdist, merge_r,
                p["min_area"], p["max_area"], p["min_circularity"], p["min_solidity"],
                p["max_aspect_ratio"], p["min_convexity"], compactness=p["compactness"],
            )

        combined_mask = band_results["fine"]["mask"]
        for name in ("coarse", "extent"):
            combined_mask = cv2.bitwise_or(combined_mask, band_results[name]["mask"])

        if p["micro_enabled"]:
            # Minute-defect band: same marker-controlled-watershed engine,
            # tuned to a small dome height / tight marker spacing / small
            # max-area cap so it only ever contributes tiny candidates the
            # fine band's own area filter would otherwise discard. This
            # replaces v3's z-score-based `local_contrast_rescue` -- it can
            # only ever ADD candidates that this same watershed engine
            # proposes on its own terms, never re-validate against a
            # statistical cutoff.
            micro_result = _detect_band(
                np.clip(sign * dog_fine, 0, None), roi, p["dome_height_micro"],
                p["min_component_area_micro"], p["local_max_min_dist_micro"],
                p["basin_merge_radius_micro"],
                p["min_area"], p["micro_max_area"], p["min_circularity"], p["min_solidity"],
                p["max_aspect_ratio"], p["min_convexity"], compactness=p["compactness"],
            )
            band_results["micro"] = micro_result
            combined_mask = cv2.bitwise_or(combined_mask, micro_result["mask"])

        combined_contours, _ = cv2.findContours(combined_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        results[polarity] = dict(
            mask=combined_mask, contours=list(combined_contours), bands=band_results,
        )

    return dict(
        roi=roi, normalized=normalized, background=background, denoised=denoised,
        dog=dog, dog_fine=dog_fine, dog_coarse=dog_coarse,
        bright=results["bright"], dark=results["dark"],
    )


def run_pipeline(image_path, max_dim, params, roi_polygon=None):
    """Full pipeline entry point. Used identically by both single-image and
    batch export; the GUI module never re-implements any of this."""
    img = cv2.imread(image_path)
    if img is None:
        return None
    img = perspective_correct(img)

    h, w = img.shape[:2]
    if max_dim is not None and max(h, w) > max_dim:
        scale = max_dim / float(max(h, w))
        img_disp = cv2.resize(img, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)
    else:
        img_disp = img.copy()

    gray = cv2.cvtColor(img_disp, cv2.COLOR_BGR2GRAY)

    # roi_polygon is already normalized (x_frac, y_frac) -- no rescaling
    # needed regardless of whether this call is the downsized live preview
    # or a full-resolution export.
    det = _run_detection(gray, params, roi_polygon=roi_polygon)
    final_mask = cv2.bitwise_or(det["bright"]["mask"], det["dark"]["mask"])

    bg_rgb = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
    white_display = bg_rgb.copy()
    dark_display = bg_rgb.copy()
    final_output = bg_rgb.copy()
    cv2.drawContours(white_display, det["bright"]["contours"], -1, (255, 0, 0), -1)
    cv2.drawContours(dark_display, det["dark"]["contours"], -1, (255, 0, 0), -1)
    cv2.drawContours(final_output, det["bright"]["contours"], -1, (255, 0, 0), -1)     # red = bright
    cv2.drawContours(final_output, det["dark"]["contours"], -1, (255, 140, 0), -1)     # orange = dark

    return dict(
        img_disp=img_disp, gray=gray, normalized=det["normalized"], background=det["background"],
        denoised=det["denoised"], dog=det["dog"], dog_fine=det["dog_fine"], dog_coarse=det["dog_coarse"],
        roi=det["roi"], bright=det["bright"], dark=det["dark"],
        final_mask=final_mask, white_display=white_display, dark_display=dark_display,
        final_output=final_output,
    )


def dog_to_colormap(dog, clip_std=3.0):
    """Diverging visualization of the (signed) DoG response. `clip_std` is
    a display-range clip for the colormap only -- it decides how many
    standard deviations of contrast fit in the visualization's color
    range, and never feeds back into detection. Unchanged from v3."""
    mu, sigma = float(dog.mean()), float(dog.std() + 1e-6)
    clipped = np.clip(dog, mu - clip_std * sigma, mu + clip_std * sigma)
    norm = cv2.normalize(clipped, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
    return cv2.applyColorMap(norm, cv2.COLORMAP_JET)
