# PBF Powder-Bed Surface Defect Inspector v4

## Project Overview

This application inspects camera images of a metal Powder Bed Fusion (PBF)
build plate and highlights surface defects in the powder layer -- bright
defects (e.g. spatter, recoater streaks, foreign particles) and dark
defects (e.g. pits, voids, incomplete spreading) -- so an operator can
review them before or during a build.

**This application contains NO threshold-based parameters.** Every
detection decision -- from finding a candidate defect region to deciding
its boundary -- is made by marker-controlled watershed segmentation, driven
by morphological reconstruction and gradient topology. There is no
`pixel > value` comparison anywhere in the code that depends on an
image's own mean, standard deviation, median, MAD, z-score, or percentile.
See "Why No Thresholds" below for what that means in practice and what it
trades off.

`pbf_pipeline.py` contains the entire image-processing engine (no GUI
imports). `pbf_inspector_app.py` is the GUI only and imports every
detection function from the pipeline -- it never re-implements any
detection logic, which is what guarantees Single-Image mode and Batch
mode always run the identical pipeline.

## Complete Pipeline

Each image (single or one file in a batch) goes through the same ordered
stages, run once per polarity (bright, dark):

1. **Load Image** -- `cv2.imread`.
2. **Perspective Correction** (`perspective_correct`) -- finds the build
   plate's quadrilateral and warps it to a flat rectangle. The plate/
   background split is a two-marker watershed over the frame's Sobel
   gradient magnitude (border strip = background marker, a small box at
   the frame centre = plate marker) -- not an intensity cutoff.
3. **ROI Selection** (`polygon_to_mask`) -- an optional user-drawn polygon
   (normalized coordinates, valid at any resolution) intersected with the
   base "not-padding" mask to produce the processing ROI.
4. **Illumination Normalization** (`estimate_background`,
   `flatten_illumination`) -- a large-sigma Gaussian low-pass estimates the
   slow illumination/powder-tone field; the image is flat-fielded against
   it.
5. **Bilateral Filtering** (`cv2.bilateralFilter`) -- edge-preserving
   denoise.
6. **Multi-Scale Gradient Bands** (`difference_of_gaussians`) -- a "fine"
   and a "coarse" Difference-of-Gaussians band select which spatial scale
   a candidate response belongs to. This is scale selection, not
   detection -- nothing is compared to a cutoff here.
7. **Marker Generation** (`dome_extract`) -- for each band (fine, coarse,
   full-extent, micro) and each polarity, morphological reconstruction
   extracts regions standing at least a fixed `dome_height` above (or
   below) their local surroundings. This is the step that decides which
   pixels are candidate defect pixels -- see "Why No Thresholds" below for
   why this is not itself a threshold.
8. **Marker Refinement** (`build_foreground_markers`) -- a distance-
   transform peak search inside each dome-positive region splits touching
   blobs into separate watershed seeds. `close_and_fill` (run just before
   this) merges dome regions within a fixed `basin_merge_radius` of one
   another into a single marker group first.
9. **Watershed Segmentation** (`watershed_segment`) -- each marker floods
   outward over the response channel's own topology, confined to the
   dome-positive footprint from step 7. A single homogeneous blob with one
   marker keeps its full extent; two touching blobs with two markers get
   split at the ridge between them.
10. **Basin Merging** -- touching/close candidate regions are merged into
    one marker group by `close_and_fill` before marker refinement (step
    8), and multiple bands' final masks are unioned per polarity.
11. **Shape Filtering** (`shape_filter`) -- a geometric discriminator
    (area, circularity, solidity, aspect ratio, convexity) rejects
    segmented regions that don't look like a real defect. This never
    inspects a pixel's intensity, so it is not a threshold in the sense
    this pipeline eliminates -- it is a shape/contour analysis stage.
12. **Contour Extraction** -- `cv2.findContours` on each band's final
    mask, then on the polarity's combined mask.
13. **Final Overlay** -- bright-defect contours drawn in red, dark-defect
    contours drawn in orange, over the grayscale image.

Single-image and batch processing both call `run_pipeline()` -- there is
exactly one implementation of all of the above.

## Why No Thresholds

Marker-controlled watershed can segment an image into "defect" and
"not defect" regions without ever comparing a pixel's intensity to a
value derived from the image's own statistics. Three ideas make this
possible, and all three are used here:

* **Morphological reconstruction (`dome_extract`)** finds regions that
  stand at least a fixed height above their surroundings by literally
  reconstructing a "flooded" version of the surface and subtracting it.
  Its output is zero outside any region shorter than that height, and
  nonzero (equal to the region's own elevation) inside one. That
  zero/nonzero split is a structural fact about the reconstruction, not a
  chosen cutoff value being compared against a pixel.
* **Distance-transform peak search (`peak_local_max`)** only ever compares
  a pixel's distance-to-boundary value to its *neighbours*, never to an
  absolute number, so splitting touching blobs into separate markers stays
  threshold-free.
* **Watershed's own basin-competition rule** decides every final boundary
  by which marker's flood reaches a pixel first, following the response
  channel's topology -- a topological rule, not an intensity comparison.

### The trade-off, stated plainly

The `dome_height_*` parameters (Tabs 3, 5, 6) and the shape-filter
parameters (Tab 4) are **fixed structural numbers you set by hand**,
exactly like `recon_radius` or a closing radius always were in this
codebase -- they are never recomputed from an image's own mean, std, or
percentiles at run time. That is what makes this a threshold-free
pipeline. It is also why the defaults shipped in `DEFAULT_PARAMS` will not
automatically re-calibrate themselves to a different camera, lighting rig,
or powder material the way a `mean + k*std` cutoff used to. If detections
look too sparse or too noisy on your imagery, treat `dome_height_fine` /
`_coarse` / `_extent` / `_micro` the same way you would treat any other
structural slider in this file: adjust them by hand against a few
reference images from your own rig, then leave them alone. This is a
deliberate consequence of removing every statistical/adaptive cutoff, not
an oversight.

## GUI Tabs

### Tab 1 -- Illumination & Denoise
| Parameter | What it controls | Stage |
|---|---|---|
| Background Gaussian Sigma | Spatial scale of the illumination field estimate | Illumination Normalization |
| Bilateral Filter Diameter | Neighbourhood size for edge-preserving denoise | Bilateral Filtering |
| Bilateral Sigma Color | How much intensity difference bilateral filtering tolerates before it stops smoothing across an edge | Bilateral Filtering |
| Bilateral Sigma Space | How far in pixels bilateral filtering looks when smoothing | Bilateral Filtering |

None of these are intensity thresholds -- they shape the preprocessing
surface everything downstream operates on.

### Tab 2 -- Multi-Scale Gradient Bands
| Parameter | What it controls | Stage |
|---|---|---|
| Fine Band Sigma 1 / Sigma 2 | The two Gaussian scales whose difference defines the "fine" (small-defect) response band | Gradient/Scale Selection |
| Coarse Band Sigma 1 / Sigma 2 | The two Gaussian scales for the "coarse" (larger-defect) response band | Gradient/Scale Selection |
| Speckle Reconstruction Radius | Structural radius that removes sub-pixel speckle before the full-extent band's marker generation | Morphological Reconstruction |

DoG selects *which spatial scale* a candidate belongs to; it is a filter,
not a threshold, and its output is never compared to a statistical cutoff.

### Tab 3 -- Marker Generation & Watershed
| Parameter | What it controls | Stage |
|---|---|---|
| Fine-Band Marker Dome Height | Fixed reconstruction depth for extracting fine-band marker candidates | Marker Generation |
| Coarse-Band Marker Dome Height | Fixed reconstruction depth for coarse-band marker candidates | Marker Generation |
| Fine-/Coarse-Band Min Component Area | Structural area filter removing tiny dome fragments before marker refinement | Marker Generation |
| Watershed Marker Min Distance | Minimum spacing enforced between distance-transform peaks when splitting touching blobs | Marker Refinement |
| Fine-/Coarse-Band Basin Merge Radius | Morphological closing radius that merges nearby dome regions into one marker group | Marker Merging |
| Watershed Compactness | Encourages more compact (rounder) watershed basins during flooding | Watershed |

### Tab 4 -- Defect Shape Filtering
| Parameter | What it controls | Stage |
|---|---|---|
| Minimum / Maximum Area | Size bounds a segmented region's contour area must fall within | Shape Filtering |
| Minimum Circularity | How close to a circle the region's contour must be | Shape Filtering |
| Minimum Solidity | How "filled in" (vs. spindly) the region must be, relative to its convex hull | Shape Filtering |
| Maximum Aspect Ratio | Upper bound on elongation (long axis / short axis) | Shape Filtering |
| Minimum Convexity | How close the contour's perimeter is to its convex hull's perimeter | Shape Filtering |

These are geometric criteria on already-segmented regions -- they never
look at a pixel's intensity value.

### Tab 5 -- Full-Extent Band & Continuity
| Parameter | What it controls | Stage |
|---|---|---|
| Full-Extent Marker Dome Height | Fixed reconstruction depth for the whole-extent band, which keeps large homogeneous defects filled in rather than only detecting a rim | Marker Generation |
| Full-Extent Min Component Area | Structural area filter for full-extent candidates | Marker Generation |
| Full-Extent Watershed Marker Min Distance | Peak spacing for splitting touching large defects | Marker Refinement |
| Full-Extent Basin Merge Radius | Merges nearby full-extent dome regions into one marker group before splitting | Marker Merging |

### Tab 6 -- Micro-Scale Marker Refinement
| Parameter | What it controls | Stage |
|---|---|---|
| Enable Micro-Scale Marker Band | Turns the minute-defect band on/off | Marker Generation |
| Micro-Band Marker Dome Height | Fixed, small reconstruction depth tuned for minute dots | Marker Generation |
| Micro-Band Min Component Area | Structural area filter for micro candidates | Marker Generation |
| Micro-Band Watershed Marker Min Distance | Tight peak spacing appropriate to minute defects | Marker Refinement |
| Micro-Band Basin Merge Radius | Marker-merging radius for the micro band | Marker Merging |
| Max Area Considered "Minute" | Upper area bound so this band only ever contributes tiny candidates | Shape Filtering |

### ROI
"Define ROI" opens a click-to-add / drag-to-move / right-click-to-delete
polygon editor. "Confirm ROI" stores a normalized polygon (valid at any
resolution) that becomes the processing mask for both the live preview and
Single/Batch export. "Clear ROI" removes the restriction. This is masking,
not a hard crop, so the same array coordinates are used throughout the
pipeline and in the returned contours.

## Single vs. Batch Processing

Both modes call the exact same `run_pipeline()` in `pbf_pipeline.py` with
the exact same parameter dictionary and ROI polygon -- there is no
duplicated detection logic between them. Batch export also writes a full
per-stage image dump and a `parameters.json` (single-image mode only) that
records the configured parameters, the ROI polygon, and the engine
identifier `dual_polarity_marker_controlled_watershed_v4_no_threshold`.

## Verification Checklist

- [x] No threshold parameters anywhere (grep the codebase for
      `threshold`, `mean+k*std`, `z-score`, `percentile`, `otsu`, `mad` --
      the only remaining hits are code comments/docstrings explaining what
      was removed and why, plus a purely cosmetic display-range clip in
      `dog_to_colormap` used only for the DoG visualization colormap, never
      for detection).
- [x] No `adaptive_threshold()`, `robust_mu_sigma()`, or
      `local_contrast_rescue()` functions -- removed entirely.
- [x] No `cv2.threshold()` / Otsu calls anywhere, including in
      `perspective_correct()`.
- [x] No intensity cutoffs, adaptive threshold methods, or hidden threshold
      comparisons in the GUI, pipeline, or exported JSON.
- [x] Detection relies only on morphological reconstruction, marker
      generation/refinement/merging, distance-transform peaks, and
      watershed flooding over gradient/response topology.
- [x] OpenCV, NumPy, SciPy, scikit-image, tkinter, customtkinter --
      unchanged dependency set; no deep-learning library, no new external
      dependency.
- [x] Single-image and batch processing share one `run_pipeline()`
      implementation; polygon ROI behaves identically in both.
