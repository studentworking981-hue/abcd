"""
widgets.py
==========
Small reusable Qt widgets for the AM Defect Detection GUI.

`ParamControl` bundles a QSlider and a numeric spin box (QSpinBox or
QDoubleSpinBox) into one row, keeping both perfectly in sync and exposing
a single `valueChanged` signal so the rest of the application does not
need to know whether a given parameter is an int or a float.
"""

from __future__ import annotations

from PyQt5.QtCore import Qt, pyqtSignal
from PyQt5.QtWidgets import (
    QWidget, QLabel, QSlider, QSpinBox, QDoubleSpinBox, QHBoxLayout, QVBoxLayout
)


class ParamControl(QWidget):
    """
    A labeled row containing a slider and a synchronized numeric spin box.

    For float parameters, the slider is internally scaled by `10**decimals`
    so that QSlider (which is integer-only) can still represent fractional
    steps smoothly.
    """

    valueChanged = pyqtSignal(float)

    def __init__(
        self,
        label: str,
        minimum: float,
        maximum: float,
        value: float,
        step: float = 1.0,
        decimals: int = 0,
        tooltip: str = "",
        parent: QWidget | None = None,
    ):
        super().__init__(parent)
        self.decimals = decimals
        self._scale = 10 ** decimals

        self.label = QLabel(label)
        if tooltip:
            self.label.setToolTip(tooltip)
            self.setToolTip(tooltip)

        self.slider = QSlider(Qt.Horizontal)
        self.slider.setMinimum(int(round(minimum * self._scale)))
        self.slider.setMaximum(int(round(maximum * self._scale)))
        self.slider.setSingleStep(max(int(round(step * self._scale)), 1))
        self.slider.setValue(int(round(value * self._scale)))

        if decimals > 0:
            self.spin = QDoubleSpinBox()
            self.spin.setDecimals(decimals)
            self.spin.setSingleStep(float(step))
            self.spin.setMinimum(float(minimum))
            self.spin.setMaximum(float(maximum))
            self.spin.setValue(float(value))
        else:
            self.spin = QSpinBox()
            self.spin.setSingleStep(int(round(step)))
            self.spin.setMinimum(int(round(minimum)))
            self.spin.setMaximum(int(round(maximum)))
            self.spin.setValue(int(round(value)))

        self.spin.setFixedWidth(80)

        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.addWidget(self.slider, stretch=1)
        row.addWidget(self.spin, stretch=0)

        outer = QVBoxLayout()
        outer.setContentsMargins(0, 4, 0, 4)
        outer.setSpacing(2)
        outer.addWidget(self.label)
        outer.addLayout(row)
        self.setLayout(outer)

        self._syncing = False
        self.slider.valueChanged.connect(self._on_slider_changed)
        self.spin.valueChanged.connect(self._on_spin_changed)

    # -- internal sync handlers -----------------------------------------

    def _on_slider_changed(self, raw_int: int):
        if self._syncing:
            return
        self._syncing = True
        val = raw_int / self._scale
        if self.decimals == 0:
            self.spin.setValue(int(round(val)))
        else:
            self.spin.setValue(val)
        self._syncing = False
        self.valueChanged.emit(float(val))

    def _on_spin_changed(self, val: float):
        if self._syncing:
            return
        self._syncing = True
        self.slider.setValue(int(round(val * self._scale)))
        self._syncing = False
        self.valueChanged.emit(float(val))

    # -- public API -------------------------------------------------------

    def value(self) -> float:
        return self.spin.value()

    def setValue(self, val: float):
        if self.decimals == 0:
            self.spin.setValue(int(round(val)))
        else:
            self.spin.setValue(float(val))
