#!/usr/bin/env python3
"""
main.py
=======
Entry point for the Additive Manufacturing (AM) Defect Detection
application.

Run with:
    python main.py

Requires PyQt5, scikit-image, numpy, scipy, and matplotlib to be
installed (see requirements.txt).
"""

import sys


def _check_dependencies():
    missing = []
    for module_name, pip_name in [
        ("PyQt5", "PyQt5"),
        ("skimage", "scikit-image"),
        ("numpy", "numpy"),
        ("scipy", "scipy"),
        ("matplotlib", "matplotlib"),
    ]:
        try:
            __import__(module_name)
        except ImportError:
            missing.append(pip_name)
    if missing:
        print("Missing required packages:", ", ".join(missing))
        print("Install them with:")
        print(f"    pip install {' '.join(missing)}")
        sys.exit(1)


if __name__ == "__main__":
    _check_dependencies()
    from gui import main
    main()
