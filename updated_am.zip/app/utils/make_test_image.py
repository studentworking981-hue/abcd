#!/usr/bin/env python3
"""
make_test_image.py
===================
Utility script (NOT part of the segmentation pipeline) that generates a
synthetic additive-manufacturing surface image containing dark defects
(pits / lack-of-fusion voids) and bright defects (spatter / over-melt),
useful for trying out the application without needing a real dataset.

Usage:
    python utils/make_test_image.py [output_path] [--seed N]
"""

import argparse
import numpy as np
from skimage import io
from skimage.util import img_as_ubyte


def generate(height=300, width=400, seed=0):
    rng = np.random.default_rng(seed)

    # Base "melt pool texture" background with mild low-frequency shading
    yy, xx = np.mgrid[0:height, 0:width]
    shading = 0.03 * np.sin(xx / 25.0) * np.cos(yy / 30.0)
    img = np.full((height, width), 0.55) + shading
    img += rng.normal(0, 0.015, (height, width))  # sensor / powder-bed noise

    def add_blob(img, cy, cx, r, val, softness=1.5):
        yyb, xxb = np.ogrid[:height, :width]
        dist = np.sqrt((yyb - cy) ** 2 + (xxb - cx) ** 2)
        mask = dist <= r
        falloff = np.clip(1 - (dist / (r * softness)), 0, 1)
        img[mask] = img[mask] * (1 - falloff[mask]) + val * falloff[mask]
        return img

    n_dark = rng.integers(5, 9)
    for _ in range(n_dark):
        cy, cx = rng.integers(20, height - 20), rng.integers(20, width - 20)
        r = rng.integers(3, 9)
        add_blob(img, cy, cx, r, val=rng.uniform(0.05, 0.2))

    n_bright = rng.integers(4, 8)
    for _ in range(n_bright):
        cy, cx = rng.integers(20, height - 20), rng.integers(20, width - 20)
        r = rng.integers(2, 6)
        add_blob(img, cy, cx, r, val=rng.uniform(0.85, 1.0))

    img = np.clip(img, 0, 1)
    return img


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", nargs="?", default="test_am_surface.png")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--height", type=int, default=300)
    parser.add_argument("--width", type=int, default=400)
    args = parser.parse_args()

    img = generate(height=args.height, width=args.width, seed=args.seed)
    io.imsave(args.output, img_as_ubyte(img))
    print(f"Saved synthetic test image to: {args.output}")
