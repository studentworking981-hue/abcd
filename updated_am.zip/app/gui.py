"""
gui.py
======
Main window for the Additive Manufacturing (AM) Defect Detection
application.

Layout
------
* Left dock: scrollable control panel with grouped parameter sliders
  (Preprocessing, Gradient, Markers, Watershed, Region Analysis, Overlay).
  Every parameter change re-runs the pipeline and refreshes every tab.
* Center: a QTabWidget with one tab per pipeline stage:
    1. Original Image
    2. Preprocessing
    3. Gradient / Topographic Surface
    4. Marker Generation
    5. Watershed Segmentation
    6. Region Analysis
    7. Overlay on Original Image
"""

from __future__ import annotations

import os
import sys
import traceback

import numpy as np
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QColor
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QTabWidget, QLabel, QPushButton, QFileDialog, QScrollArea, QGroupBox,
    QComboBox, QCheckBox, QTableWidget, QTableWidgetItem, QMessageBox,
    QSplitter, QStatusBar, QHeaderView, QProgressBar, QListWidget
)

from widgets import ParamControl
import pipeline as pl
import batch as bt


# ---------------------------------------------------------------------------
# A single matplotlib canvas wrapped for easy embedding inside a tab
# ---------------------------------------------------------------------------

class ImageTab(QWidget):
    """A tab that shows a single image (grayscale or RGB) with a title."""

    def __init__(self, title: str, cmap: str = "gray", parent=None):
        super().__init__(parent)
        self.title = title
        self.cmap = cmap

        self.figure = Figure(figsize=(5, 4), tight_layout=True)
        self.canvas = FigureCanvas(self.figure)
        self.ax = self.figure.add_subplot(111)
        self.ax.set_axis_off()

        self.info_label = QLabel("")
        self.info_label.setStyleSheet("color: #555; font-size: 11px;")

        layout = QVBoxLayout()
        layout.addWidget(self.canvas, stretch=1)
        layout.addWidget(self.info_label)
        self.setLayout(layout)

    def show_image(self, img: np.ndarray, info: str = "", cmap: str | None = None):
        self.ax.clear()
        self.ax.set_axis_off()
        if img is None:
            self.info_label.setText(info)
            self.canvas.draw_idle()
            return
        use_cmap = cmap if cmap is not None else (None if img.ndim == 3 else self.cmap)
        self.ax.imshow(img, cmap=use_cmap)
        self.ax.set_title(self.title, fontsize=10)
        self.info_label.setText(info)
        self.canvas.draw_idle()


class MarkerTab(QWidget):
    """Special tab for marker visualization: overlays dark/bright/background
    seed points on top of the smoothed image."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.figure = Figure(figsize=(5, 4), tight_layout=True)
        self.canvas = FigureCanvas(self.figure)
        self.ax = self.figure.add_subplot(111)
        self.ax.set_axis_off()
        self.info_label = QLabel("")
        self.info_label.setStyleSheet("color: #555; font-size: 11px;")
        layout = QVBoxLayout()
        layout.addWidget(self.canvas, stretch=1)
        layout.addWidget(self.info_label)
        self.setLayout(layout)

    def show_markers(self, smoothed: np.ndarray, marker_result: pl.MarkerResult, info: str = ""):
        self.ax.clear()
        self.ax.set_axis_off()
        self.ax.imshow(smoothed, cmap="gray")
        ys, xs = np.nonzero(marker_result.dark_mask)
        self.ax.scatter(xs, ys, s=14, c="deepskyblue", marker="o", label="dark-defect seed")
        ys, xs = np.nonzero(marker_result.bright_mask)
        self.ax.scatter(xs, ys, s=14, c="red", marker="o", label="bright-defect seed")
        ys, xs = np.nonzero(marker_result.background_mask)
        self.ax.scatter(xs, ys, s=4, c="lime", marker=".", alpha=0.5, label="background seed")
        self.ax.set_title("Marker Generation (extrema-based seeds)", fontsize=10)
        self.ax.legend(loc="upper right", fontsize=7, framealpha=0.6)
        self.info_label.setText(info)
        self.canvas.draw_idle()


class RegionAnalysisTab(QWidget):
    """Table view of regionprops-derived measurements."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.summary_label = QLabel("")
        self.summary_label.setStyleSheet("font-weight: bold; padding: 4px;")

        self.table = QTableWidget()
        self.table.setColumnCount(8)
        self.table.setHorizontalHeaderLabels(
            ["Label", "Role", "Area (px)", "Mean Intensity", "Eccentricity",
             "Perimeter", "Equiv. Diameter", "Solidity"]
        )
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)

        layout = QVBoxLayout()
        layout.addWidget(self.summary_label)
        layout.addWidget(self.table)
        self.setLayout(layout)

    def show_regions(self, region_result: pl.RegionAnalysisResult):
        rows = region_result.table
        self.table.setRowCount(len(rows))

        n_defects = sum(1 for r in rows if r["role"] == "defect")
        n_noise = sum(1 for r in rows if r["role"] == "noise")
        self.summary_label.setText(
            f"{len(rows)} total regions   |   {n_defects} defects   |   "
            f"{n_noise} filtered as noise   |   1 background region"
        )

        role_colors = {"defect": "#ffe0e0", "background": "#e0ffe0", "noise": "#eeeeee"}
        for i, r in enumerate(rows):
            values = [
                str(r["label"]), r["role"], str(r["area"]),
                f"{r['mean_intensity']:.4f}", f"{r['eccentricity']:.3f}",
                f"{r['perimeter']:.1f}", f"{r['equivalent_diameter']:.2f}",
                f"{r['solidity']:.3f}",
            ]
            for j, v in enumerate(values):
                item = QTableWidgetItem(v)
                item.setBackground(QColor(role_colors.get(r["role"], "#ffffff")))
                self.table.setItem(i, j, item)


class BatchTab(QWidget):
    """
    Batch Processing tab: pick an input folder and an output folder, run
    the existing single-image pipeline (via batch.BatchWorker) over every
    supported image in the input folder, and save every output the
    application already generates into one subfolder per input image.
    """

    def __init__(self, get_params_callback, parent=None):
        super().__init__(parent)
        self._get_params = get_params_callback
        self.input_folder = ""
        self.output_folder = ""
        self.worker: bt.BatchWorker | None = None

        layout = QVBoxLayout()

        folders_box = QGroupBox("Folders")
        folders_layout = QGridLayout()

        self.input_label = QLabel("(none selected)")
        self.input_label.setStyleSheet("color: #555;")
        self.input_btn = QPushButton("Select Input Folder…")
        self.input_btn.clicked.connect(self._select_input_folder)

        self.output_label = QLabel("(none selected)")
        self.output_label.setStyleSheet("color: #555;")
        self.output_btn = QPushButton("Select Output Folder…")
        self.output_btn.clicked.connect(self._select_output_folder)

        folders_layout.addWidget(QLabel("Input Folder:"), 0, 0)
        folders_layout.addWidget(self.input_label, 0, 1)
        folders_layout.addWidget(self.input_btn, 0, 2)
        folders_layout.addWidget(QLabel("Output Folder:"), 1, 0)
        folders_layout.addWidget(self.output_label, 1, 1)
        folders_layout.addWidget(self.output_btn, 1, 2)
        folders_box.setLayout(folders_layout)
        layout.addWidget(folders_box)

        btn_row = QHBoxLayout()
        self.start_btn = QPushButton("Start")
        self.start_btn.clicked.connect(self._start)
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self._cancel)
        self.cancel_btn.setEnabled(False)
        btn_row.addWidget(self.start_btn)
        btn_row.addWidget(self.cancel_btn)
        layout.addLayout(btn_row)

        progress_box = QGroupBox("Progress")
        progress_layout = QVBoxLayout()
        self.progress_bar = QProgressBar()
        self.progress_bar.setValue(0)
        self.current_file_label = QLabel("Current file: —")
        self.processed_count_label = QLabel("Processed: 0 / 0")
        progress_layout.addWidget(self.progress_bar)
        progress_layout.addWidget(self.current_file_label)
        progress_layout.addWidget(self.processed_count_label)
        progress_box.setLayout(progress_layout)
        layout.addWidget(progress_box)

        self.summary_label = QLabel("")
        self.summary_label.setWordWrap(True)
        self.summary_label.setStyleSheet("font-weight: bold; padding: 4px;")
        layout.addWidget(self.summary_label)

        layout.addWidget(QLabel("Errors / Log:"))
        self.log_list = QListWidget()
        layout.addWidget(self.log_list, stretch=1)

        self.setLayout(layout)

    # -- folder selection -------------------------------------------------

    def _select_input_folder(self):
        path = QFileDialog.getExistingDirectory(self, "Select Input Folder")
        if path:
            self.input_folder = path
            self.input_label.setText(path)

    def _select_output_folder(self):
        path = QFileDialog.getExistingDirectory(self, "Select Output Folder")
        if path:
            self.output_folder = path
            self.output_label.setText(path)

    # -- run control --------------------------------------------------

    def _start(self):
        if not self.input_folder or not os.path.isdir(self.input_folder):
            QMessageBox.warning(self, "Batch Processing", "Please select a valid input folder.")
            return
        if not self.output_folder:
            QMessageBox.warning(self, "Batch Processing", "Please select an output folder.")
            return

        files = bt.list_supported_images(self.input_folder)
        if not files:
            QMessageBox.information(
                self, "Batch Processing",
                "No supported images (png, jpg, jpeg, bmp, tif, tiff) found in the input folder."
            )
            return

        self.log_list.clear()
        self.summary_label.setText("")
        self.progress_bar.setMinimum(0)
        self.progress_bar.setMaximum(len(files))
        self.progress_bar.setValue(0)
        self.current_file_label.setText("Current file: —")
        self.processed_count_label.setText(f"Processed: 0 / {len(files)}")

        self.start_btn.setEnabled(False)
        self.input_btn.setEnabled(False)
        self.output_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)

        params = self._get_params()
        self.worker = bt.BatchWorker(self.input_folder, self.output_folder, params)
        self.worker.progress.connect(self._on_progress)
        self.worker.current_file_changed.connect(self._on_current_file)
        self.worker.image_failed.connect(self._on_image_failed)
        self.worker.finished_all.connect(self._on_finished)
        self.worker.start()

    def _cancel(self):
        if self.worker is not None:
            self.cancel_btn.setEnabled(False)
            self.current_file_label.setText("Current file: cancelling…")
            self.worker.cancel()

    # -- worker signal handlers -------------------------------------------

    def _on_progress(self, processed: int, total: int):
        self.progress_bar.setValue(processed)
        self.processed_count_label.setText(f"Processed: {processed} / {total}")

    def _on_current_file(self, filename: str):
        self.current_file_label.setText(f"Current file: {filename}")

    def _on_image_failed(self, filename: str, message: str):
        first_line = message.splitlines()[0] if message else "Unknown error"
        self.log_list.addItem(f"FAILED: {filename} — {first_line}")

    def _on_finished(self, total: int, succeeded: int, failed: int):
        self.start_btn.setEnabled(True)
        self.input_btn.setEnabled(True)
        self.output_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.current_file_label.setText("Current file: —")

        if self.worker is not None and self.worker._cancel_requested and (succeeded + failed) < total:
            self.summary_label.setText(
                f"Cancelled — {succeeded + failed} / {total} processed "
                f"({succeeded} succeeded, {failed} failed) before stopping."
            )
        else:
            self.summary_label.setText(
                f"Completed — {succeeded} / {total} succeeded, {failed} failed. "
                f"Output saved to: {self.output_folder}"
            )
        self.worker = None


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AM Defect Detection — Watershed Segmentation")
        self.resize(1400, 900)

        self.rgb = None
        self.gray = None
        self._last_result: pl.PipelineResult | None = None

        # Debounce timer so rapid slider drags don't queue up redundant
        # full-pipeline recomputations; still feels "live" (~60ms).
        self._recompute_timer = QTimer(self)
        self._recompute_timer.setSingleShot(True)
        self._recompute_timer.setInterval(60)
        self._recompute_timer.timeout.connect(self._recompute_pipeline)

        self._build_ui()

    # -- UI construction ---------------------------------------------------

    def _build_ui(self):
        central = QWidget()
        root_layout = QHBoxLayout(central)
        self.setCentralWidget(central)

        splitter = QSplitter(Qt.Horizontal)
        root_layout.addWidget(splitter)

        splitter.addWidget(self._build_control_panel())
        splitter.addWidget(self._build_tabs())
        splitter.setStretchFactor(0, 0)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([340, 1060])

        self.setStatusBar(QStatusBar())
        self.statusBar().showMessage("Load an image to begin.")

    def _build_control_panel(self) -> QWidget:
        panel = QWidget()
        panel.setMinimumWidth(320)
        panel.setMaximumWidth(420)
        outer = QVBoxLayout(panel)

        # -- Load / Save buttons --
        io_box = QGroupBox("Image")
        io_layout = QVBoxLayout()
        self.load_btn = QPushButton("Load Image…")
        self.load_btn.clicked.connect(self.on_load_image)
        self.save_btn = QPushButton("Save Overlay As…")
        self.save_btn.clicked.connect(self.on_save_overlay)
        self.save_btn.setEnabled(False)
        io_layout.addWidget(self.load_btn)
        io_layout.addWidget(self.save_btn)
        io_box.setLayout(io_layout)
        outer.addWidget(io_box)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout(scroll_content)

        scroll_layout.addWidget(self._build_dog_group())
        scroll_layout.addWidget(self._build_gdiv_group())
        scroll_layout.addWidget(self._build_preprocessing_group())
        scroll_layout.addWidget(self._build_gradient_group())
        scroll_layout.addWidget(self._build_marker_group())
        scroll_layout.addWidget(self._build_watershed_group())
        scroll_layout.addWidget(self._build_region_group())
        scroll_layout.addWidget(self._build_overlay_group())
        scroll_layout.addStretch(1)

        scroll.setWidget(scroll_content)
        outer.addWidget(scroll, stretch=1)
        return panel

    # -- Parameter groups ---------------------------------------------------

    # -- Optional Gaussian preprocessing (Task 1) ---------------------------

    _DOG_DEFAULT_SIGMA1 = 1.0
    _DOG_DEFAULT_SIGMA2 = 2.0
    _GDIV_DEFAULT_SIGMA = 5.0
    _GDIV_DEFAULT_EPSILON = 1e-4

    def _build_dog_group(self) -> QGroupBox:
        box = QGroupBox("1. Difference of Gaussian (DoG) — optional")
        layout = QVBoxLayout()

        self.dog_enabled_checkbox = QCheckBox("Enable DoG preprocessing")
        self.dog_enabled_checkbox.setChecked(False)
        self.dog_enabled_checkbox.stateChanged.connect(self._on_dog_toggled)
        layout.addWidget(self.dog_enabled_checkbox)

        self.dog_sigma1_ctrl = ParamControl(
            "Sigma 1", 0.1, 20.0, self._DOG_DEFAULT_SIGMA1, step=0.1, decimals=1,
            tooltip="Standard deviation of the first Gaussian blur (typically the "
                    "smaller of the two).")
        self.dog_sigma2_ctrl = ParamControl(
            "Sigma 2", 0.1, 30.0, self._DOG_DEFAULT_SIGMA2, step=0.1, decimals=1,
            tooltip="Standard deviation of the second Gaussian blur (typically the "
                    "larger of the two). DoG = Gaussian(I, sigma1) - Gaussian(I, sigma2).")
        for c in (self.dog_sigma1_ctrl, self.dog_sigma2_ctrl):
            c.valueChanged.connect(self._schedule_recompute)
            c.setEnabled(False)
            layout.addWidget(c)

        self.dog_reset_btn = QPushButton("Reset to Defaults")
        self.dog_reset_btn.clicked.connect(self._reset_dog)
        layout.addWidget(self.dog_reset_btn)

        box.setLayout(layout)
        return box

    def _on_dog_toggled(self, _state):
        enabled = self.dog_enabled_checkbox.isChecked()
        self.dog_sigma1_ctrl.setEnabled(enabled)
        self.dog_sigma2_ctrl.setEnabled(enabled)
        self._schedule_recompute()

    def _reset_dog(self):
        self.dog_sigma1_ctrl.setValue(self._DOG_DEFAULT_SIGMA1)
        self.dog_sigma2_ctrl.setValue(self._DOG_DEFAULT_SIGMA2)
        self.dog_enabled_checkbox.setChecked(False)
        self._schedule_recompute()

    def _build_gdiv_group(self) -> QGroupBox:
        box = QGroupBox("2. Gaussian Division — optional")
        layout = QVBoxLayout()

        self.gdiv_enabled_checkbox = QCheckBox("Enable Gaussian Division")
        self.gdiv_enabled_checkbox.setChecked(False)
        self.gdiv_enabled_checkbox.stateChanged.connect(self._on_gdiv_toggled)
        layout.addWidget(self.gdiv_enabled_checkbox)

        self.gdiv_sigma_ctrl = ParamControl(
            "Sigma", 0.5, 50.0, self._GDIV_DEFAULT_SIGMA, step=0.5, decimals=1,
            tooltip="Standard deviation of the Gaussian used to estimate the local "
                    "illumination background. Output = I / (Gaussian(I, sigma) + epsilon).")
        self.gdiv_epsilon_ctrl = ParamControl(
            "Epsilon", 0.0001, 0.1, self._GDIV_DEFAULT_EPSILON, step=0.0001, decimals=4,
            tooltip="Small constant added to the denominator to avoid division by zero.")
        for c in (self.gdiv_sigma_ctrl, self.gdiv_epsilon_ctrl):
            c.valueChanged.connect(self._schedule_recompute)
            c.setEnabled(False)
            layout.addWidget(c)

        self.gdiv_reset_btn = QPushButton("Reset to Defaults")
        self.gdiv_reset_btn.clicked.connect(self._reset_gdiv)
        layout.addWidget(self.gdiv_reset_btn)

        box.setLayout(layout)
        return box

    def _on_gdiv_toggled(self, _state):
        enabled = self.gdiv_enabled_checkbox.isChecked()
        self.gdiv_sigma_ctrl.setEnabled(enabled)
        self.gdiv_epsilon_ctrl.setEnabled(enabled)
        self._schedule_recompute()

    def _reset_gdiv(self):
        self.gdiv_sigma_ctrl.setValue(self._GDIV_DEFAULT_SIGMA)
        self.gdiv_epsilon_ctrl.setValue(self._GDIV_DEFAULT_EPSILON)
        self.gdiv_enabled_checkbox.setChecked(False)
        self._schedule_recompute()

    def _build_preprocessing_group(self) -> QGroupBox:
        box = QGroupBox("3. Preprocessing (denoise)")
        layout = QVBoxLayout()

        self.pre_method_combo = QComboBox()
        self.pre_method_combo.addItems(["none", "gaussian", "median", "bilateral"])
        self.pre_method_combo.setCurrentText("gaussian")
        self.pre_method_combo.currentTextChanged.connect(self._schedule_recompute)
        layout.addWidget(QLabel("Method"))
        layout.addWidget(self.pre_method_combo)

        self.gaussian_sigma_ctrl = ParamControl(
            "Gaussian sigma", 0.0, 10.0, 1.0, step=0.1, decimals=1,
            tooltip="Standard deviation of the Gaussian smoothing kernel.")
        self.median_radius_ctrl = ParamControl(
            "Median disk radius", 1, 15, 2, step=1, decimals=0,
            tooltip="Radius of the disk structuring element for median filtering.")
        self.bilateral_sigma_color_ctrl = ParamControl(
            "Bilateral sigma (color)", 0.01, 1.0, 0.05, step=0.01, decimals=2)
        self.bilateral_sigma_spatial_ctrl = ParamControl(
            "Bilateral sigma (spatial)", 0.5, 20.0, 5.0, step=0.5, decimals=1)

        for c in (self.gaussian_sigma_ctrl, self.median_radius_ctrl,
                  self.bilateral_sigma_color_ctrl, self.bilateral_sigma_spatial_ctrl):
            c.valueChanged.connect(self._schedule_recompute)
            layout.addWidget(c)

        box.setLayout(layout)
        return box

    def _build_gradient_group(self) -> QGroupBox:
        box = QGroupBox("4. Gradient / Topographic Surface")
        layout = QVBoxLayout()

        self.grad_method_combo = QComboBox()
        self.grad_method_combo.addItems(["sobel", "scharr", "prewitt", "morphological"])
        self.grad_method_combo.currentTextChanged.connect(self._schedule_recompute)
        layout.addWidget(QLabel("Method"))
        layout.addWidget(self.grad_method_combo)

        self.grad_presmooth_ctrl = ParamControl(
            "Gradient presmoothing sigma", 0.0, 5.0, 0.0, step=0.1, decimals=1,
            tooltip="Extra Gaussian blur applied to the gradient surface itself, "
                    "useful for merging noisy micro-basins.")
        self.grad_morph_radius_ctrl = ParamControl(
            "Morphological gradient radius", 1, 10, 1, step=1, decimals=0,
            tooltip="Structuring-element radius used only when method='morphological'.")

        for c in (self.grad_presmooth_ctrl, self.grad_morph_radius_ctrl):
            c.valueChanged.connect(self._schedule_recompute)
            layout.addWidget(c)

        box.setLayout(layout)
        return box

    def _build_marker_group(self) -> QGroupBox:
        box = QGroupBox("5. Marker Generation (extrema-based, no threshold)")
        layout = QVBoxLayout()

        self.h_dark_ctrl = ParamControl(
            "Dark-defect sensitivity (h)", 0.001, 0.5, 0.03, step=0.001, decimals=3,
            tooltip="h-minima persistence depth. Smaller = more sensitive to shallow "
                    "dark defects (also more noise-prone).")
        self.h_bright_ctrl = ParamControl(
            "Bright-defect sensitivity (h)", 0.001, 0.5, 0.03, step=0.001, decimals=3,
            tooltip="h-maxima persistence depth for bright defects (spatter, over-melt).")
        self.h_background_ctrl = ParamControl(
            "Background flatness (h)", 0.001, 0.5, 0.05, step=0.001, decimals=3,
            tooltip="h-minima persistence depth applied to the gradient surface to "
                    "find flat, defect-free background plateaus.")
        self.marker_dilation_ctrl = ParamControl(
            "Marker dilation radius", 0, 10, 0, step=1, decimals=0,
            tooltip="Optional dilation of seed points to make them more robust.")
        self.marker_connectivity_combo = QComboBox()
        self.marker_connectivity_combo.addItems(["1 (4-connected)", "2 (8-connected)"])
        self.marker_connectivity_combo.setCurrentIndex(1)
        self.marker_connectivity_combo.currentIndexChanged.connect(self._schedule_recompute)

        for c in (self.h_dark_ctrl, self.h_bright_ctrl, self.h_background_ctrl,
                  self.marker_dilation_ctrl):
            c.valueChanged.connect(self._schedule_recompute)
            layout.addWidget(c)

        layout.addWidget(QLabel("Marker connectivity"))
        layout.addWidget(self.marker_connectivity_combo)

        box.setLayout(layout)
        return box

    def _build_watershed_group(self) -> QGroupBox:
        box = QGroupBox("6. Watershed Segmentation")
        layout = QVBoxLayout()

        self.ws_connectivity_combo = QComboBox()
        self.ws_connectivity_combo.addItems(["1 (4-connected)", "2 (8-connected)"])
        self.ws_connectivity_combo.setCurrentIndex(1)
        self.ws_connectivity_combo.currentIndexChanged.connect(self._schedule_recompute)
        layout.addWidget(QLabel("Watershed connectivity"))
        layout.addWidget(self.ws_connectivity_combo)

        self.ws_compactness_ctrl = ParamControl(
            "Compactness", 0.0, 1.0, 0.0, step=0.001, decimals=3,
            tooltip="Higher values favor more regularly-shaped (compact) catchment "
                    "basins (compact watershed).")
        self.ws_compactness_ctrl.valueChanged.connect(self._schedule_recompute)
        layout.addWidget(self.ws_compactness_ctrl)

        self.ws_line_checkbox = QCheckBox("Draw watershed lines")
        self.ws_line_checkbox.setChecked(True)
        self.ws_line_checkbox.stateChanged.connect(self._schedule_recompute)
        layout.addWidget(self.ws_line_checkbox)

        box.setLayout(layout)
        return box

    def _build_region_group(self) -> QGroupBox:
        box = QGroupBox("7. Region Analysis")
        layout = QVBoxLayout()
        self.min_area_ctrl = ParamControl(
            "Minimum defect area (px)", 1, 500, 5, step=1, decimals=0,
            tooltip="Regions smaller than this (excluding the background region) "
                    "are classified as noise rather than defects.")
        self.min_area_ctrl.valueChanged.connect(self._schedule_recompute)
        layout.addWidget(self.min_area_ctrl)
        box.setLayout(layout)
        return box

    def _build_overlay_group(self) -> QGroupBox:
        box = QGroupBox("8. Overlay")
        layout = QVBoxLayout()
        self.overlay_alpha_ctrl = ParamControl(
            "Overlay alpha", 0.0, 1.0, 0.4, step=0.05, decimals=2)
        self.overlay_alpha_ctrl.valueChanged.connect(self._schedule_recompute)
        layout.addWidget(self.overlay_alpha_ctrl)

        self.overlay_boundaries_checkbox = QCheckBox("Show watershed boundaries")
        self.overlay_boundaries_checkbox.setChecked(True)
        self.overlay_boundaries_checkbox.stateChanged.connect(self._schedule_recompute)
        layout.addWidget(self.overlay_boundaries_checkbox)

        box.setLayout(layout)
        return box

    def _build_tabs(self) -> QWidget:
        self.tabs = QTabWidget()

        self.tab_original = ImageTab("Original Image")
        self.tab_dog = ImageTab("Difference of Gaussian (DoG)")
        self.tab_gdiv = ImageTab("Gaussian Division")
        self.tab_preprocess = ImageTab("Preprocessed / Smoothed")
        self.tab_gradient = ImageTab("Gradient / Topographic Surface")
        self.tab_markers = MarkerTab()
        self.tab_watershed = ImageTab("Watershed Labels", cmap="nipy_spectral")
        self.tab_regions = RegionAnalysisTab()
        self.tab_overlay = ImageTab("Overlay: Detected Defects")
        self.tab_batch = BatchTab(get_params_callback=self._collect_params)

        self.tabs.addTab(self.tab_original, "1. Original")
        self.tabs.addTab(self.tab_dog, "2. DoG")
        self.tabs.addTab(self.tab_gdiv, "3. Gaussian Division")
        self.tabs.addTab(self.tab_preprocess, "4. Preprocessing")
        self.tabs.addTab(self.tab_gradient, "5. Gradient")
        self.tabs.addTab(self.tab_markers, "6. Markers")
        self.tabs.addTab(self.tab_watershed, "7. Watershed")
        self.tabs.addTab(self.tab_regions, "8. Region Analysis")
        self.tabs.addTab(self.tab_overlay, "9. Overlay")
        self.tabs.addTab(self.tab_batch, "Batch Processing")

        return self.tabs

    # -- Event handlers -------------------------------------------------

    def on_load_image(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Load Image", "",
            "Images (*.png *.jpg *.jpeg *.bmp *.tif *.tiff);;All Files (*)"
        )
        if not path:
            return
        try:
            self.rgb, self.gray = pl.load_image(path)
        except Exception as e:
            QMessageBox.critical(self, "Failed to load image", str(e))
            return

        self.tab_original.show_image(self.rgb, info=f"Shape: {self.gray.shape}  |  Source: {path}")
        self.save_btn.setEnabled(True)
        self.statusBar().showMessage(f"Loaded: {path}")
        self._recompute_pipeline()

    def on_save_overlay(self):
        if self._last_result is None:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Overlay", "overlay.png", "PNG Image (*.png)"
        )
        if not path:
            return
        from skimage.io import imsave
        from skimage.util import img_as_ubyte
        imsave(path, img_as_ubyte(np.clip(self._last_result.overlay, 0, 1)))
        self.statusBar().showMessage(f"Overlay saved to {path}")

    def _schedule_recompute(self, *_):
        if self.gray is None:
            return
        self._recompute_timer.start()

    # -- Pipeline execution ----------------------------------------------

    def _collect_params(self) -> pl.PipelineParams:
        return pl.PipelineParams(
            dog_enabled=self.dog_enabled_checkbox.isChecked(),
            dog_sigma1=self.dog_sigma1_ctrl.value(),
            dog_sigma2=self.dog_sigma2_ctrl.value(),
            gdiv_enabled=self.gdiv_enabled_checkbox.isChecked(),
            gdiv_sigma=self.gdiv_sigma_ctrl.value(),
            gdiv_epsilon=self.gdiv_epsilon_ctrl.value(),
            pre_method=self.pre_method_combo.currentText(),
            gaussian_sigma=self.gaussian_sigma_ctrl.value(),
            median_radius=int(self.median_radius_ctrl.value()),
            bilateral_sigma_color=self.bilateral_sigma_color_ctrl.value(),
            bilateral_sigma_spatial=self.bilateral_sigma_spatial_ctrl.value(),
            grad_method=self.grad_method_combo.currentText(),
            grad_presmooth_sigma=self.grad_presmooth_ctrl.value(),
            grad_morph_radius=int(self.grad_morph_radius_ctrl.value()),
            h_dark=self.h_dark_ctrl.value(),
            h_bright=self.h_bright_ctrl.value(),
            h_background=self.h_background_ctrl.value(),
            marker_dilation=int(self.marker_dilation_ctrl.value()),
            marker_connectivity=self.marker_connectivity_combo.currentIndex() + 1,
            ws_connectivity=self.ws_connectivity_combo.currentIndex() + 1,
            ws_compactness=self.ws_compactness_ctrl.value(),
            ws_watershed_line=self.ws_line_checkbox.isChecked(),
            min_area=int(self.min_area_ctrl.value()),
            overlay_show_boundaries=self.overlay_boundaries_checkbox.isChecked(),
            overlay_alpha=self.overlay_alpha_ctrl.value(),
        )

    def _recompute_pipeline(self):
        if self.gray is None:
            return
        params = self._collect_params()
        try:
            result = pl.run_pipeline(self.rgb, self.gray, params)
        except Exception as e:
            traceback.print_exc()
            self.statusBar().showMessage(f"Pipeline error: {e}")
            return

        self._last_result = result

        if result.dog_output is not None:
            self.tab_dog.show_image(
                result.dog_output,
                info=f"sigma1={params.dog_sigma1:.2f}, sigma2={params.dog_sigma2:.2f}")
        else:
            self.tab_dog.show_image(None, info="Disabled (bypassed)")

        if result.gdiv_output is not None:
            self.tab_gdiv.show_image(
                result.gdiv_output,
                info=f"sigma={params.gdiv_sigma:.2f}, epsilon={params.gdiv_epsilon:.4f}")
        else:
            self.tab_gdiv.show_image(None, info="Disabled (bypassed)")

        self.tab_preprocess.show_image(
            result.smoothed, info=f"method={params.pre_method}")
        self.tab_gradient.show_image(
            result.gradient, cmap="inferno",
            info=f"method={params.grad_method}, range=[{result.gradient.min():.3f}, {result.gradient.max():.3f}]")
        self.tab_markers.show_markers(
            result.smoothed, result.marker_result,
            info=(f"dark seeds: {result.marker_result.n_dark}   "
                  f"bright seeds: {result.marker_result.n_bright}"))
        n_labels = len(np.unique(result.labels))
        self.tab_watershed.show_image(
            result.labels, cmap="nipy_spectral",
            info=f"{n_labels} watershed regions (including background)")
        self.tab_regions.show_regions(result.region_result)
        n_defects = len(result.region_result.defect_labels)
        self.tab_overlay.show_image(
            result.overlay, info=f"{n_defects} defects highlighted")

        self.statusBar().showMessage(
            f"Pipeline updated — {n_labels} regions, {n_defects} classified as defects."
        )


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("AM Defect Detection")
    win = MainWindow()
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
