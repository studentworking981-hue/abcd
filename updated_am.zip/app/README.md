# AM Defect Detection — Watershed-Based Segmentation

A desktop application for detecting and segmenting defects (porosity,
lack-of-fusion voids, spatter, over-melt) in additive manufacturing
surface/layer images, built entirely around
`skimage.segmentation.watershed()` as the **only** segmentation
algorithm.

## Design constraint: no thresholding, anywhere

Every stage of the pipeline avoids intensity thresholding of any kind —
no global, adaptive, Otsu, multi-Otsu, Li, Yen, Triangle, Sauvola, or
Niblack thresholds, and no manual binary cut-offs. Region separation is
produced exclusively by watershed, seeded by markers derived from
**morphological extrema** (`skimage.morphology.extrema.h_minima` /
`h_maxima`), which are topological persistence operators rather than
pixel-value cut-offs:

* **Dark defects** (pits, porosity, lack-of-fusion) → local *minima* of
  the smoothed intensity surface.
* **Bright defects** (spatter, over-melt highlights) → local *maxima* of
  the smoothed intensity surface.
* **Background** seeds → flat, low-persistence-minima regions of the
  *gradient* surface (large texture-free plateaus).
* The **watershed line itself is the only "segmentation" decision** —
  everything else (denoising, gradient, marker extraction) is
  preprocessing/utility work explicitly permitted by the brief.

## Project layout

```
am_defect_app/
├── main.py              # entry point, dependency check
├── gui.py                # PyQt5 main window, 10 tabs, live parameter panel
├── widgets.py             # ParamControl: linked slider + numeric spin box
├── pipeline.py            # all image processing (skimage-only segmentation)
├── batch.py               # batch folder processing (QThread worker)
├── requirements.txt
├── utils/
│   └── make_test_image.py # generates a synthetic AM test image (I/O utility only)
└── README.md
```

## Installation

```bash
pip install -r requirements.txt
```

Requires: PyQt5, scikit-image, numpy, scipy, matplotlib, Pillow.

## Running

```bash
python main.py
```

If you don't have a sample AM image handy, generate a synthetic one
first:

```bash
python utils/make_test_image.py test_am_surface.png
```

Then click **Load Image…** in the app and pick that file.

## Using the application

The window has two parts:

* **Left panel** — every adjustable parameter, each with a slider AND a
  numeric spin box kept in sync. Any change immediately re-runs the
  whole pipeline and refreshes every image tab.
* **Center — 9 image/analysis tabs plus a Batch Processing tab**:

  1. **Original** — the loaded image as-is.
  2. **DoG** — optional Difference-of-Gaussian output (disabled by
     default; shows "Disabled (bypassed)" when off).
  3. **Gaussian Division** — optional illumination-flattening output
     (disabled by default; shows "Disabled (bypassed)" when off).
  4. **Preprocessing** — denoised/smoothed grayscale image (Gaussian,
     median, or bilateral filtering — smoothing only, never a mask).
     Runs on the DoG/Gaussian-Division output when those are enabled,
     otherwise on the original grayscale image — the existing
     Watershed pipeline itself is unchanged.
  5. **Gradient** — the topographic elevation surface watershed floods
     (Sobel / Scharr / Prewitt / morphological gradient).
  6. **Markers** — the smoothed image with dark-defect seeds (blue),
     bright-defect seeds (red), and background seeds (green) overlaid,
     so you can see exactly what watershed is being told to grow from.
  7. **Watershed** — the raw label image (`nipy_spectral` colormap),
     one color per catchment basin.
  8. **Region Analysis** — a `regionprops`-derived table (area, mean
     intensity, eccentricity, perimeter, equivalent diameter,
     solidity) with each region tagged `background` / `defect` /
     `noise` (noise = area below the "Minimum defect area" slider).
  9. **Overlay** — the original image with detected defects highlighted
     in color and (optionally) watershed boundary lines drawn on top.
  10. **Batch Processing** — run the entire pipeline above over every
      supported image in a folder (see below).

### Parameter groups

| Group | Parameters |
|---|---|
| Difference of Gaussian (DoG) — optional | enable checkbox, sigma 1, sigma 2, reset button |
| Gaussian Division — optional | enable checkbox, sigma, epsilon, reset button |
| Preprocessing | method (none/gaussian/median/bilateral), Gaussian sigma, median radius, bilateral sigma (color/spatial) |
| Gradient | method (sobel/scharr/prewitt/morphological), presmoothing sigma, morphological gradient radius |
| Markers | dark-defect sensitivity (h), bright-defect sensitivity (h), background flatness (h), marker dilation radius, marker connectivity |
| Watershed | connectivity, compactness, watershed-line toggle |
| Region Analysis | minimum defect area (px) |
| Overlay | alpha, boundary-line toggle |

Lower `h` values in the Markers group make the app more sensitive
(detects shallower/fainter defects, at the cost of more noise); higher
values make it more conservative.

### Optional Gaussian preprocessing (DoG / Gaussian Division)

Two independent, disabled-by-default preprocessing stages run **before**
the existing Watershed pipeline:

```
Input
 ↓
DoG (optional)              DoG = Gaussian(I, σ1) - Gaussian(I, σ2)
 ↓
Gaussian Division (optional) Output = I / (Gaussian(I, σ) + ε)
 ↓
Existing Watershed Pipeline (unchanged)
```

Each has its own **Enable/Disable** checkbox and **Reset to Defaults**
button in the left panel. Leave both unchecked to reproduce the
original app's behavior exactly. Both use `skimage.filters.gaussian`
under the hood (see `pipeline.difference_of_gaussian` and
`pipeline.gaussian_division`).

### Batch Processing

The **Batch Processing** tab runs the current parameter settings (from
the left panel, including any enabled DoG / Gaussian Division options)
over every supported image in a folder:

1. **Select Input Folder…** — folder containing images to process
   (`.png`, `.jpg`, `.jpeg`, `.bmp`, `.tif`, `.tiff`).
2. **Select Output Folder…** — where results are written.
3. **Start** — processes every supported image, one at a time, on a
   background thread so the GUI stays responsive.
4. **Cancel** — stops after the image currently in progress.

The progress bar, current-file label, and processed count update live;
if one image fails, the error is logged in the list below and
processing continues with the next image. A completion summary is
shown when the run finishes or is cancelled.

For each input image `Image1.ext`, a folder is created at
`OutputFolder/Image1/` containing every output the app already
generates: `original.png`, `dog_output.png` / `gaussian_division_output.png`
(only if enabled), `preprocessed.png`, `gradient.png`, `markers.png`,
`watershed_labels.png`, `defect_mask.png`, `overlay.png`, and
`regions.csv` (the full region-analysis table).

## Extending the pipeline

`pipeline.py` is written as small, independent, pure functions
(`preprocess`, `compute_gradient`, `generate_markers`, `run_watershed`,
`analyze_regions`, `build_overlay`), each returning plain numpy arrays.
To add a new gradient method, denoising filter, or region measurement,
extend the relevant function's `if/elif` chain and add a matching
`ParamControl` in `gui.py` — the rest of the app (tabs, live updates,
overlay) needs no changes.
