# AM Defect Detection — Watershed-Based Segmentation

A desktop application for detecting and segmenting defects (porosity,
lack-of-fusion voids, spatter, over-melt) in additive manufacturing
surface/layer images, built entirely around
`skimage.segmentation.watershed()` as the **only** segmentation
algorithm.

## Design constraint: no thresholding, anywhere

Every stage of the pipeline avoids intensity thresholding of any kind —
no global, adaptive, Otsu, multi-Otsu, Li, Yen, Triangle, Sauvola, or
Niblack thresholds, and no manual binary cut-offs. Region separation is
produced exclusively by watershed, seeded by markers derived from
**morphological extrema** (`skimage.morphology.extrema.h_minima` /
`h_maxima`), which are topological persistence operators rather than
pixel-value cut-offs:

* **Dark defects** (pits, porosity, lack-of-fusion) → local *minima* of
  the smoothed intensity surface.
* **Bright defects** (spatter, over-melt highlights) → local *maxima* of
  the smoothed intensity surface.
* **Background** seeds → flat, low-persistence-minima regions of the
  *gradient* surface (large texture-free plateaus).
* The **watershed line itself is the only "segmentation" decision** —
  everything else (denoising, gradient, marker extraction) is
  preprocessing/utility work explicitly permitted by the brief.

## Project layout

```
am_defect_app/
├── main.py              # entry point, dependency check
├── gui.py                # PyQt5 main window, 7 tabs, live parameter panel
├── widgets.py             # ParamControl: linked slider + numeric spin box
├── pipeline.py            # all image processing (skimage-only segmentation)
├── requirements.txt
├── utils/
│   └── make_test_image.py # generates a synthetic AM test image (I/O utility only)
└── README.md
```

## Installation

```bash
pip install -r requirements.txt
```

Requires: PyQt5, scikit-image, numpy, scipy, matplotlib, Pillow.

## Running

```bash
python main.py
```

If you don't have a sample AM image handy, generate a synthetic one
first:

```bash
python utils/make_test_image.py test_am_surface.png
```

Then click **Load Image…** in the app and pick that file.

## Using the application

The window has two parts:

* **Left panel** — every adjustable parameter, each with a slider AND a
  numeric spin box kept in sync. Any change immediately re-runs the
  whole pipeline and refreshes all seven tabs.
* **Center — 7 tabs**, one per pipeline stage:

  1. **Original** — the loaded image as-is.
  2. **Preprocessing** — denoised/smoothed grayscale image (Gaussian,
     median, or bilateral filtering — smoothing only, never a mask).
  3. **Gradient** — the topographic elevation surface watershed floods
     (Sobel / Scharr / Prewitt / morphological gradient).
  4. **Markers** — the smoothed image with dark-defect seeds (blue),
     bright-defect seeds (red), and background seeds (green) overlaid,
     so you can see exactly what watershed is being told to grow from.
  5. **Watershed** — the raw label image (`nipy_spectral` colormap),
     one color per catchment basin.
  6. **Region Analysis** — a `regionprops`-derived table (area, mean
     intensity, eccentricity, perimeter, equivalent diameter,
     solidity) with each region tagged `background` / `defect` /
     `noise` (noise = area below the "Minimum defect area" slider).
  7. **Overlay** — the original image with detected defects highlighted
     in color and (optionally) watershed boundary lines drawn on top.

### Parameter groups

| Group | Parameters |
|---|---|
| Preprocessing | method (none/gaussian/median/bilateral), Gaussian sigma, median radius, bilateral sigma (color/spatial) |
| Gradient | method (sobel/scharr/prewitt/morphological), presmoothing sigma, morphological gradient radius |
| Markers | dark-defect sensitivity (h), bright-defect sensitivity (h), background flatness (h), marker dilation radius, marker connectivity |
| Watershed | connectivity, compactness, watershed-line toggle |
| Region Analysis | minimum defect area (px) |
| Overlay | alpha, boundary-line toggle |

Lower `h` values in the Markers group make the app more sensitive
(detects shallower/fainter defects, at the cost of more noise); higher
values make it more conservative.

## Extending the pipeline

`pipeline.py` is written as small, independent, pure functions
(`preprocess`, `compute_gradient`, `generate_markers`, `run_watershed`,
`analyze_regions`, `build_overlay`), each returning plain numpy arrays.
To add a new gradient method, denoising filter, or region measurement,
extend the relevant function's `if/elif` chain and add a matching
`ParamControl` in `gui.py` — the rest of the app (tabs, live updates,
overlay) needs no changes.
