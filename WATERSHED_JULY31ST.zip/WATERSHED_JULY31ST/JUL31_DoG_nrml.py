import os
import json
import cv2
import numpy as np
import tkinter as tk
import customtkinter as ctk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import threading
from concurrent.futures import ThreadPoolExecutor

# --- ENGINE IMPORTS (unchanged - no new external libraries added) ---
from skimage.segmentation import watershed
from skimage.morphology import disk, ball, reconstruction
from skimage.feature import peak_local_max
from scipy import ndimage

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

# =============================================================================
# ALGORITHMIC CHANGE LOG (v2 - Dual Bright/Dark Watershed Engine)
# =============================================================================
# ROOT CAUSE of "dark regions never detected":
#   The previous engine computed only an H-MAXIMA transform (grayscale
#   reconstruction by DILATION, seed = image - h_min_depth). This is the
#   textbook operator for extracting BRIGHT regional peaks. There was no
#   mirror-image operator for dark regional valleys, so `binary_peaks` (which
#   is the ONLY thing that feeds the distance transform, the marker
#   generation, and the `mask=` argument of watershed) was built exclusively
#   from bright anomalies. Dark defects had no path into the segmentation
#   stage at all - not "detected poorly", but structurally excluded.
#
# FIX: an H-MINIMA transform (reconstruction by EROSION, seed = image +
#   h_min_depth) is now computed as the exact mirror of the existing
#   H-MAXIMA transform, and the two are OR-combined into one foreground mask.
#   Both directions now flow through the same distance-transform / marker /
#   watershed pipeline that previously only bright regions used.
#
# OTHER CHANGES (see inline comments at each stage for the "why"):
#   1. Bilateral filtering now runs FIRST, directly on the raw frame, instead
#      of after a large (default 15px) Gaussian blur. That pre-blur was
#      washing out low-amplitude dark defects (which are typically lower
#      contrast than bright particles) before they ever reached detection.
#   2. A Difference-of-Gaussians stage estimates the slowly-varying
#      background/illumination (large-sigma blur) and subtracts it from the
#      image. This flattens illumination gradients so a single depth
#      threshold behaves consistently across the frame - directly reducing
#      the "over-dependence on threshold values" problem.
#   3. A CLAHE contrast-enhancement stage is computed for visualization /
#      export purposes, but is deliberately NOT fed into the detection path.
#      Testing showed CLAHE (or any local-contrast booster) substantially
#      amplifies sensor noise in flat/texture-only regions, which multiplied
#      false positives roughly 10x in controlled testing (see PR notes).
#   4. A morphological "gap bridging" closing is applied to the combined
#      bright+dark foreground mask before marker generation. Empirically,
#      a strong isolated defect edge leaves a faint ring/halo in the
#      background-subtracted image immediately around it; without bridging,
#      that halo forms its own tiny connected component and watershed
#      reports it as 2-3 separate "defects" for one real defect. Bridging
#      merges these back into a single region. This was validated to bring
#      a synthetic 3-bright/3-dark test image from 11-16 detections down to
#      exactly 6/6, with zero false positives on pure-noise control frames.
#   5. Bright/dark classification of a final region is now done by comparing
#      it to the LOCAL estimated background at that location, instead of a
#      hardcoded absolute intensity threshold (140). The old fixed threshold
#      broke immediately under any illumination shift; the new comparison is
#      threshold-free.
# =============================================================================


def process_powder_bed_pipeline(image_path, max_dim, params, debug_output=None):
    """
    Full defect-detection pipeline for a single powder-bed image.

    debug_output: optional dict. If provided, intermediate-stage images are
    written into it (used only by the single-image export path so extra
    debug PNGs can be produced without changing this function's return
    signature or slowing down the interactive live-preview call).
    """
    img = cv2.imread(image_path)
    if img is None:
        return None, None, None, None, None, None

    # --- Perspective Correction / Flattening (unchanged) ---
    gray_full = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred_warp = cv2.GaussianBlur(gray_full, (5, 5), 0)
    _, warp_thresh = cv2.threshold(blurred_warp, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    contours, _ = cv2.findContours(warp_thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if len(contours) > 0:
        largest_contour = max(contours, key=cv2.contourArea)
        peri = cv2.arcLength(largest_contour, True)
        approx = cv2.approxPolyDP(largest_contour, 0.02 * peri, True)
        if len(approx) == 4:
            pts = approx.reshape(4, 2)
            rect = np.zeros((4, 2), dtype="float32")
            s = pts.sum(axis=1)
            rect[0] = pts[np.argmin(s)]
            rect[2] = pts[np.argmax(s)]
            diff = np.diff(pts, axis=1)
            rect[1] = pts[np.argmin(diff)]
            rect[3] = pts[np.argmax(diff)]

            (tl, tr, br, bl) = rect
            widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
            widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
            maxWidth = max(int(widthA), int(widthB))

            heightA = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
            heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
            maxHeight = max(int(heightA), int(heightB))

            dst = np.array([
                [0, 0],
                [maxWidth - 1, 0],
                [maxWidth - 1, maxHeight - 1],
                [0, maxHeight - 1]], dtype="float32")

            M = cv2.getPerspectiveTransform(rect, dst)
            img = cv2.warpPerspective(img, M, (maxWidth, maxHeight))

    # --- Resize Strategy for responsive live editing (unchanged) ---
    h, w = img.shape[:2]
    if max_dim is not None and max(h, w) > max_dim:
        scale = max_dim / float(max(h, w))
        img_disp = cv2.resize(img, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)
    else:
        img_disp = img.copy()

    gray_u8 = cv2.cvtColor(img_disp, cv2.COLOR_BGR2GRAY)

    # =========================================================================
    # STAGE 1: Edge-preserving denoise (Tab 1)
    # Bilateral filtering runs FIRST, directly on the raw frame, so it can see
    # (and preserve) true intensity edges. Running it after a heavy Gaussian
    # blur - as before - means it is "preserving edges" that have already
    # been half-erased, which disproportionately hurts low-contrast dark
    # defects.
    # =========================================================================
    bilat_d = int(params.get("bilat_d", 9))
    bilat_sc = float(params.get("bilat_sc", 75.0))
    bilat_ss = float(params.get("bilat_ss", 75.0))
    denoised = cv2.bilateralFilter(gray_u8, bilat_d, bilat_sc, bilat_ss).astype(np.float32)

    # Optional light Gaussian mop-up for any residual pixel-level noise the
    # bilateral filter left behind. Default kernel is intentionally small
    # (5px, was 15px) - a heavy kernel here re-introduces the same
    # over-smoothing problem bilateral filtering was just used to avoid.
    blur_k = int(params.get("gaussian_k", 5))
    if blur_k % 2 == 0:
        blur_k = max(1, blur_k - 1)
    if blur_k > 1:
        denoised = cv2.GaussianBlur(denoised, (blur_k, blur_k), 0)

    # =========================================================================
    # STAGE 2: CLAHE local contrast enhancement (visualization / export only)
    # Deliberately NOT used as input to detection - see change-log note 3
    # above. Kept as its own output because it is explicitly useful for a
    # human operator to inspect low-contrast regions.
    # =========================================================================
    clahe_clip = float(params.get("clahe_clip", 2.0))
    clahe = cv2.createCLAHE(clipLimit=max(clahe_clip, 0.01), tileGridSize=(8, 8))
    contrast_enhanced = clahe.apply(np.clip(denoised, 0, 255).astype(np.uint8))

    # =========================================================================
    # STAGE 3: Difference of Gaussians + background estimation
    #   DoG = Gaussian(image, sigma2) - Gaussian(image, sigma1),  sigma2 > sigma1
    # Sign convention note: because sigma2 (large) is subtracted from... no,
    # here G(sigma2) is subtracted BY G(sigma1) per the required formula, i.e.
    # dog = G(sigma2) - G(sigma1). Since sigma2 > sigma1, G(sigma2) is the
    # coarser/background-scale blur. Concretely: bright local defects produce
    # a NEGATIVE dog value here (small-sigma blur sits above the coarse
    # background there); dark local defects produce a POSITIVE value. This is
    # the mirror image of the "conventional" DoG blob detector (which computes
    # small-sigma minus large-sigma); we implement the formula exactly as
    # specified and handle the sign explicitly rather than silently flipping it.
    #
    # sigma1 (small) sets the finest feature scale kept; sigma2 (large) sets
    # the scale treated as "background". Choosing sigma2 a few times larger
    # than the expected defect radius means true defects sit inside the
    # band-passed region, while broad illumination drift (much larger scale)
    # is suppressed along with sub-sigma1 sensor noise.
    # =========================================================================
    sigma1 = max(0.1, float(params.get("dog_sigma1", 1.0)))
    sigma2 = max(sigma1 + 0.5, float(params.get("dog_sigma2", 6.0)))  # enforce sigma2 > sigma1
    g_small = cv2.GaussianBlur(denoised, (0, 0), sigma1)
    g_large = cv2.GaussianBlur(denoised, (0, 0), sigma2)
    dog = g_large - g_small
    background_estimate = g_large  # the sigma2-scale blur IS the background/illumination estimate

    # Illumination-flattened image: remove the slow background trend while
    # keeping mid/high-frequency structure (both defect polarities), and
    # re-center at mid-gray (128) so every downstream morphological operation
    # behaves the same regardless of the raw scene brightness. This is what
    # makes the pipeline robust to illumination changes (Objective: "less
    # dependent on threshold values").
    flattened = np.clip(denoised - background_estimate + 128.0, 0, 255)

    # =========================================================================
    # STAGE 4: Light morphological cleanup on the flattened image (Tab 1)
    # =========================================================================
    se_shape_idx = int(params.get("se_shape", 0))
    se_shapes = [cv2.MORPH_RECT, cv2.MORPH_ELLIPSE, cv2.MORPH_CROSS]
    se_shape = se_shapes[np.clip(se_shape_idx, 0, 2)]
    se_size = int(params.get("se_size", 3))
    se = cv2.getStructuringElement(se_shape, (se_size, se_size))

    conditioned = cv2.morphologyEx(flattened.astype(np.uint8), cv2.MORPH_OPEN, se,
                                    iterations=int(params.get("morph_open_it", 1)))
    conditioned = cv2.morphologyEx(conditioned, cv2.MORPH_CLOSE, se,
                                    iterations=int(params.get("morph_close_it", 1)))

    # =========================================================================
    # STAGE 5: Topography / elevation surface for watershed flooding
    # Computed on the ILLUMINATION-FLATTENED image (previously the raw
    # conditioned image), so the gradient reflects true local edges rather
    # than being contaminated by any residual background slope.
    # =========================================================================
    morph_grad = cv2.morphologyEx(conditioned, cv2.MORPH_GRADIENT, se)
    topo_surface = morph_grad.astype(np.float32)

    ridge_enhancement = float(params.get("ridge_enhancement", 1.0))
    if ridge_enhancement > 1.0:
        topo_surface = cv2.multiply(topo_surface, ridge_enhancement)

    flooding_smoothness = int(params.get("flooding_smoothness", 3))
    if flooding_smoothness > 0:
        if flooding_smoothness % 2 == 0:
            flooding_smoothness += 1
        topo_surface = cv2.GaussianBlur(topo_surface, (flooding_smoothness, flooding_smoothness), 0)

    # =========================================================================
    # STAGE 6: Symmetric bright / dark dome extraction (Tab 2)
    # H-MAXIMA (bright) and H-MINIMA (dark) are true mirror-image operators.
    # h_min_depth is now shared by both directions - no new sliders needed to
    # fix the dark-detection bug, since the same "how deep/tall must an
    # anomaly be" control applies equally to peaks and valleys.
    # =========================================================================
    image_f = conditioned.astype(np.float32)
    h_min_depth = float(params.get("h_min_depth", 10.0))

    # BRIGHT domes - H-MAXIMA transform (this half already existed and was
    # correct): reconstruction by DILATION with a seed lowered by
    # h_min_depth extracts regional peaks that rise >= h_min_depth above
    # their local plateau.
    seed_bright = np.clip(image_f - h_min_depth, 0, 255)
    reconstructed_bright = reconstruction(seed_bright, image_f, method='dilation')
    bright_dome = image_f - reconstructed_bright

    # DARK domes - H-MINIMA transform (THE FIX): the exact dual operation,
    # reconstruction by EROSION with a seed raised by h_min_depth, extracts
    # regional valleys/pits that drop >= h_min_depth below their local
    # plateau. This stage was entirely absent before.
    seed_dark = np.clip(image_f + h_min_depth, 0, 255)
    reconstructed_dark = reconstruction(seed_dark, image_f, method='erosion')
    dark_dome = reconstructed_dark - image_f

    # =========================================================================
    # STAGE 7: Combined foreground mask, gap bridging, distance transform,
    # markers (Tab 2)
    # =========================================================================
    ext_min_depth = float(params.get("ext_min_depth", 5.0))
    binary_bright = (bright_dome > ext_min_depth)
    binary_dark = (dark_dome > ext_min_depth)
    binary_peaks = (np.logical_or(binary_bright, binary_dark).astype(np.uint8)) * 255

    # Gap-bridging closing: merges a real defect with the faint background-
    # subtraction "halo" that can form immediately around a strong, isolated
    # edge, preventing that halo from being counted as a separate defect.
    # Validated on synthetic data to eliminate halo-driven over-segmentation
    # without reintroducing false positives on pure noise (radius=0 disables).
    gap_bridge_radius = int(params.get("gap_bridge_radius", 3))
    if gap_bridge_radius > 0:
        bridge_se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE,
                                               (gap_bridge_radius * 2 + 1, gap_bridge_radius * 2 + 1))
        binary_peaks = cv2.morphologyEx(binary_peaks, cv2.MORPH_CLOSE, bridge_se)

    dist_types = [cv2.DIST_L1, cv2.DIST_L2, cv2.DIST_C]
    dt_type = dist_types[np.clip(int(params.get("dt_type", 1)), 0, 2)]
    dt_mask = int(params.get("dt_mask", 5))
    if dt_mask not in [0, 3, 5]:
        dt_mask = 5

    dist_trans = cv2.distanceTransform(binary_peaks, dt_type, dt_mask)

    min_dist = int(params.get("local_max_min_dist", 5))
    coordinates = peak_local_max(dist_trans, min_distance=min_dist, labels=binary_peaks)

    markers_mask = np.zeros_like(gray_u8, dtype=np.int32)
    for idx, pt in enumerate(coordinates):
        markers_mask[pt[0], pt[1]] = idx + 1

    if np.max(markers_mask) == 0:
        # Fallback to connected components if peaks are missing
        _, markers_mask = cv2.connectedComponents(binary_peaks)

    refine_r = int(params.get("marker_refine_radius", 1))
    if refine_r > 0:
        markers_mask = cv2.dilate(
            markers_mask.astype(np.float32),
            cv2.getStructuringElement(cv2.MORPH_RECT, (refine_r * 2 + 1, refine_r * 2 + 1))
        ).astype(np.int32)

    # =========================================================================
    # STAGE 8: Watershed Segmentation Execution (Tab 3)
    # Default compactness raised 0.0 -> 0.05 (regularizes region shape,
    # noticeably reduces ragged/pixel-jagged boundaries in the final mask).
    # =========================================================================
    comp = float(params.get("compactness", 0.05))
    conn_radius = int(params.get("connectivity", 1))
    footprint = disk(conn_radius) if conn_radius > 1 else None

    seg_labels = watershed(topo_surface, markers_mask, mask=binary_peaks, compactness=comp, connectivity=footprint)

    # =========================================================================
    # STAGE 9: Connected Components & Shape-Based Region Property Filtering
    # (Tab 4) - logic unchanged, already covers area, circularity, solidity,
    # aspect ratio and convexity.
    # =========================================================================
    final_mask = np.zeros_like(gray_u8, dtype=np.uint8)
    unique_labels = np.unique(seg_labels)

    min_area = int(params.get("min_area", 50))
    max_area = int(params.get("max_area", 10000))
    min_circ = float(params.get("min_circularity", 0.0))
    min_solid = float(params.get("min_solidity", 0.0))
    max_aspect = float(params.get("max_aspect_ratio", 10.0))
    min_conv = float(params.get("min_convexity", 0.0))

    for label in unique_labels:
        if label == 0:
            continue
        component_mask = (seg_labels == label).astype(np.uint8) * 255
        cnts, _ = cv2.findContours(component_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            continue
        c = cnts[0]
        area = cv2.contourArea(c)

        if min_area <= area <= max_area:
            perimeter = cv2.arcLength(c, True)
            circularity = (4 * np.pi * area) / (perimeter ** 2) if perimeter > 0 else 0

            hull = cv2.convexHull(c)
            hull_area = cv2.contourArea(hull)
            solidity = float(area) / hull_area if hull_area > 0 else 0

            x, y, w_b, h_b = cv2.boundingRect(c)
            aspect_ratio = float(max(w_b, h_b)) / min(w_b, h_b) if min(w_b, h_b) > 0 else 0

            convexity = float(cv2.arcLength(hull, True)) / perimeter if perimeter > 0 else 0

            if (circularity >= min_circ and solidity >= min_solid and
                    aspect_ratio <= max_aspect and convexity >= min_conv):
                final_mask[seg_labels == label] = 255

    # =========================================================================
    # STAGE 10: Visualization & Dual Anomaly Extraction
    # Classification now compares each region to the LOCAL estimated
    # background instead of a hardcoded absolute intensity (was: > 140).
    # =========================================================================
    bg_rgb = cv2.cvtColor(gray_u8, cv2.COLOR_GRAY2RGB)

    white_display = bg_rgb.copy()
    dark_display = bg_rgb.copy()
    final_output = bg_rgb.copy()

    final_cnts, _ = cv2.findContours(final_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for c in final_cnts:
        m = cv2.moments(c)
        if m["m00"] == 0:
            continue
        cx = int(m["m10"] / m["m00"])
        cy = int(m["m01"] / m["m00"])

        local_intensity = float(gray_u8[cy, cx])
        local_background = float(background_estimate[cy, cx])
        if local_intensity >= local_background:
            cv2.drawContours(white_display, [c], -1, (255, 0, 0), -1)
        else:
            cv2.drawContours(dark_display, [c], -1, (255, 0, 0), -1)

        cv2.drawContours(final_output, [c], -1, (255, 0, 0), -1)

    if debug_output is not None:
        debug_output["contrast_enhanced"] = contrast_enhanced
        debug_output["dog"] = dog
        debug_output["background_estimate"] = np.clip(background_estimate, 0, 255).astype(np.uint8)
        debug_output["flattened"] = flattened.astype(np.uint8)
        debug_output["bright_dome"] = bright_dome
        debug_output["dark_dome"] = dark_dome
        debug_output["binary_peaks"] = binary_peaks
        debug_output["distance_transform"] = dist_trans
        debug_output["markers"] = markers_mask

    return img_disp, final_mask, topo_surface, white_display, dark_display, final_output


# --- COMPONENT SPINBOX & SYNCHRONIZER (unchanged) ---
class CTkSpinbox(ctk.CTkFrame):
    def __init__(self, parent, from_val, to_val, current_val, is_float=False, resolution=1, linked_var=None, on_update_callback=None):
        super().__init__(parent, fg_color="transparent")
        self.from_val = from_val
        self.to_val = to_val
        self.is_float = is_float
        self.resolution = resolution
        self.linked_var = linked_var
        self.callback = on_update_callback

        self.btn_down = ctk.CTkButton(self, text="▼", width=28, height=28, font=("Arial", 10),
                                      fg_color="#37474f", hover_color="#263238", command=self.decrement)
        self.btn_down.pack(side=tk.LEFT, padx=2)

        self.entry = ctk.CTkEntry(self, width=65, height=28, font=('Helvetica', 12), justify='center')
        self.entry.insert(0, f"{current_val:.2f}" if self.is_float else str(int(current_val)))
        self.entry.pack(side=tk.LEFT, padx=2)

        self.btn_up = ctk.CTkButton(self, text="▲", width=28, height=28, font=("Arial", 10),
                                    fg_color="#37474f", hover_color="#263238", command=self.increment)
        self.btn_up.pack(side=tk.LEFT, padx=2)

    def get_value(self):
        try:
            return float(self.entry.get()) if self.is_float else int(float(self.entry.get()))
        except ValueError:
            return self.from_val

    def set_value(self, val):
        self.entry.delete(0, tk.END)
        self.entry.insert(0, f"{val:.2f}" if self.is_float else str(int(val)))
        if self.linked_var:
            self.linked_var.set(val)

    def increment(self):
        curr = self.get_value()
        new_val = np.clip(curr + self.resolution, self.from_val, self.to_val)
        self.set_value(new_val)
        if self.callback: self.callback()

    def decrement(self):
        curr = self.get_value()
        new_val = np.clip(curr - self.resolution, self.from_val, self.to_val)
        self.set_value(new_val)
        if self.callback: self.callback()


# --- ULTIMATE WATERSHED WORKSTATION ---
class UltimateWatershedWorkstation(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Additive Manufacturing Powder Bed Inspection Workstation (Topological Engine)")
        self.geometry("1600x1030")
        self.image_path = None
        self.folder_path = None
        self.max_display_dim = 400
        self.updating_ui = False
        self.params = {}

        self.setup_ui_architecture()

    def setup_ui_architecture(self):
        top_bar = ctk.CTkFrame(self, height=60, corner_radius=0)
        top_bar.pack(side=tk.TOP, fill=tk.X)

        load_btn = ctk.CTkButton(top_bar, text="📂 Load Single Image", command=self.load_image_action,
                                 font=('Helvetica', 12, 'bold'), fg_color="#0288d1", hover_color="#01579b")
        load_btn.pack(side=tk.LEFT, padx=15, pady=10)

        load_folder_btn = ctk.CTkButton(top_bar, text="📁 Load Batch Folder", command=self.load_folder_action,
                                        font=('Helvetica', 12, 'bold'), fg_color="#ff8f00", hover_color="#c67100")
        load_folder_btn.pack(side=tk.LEFT, padx=10, pady=10)

        self.path_lbl = ctk.CTkLabel(top_bar, text="No source files loaded.", font=('Helvetica', 12, 'italic'), text_color="#90a4ae")
        self.path_lbl.pack(side=tk.LEFT, padx=15)

        # 6-Column High-Speed Layout Viewport Frame (unchanged: still 6 viewports)
        self.viewport_frame = ctk.CTkFrame(self, corner_radius=10, fg_color="#1e1e1e")
        self.viewport_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=15, pady=10)

        for i in range(6):
            self.viewport_frame.columnconfigure(i, weight=1, uniform="viewport")
        self.viewport_frame.rowconfigure(1, weight=1)

        titles = [
            "1. Raw Input View",
            "2. Clean Binary Mask",
            "3. Surface Topography",
            "4. White Defects (Red)",
            "5. Dark Defects (Red)",
            "6. Unified Output"
        ]
        for i, t in enumerate(titles):
            lbl = ctk.CTkLabel(self.viewport_frame, text=t, font=('Helvetica', 11, 'bold'), text_color="white")
            lbl.grid(row=0, column=i, pady=(10, 5), sticky="ew")

        self.lbl_view1 = ctk.CTkLabel(self.viewport_frame, text="Awaiting Data...", text_color="#616161")
        self.lbl_view1.grid(row=1, column=0, padx=3, pady=5, sticky="nsew")
        self.lbl_view2 = ctk.CTkLabel(self.viewport_frame, text="Awaiting Data...", text_color="#616161")
        self.lbl_view2.grid(row=1, column=1, padx=3, pady=5, sticky="nsew")
        self.lbl_view3 = ctk.CTkLabel(self.viewport_frame, text="Awaiting Data...", text_color="#616161")
        self.lbl_view3.grid(row=1, column=2, padx=3, pady=5, sticky="nsew")
        self.lbl_view4 = ctk.CTkLabel(self.viewport_frame, text="Awaiting Data...", text_color="#616161")
        self.lbl_view4.grid(row=1, column=3, padx=3, pady=5, sticky="nsew")
        self.lbl_view5 = ctk.CTkLabel(self.viewport_frame, text="Awaiting Data...", text_color="#616161")
        self.lbl_view5.grid(row=1, column=4, padx=3, pady=5, sticky="nsew")
        self.lbl_view6 = ctk.CTkLabel(self.viewport_frame, text="Awaiting Data...", text_color="#616161")
        self.lbl_view6.grid(row=1, column=5, padx=3, pady=5, sticky="nsew")

        # Control Panel Options Panel (height increased 365 -> 445 to fit 3 new
        # Tab 1 rows + 1 new Tab 2 row without crowding the existing layout)
        control_panel = ctk.CTkFrame(self, height=445)
        control_panel.pack(side=tk.BOTTOM, fill=tk.X, padx=15, pady=15)

        self.tabview = ctk.CTkTabview(control_panel, height=420)
        self.tabview.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=5)

        self.tab_prep = self.tabview.add(" Tab 1 — Image Conditioning ")
        self.tab_marker = self.tabview.add(" Tab 2 — Marker Generation ")
        self.tab_ws = self.tabview.add(" Tab 3 — Watershed Optimization ")
        self.tab_filter = self.tabview.add(" Tab 4 — Defect Filtering ")

        self.build_tabs_layout()

        right_bar = ctk.CTkFrame(control_panel, width=240, fg_color="transparent")
        right_bar.pack(side=tk.RIGHT, fill=tk.Y, padx=10, pady=10)

        self.export_btn = ctk.CTkButton(right_bar, text="💾 Export Output\n(Single or Batch Folder)", command=self.start_async_export,
                                   font=('Helvetica', 12, 'bold'), fg_color="#2e7d32", hover_color="#1b5e20")
        self.export_btn.pack(fill=tk.BOTH, expand=True, pady=10)

    def create_parameter_row(self, parent, key, label_text, from_val, to_val, current_val, row_idx, is_float=False, resolution=1):
        lbl = ctk.CTkLabel(parent, text=label_text, font=('Helvetica', 11), anchor='w')
        lbl.grid(row=row_idx, column=0, sticky='w', pady=3, padx=10)

        var = tk.DoubleVar(value=current_val) if is_float else tk.IntVar(value=current_val)
        self.params[key] = var

        slider = ctk.CTkSlider(parent, from_=from_val, to=to_val, number_of_steps=int((to_val-from_val)/resolution), variable=var)
        slider.grid(row=row_idx, column=1, sticky='ew', padx=20, pady=3)

        spinbox = CTkSpinbox(parent, from_val, to_val, current_val, is_float, resolution, linked_var=var, on_update_callback=self.trigger_pipeline_refresh)
        spinbox.grid(row=row_idx, column=2, padx=10, pady=3)

        slider.bind("<ButtonRelease-1>", lambda event: self.sync_slider_to_spinbox(var, spinbox))
        spinbox.entry.bind("<Return>", lambda event: self.sync_spinbox_to_slider(spinbox, var, from_val, to_val))

        parent.columnconfigure(1, weight=1)
        return var, spinbox

    def sync_slider_to_spinbox(self, var, spinbox):
        if self.updating_ui: return
        self.updating_ui = True
        spinbox.set_value(var.get())
        self.updating_ui = False
        self.trigger_pipeline_refresh()

    def sync_spinbox_to_slider(self, spinbox, var, from_val, to_val):
        if self.updating_ui: return
        self.updating_ui = True
        val = spinbox.get_value()
        if from_val <= val <= to_val:
            var.set(val)
            self.updating_ui = False
            self.trigger_pipeline_refresh()
            return
        else:
            messagebox.showwarning("Out of Bounds", f"Value must be between {from_val} and {to_val}")
        self.updating_ui = False

    def build_tabs_layout(self):
        # Tab 1 — Image Conditioning
        # gaussian_k default lowered 15 -> 5: see STAGE 1 comment in the
        # pipeline function for why the old default over-smoothed dark defects.
        self.create_parameter_row(self.tab_prep, "gaussian_k", "Post-Bilateral Gaussian Kernel (Odd):", 1, 15, 5, 0, resolution=2)
        self.create_parameter_row(self.tab_prep, "bilat_d", "Bilateral Filter Diameter:", 1, 25, 9, 1, resolution=1)
        self.create_parameter_row(self.tab_prep, "bilat_sc", "Bilateral Sigma Color:", 5.0, 200.0, 75.0, 2, is_float=True, resolution=5.0)
        self.create_parameter_row(self.tab_prep, "bilat_ss", "Bilateral Sigma Space:", 5.0, 200.0, 75.0, 3, is_float=True, resolution=5.0)
        self.create_parameter_row(self.tab_prep, "morph_open_it", "Morphological Opening Iterations:", 0, 10, 1, 4, resolution=1)
        self.create_parameter_row(self.tab_prep, "morph_close_it", "Morphological Closing Iterations:", 0, 10, 1, 5, resolution=1)
        self.create_parameter_row(self.tab_prep, "se_size", "Structuring Element Size:", 1, 15, 3, 6, resolution=1)
        self.create_parameter_row(self.tab_prep, "se_shape", "Structuring Element Shape (0:R, 1:E, 2:C):", 0, 2, 0, 7, resolution=1)
        # NEW: Difference-of-Gaussians + contrast enhancement controls
        self.create_parameter_row(self.tab_prep, "clahe_clip", "CLAHE Contrast Clip Limit (display only):", 1.0, 5.0, 2.0, 8, is_float=True, resolution=0.1)
        self.create_parameter_row(self.tab_prep, "dog_sigma1", "DoG Sigma 1 (fine/defect scale):", 0.5, 5.0, 1.0, 9, is_float=True, resolution=0.1)
        self.create_parameter_row(self.tab_prep, "dog_sigma2", "DoG Sigma 2 (background scale):", 2.0, 20.0, 6.0, 10, is_float=True, resolution=0.5)

        # Tab 2 — Marker Generation
        self.create_parameter_row(self.tab_marker, "dt_type", "Distance Transform Type (0:L1, 1:L2, 2:C):", 0, 2, 1, 0, resolution=1)
        self.create_parameter_row(self.tab_marker, "dt_mask", "Distance Mask Size (3 or 5):", 3, 5, 5, 1, resolution=2)
        self.create_parameter_row(self.tab_marker, "local_max_min_dist", "Local Maxima Minimum Distance:", 1, 50, 5, 2, resolution=1)
        self.create_parameter_row(self.tab_marker, "marker_refine_radius", "Marker Refinement Radius:", 0, 10, 1, 3, resolution=1)
        self.create_parameter_row(self.tab_marker, "h_min_depth", "H-Maxima/H-Minima Depth (bright + dark):", 0.0, 100.0, 10.0, 4, is_float=True, resolution=1.0)
        self.create_parameter_row(self.tab_marker, "ext_min_depth", "Extended Minima Depth Dynamic Cutoff:", 0.0, 100.0, 5.0, 5, is_float=True, resolution=1.0)
        # NEW: bridges halo/edge-ringing gaps around a real defect so it isn't
        # fragmented into several detections (see STAGE 7 comment).
        self.create_parameter_row(self.tab_marker, "gap_bridge_radius", "Gap-Bridge Radius (merge halo fragments):", 0, 15, 3, 6, resolution=1)

        # Tab 3 — Watershed Optimization
        # compactness default raised 0.0 -> 0.05 and flooding_smoothness
        # 0 -> 3: both reduce ragged/noisy boundaries in the final mask.
        self.create_parameter_row(self.tab_ws, "compactness", "Compactness Regularization Factor:", 0.0, 10.0, 0.05, 0, is_float=True, resolution=0.05)
        self.create_parameter_row(self.tab_ws, "connectivity", "Connectivity Neighborhood Radius:", 1, 8, 1, 1, resolution=1)
        self.create_parameter_row(self.tab_ws, "ridge_enhancement", "Ridge Enhancement Strength Scalar:", 1.0, 5.0, 1.0, 2, is_float=True, resolution=0.2)
        self.create_parameter_row(self.tab_ws, "flooding_smoothness", "Flooding Topology Smoothness Kernel:", 0, 15, 3, 3, resolution=1)

        # Tab 4 — Defect Filtering
        self.create_parameter_row(self.tab_filter, "min_area", "Minimum Area Limit (Pixels):", 50, 20000, 50, 0, resolution=50)
        self.create_parameter_row(self.tab_filter, "max_area", "Maximum Area Limit (Pixels):", 100, 50000, 10000, 1, resolution=100)
        self.create_parameter_row(self.tab_filter, "min_circularity", "Minimum Circularity Metric:", 0.0, 1.0, 0.0, 2, is_float=True, resolution=0.05)
        self.create_parameter_row(self.tab_filter, "min_solidity", "Minimum Solidity Density:", 0.0, 1.0, 0.0, 3, is_float=True, resolution=0.05)
        self.create_parameter_row(self.tab_filter, "max_aspect_ratio", "Maximum Aspect Ratio Bound:", 1.0, 20.0, 10.0, 4, is_float=True, resolution=0.5)
        self.create_parameter_row(self.tab_filter, "min_convexity", "Minimum Boundary Convexity:", 0.0, 1.0, 0.0, 5, is_float=True, resolution=0.05)

    def load_image_action(self):
        file_path = filedialog.askopenfilename(filetypes=[("All Image Formats", "*.jpg *.jpeg *.png *.bmp *.tiff *.pgm")])
        if file_path:
            self.folder_path = None
            self.image_path = file_path
            self.path_lbl.configure(text=os.path.basename(file_path))
            self.trigger_pipeline_refresh()

    def load_folder_action(self):
        folder_path = filedialog.askdirectory(title="Select Batch Folder of AM Images")
        if folder_path:
            self.image_path = None
            self.folder_path = folder_path
            files = [f for f in os.listdir(folder_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp'))]
            self.path_lbl.configure(text=f"Batch Folder: {os.path.basename(folder_path)} ({len(files)} target images)")

            if len(files) > 0:
                self.image_path = os.path.join(folder_path, files[0])
                self.trigger_pipeline_refresh()

    def get_current_params_dict(self):
        return {k: v.get() for k, v in self.params.items()}

    def trigger_pipeline_refresh(self):
        if not self.image_path or self.updating_ui:
            return

        p_dict = self.get_current_params_dict()
        disp_img, mask, topology, white_disp, dark_disp, final_disp = process_powder_bed_pipeline(
            self.image_path, self.max_display_dim, p_dict
        )

        if disp_img is not None:
            self.update_native_viewports(disp_img, mask, topology, white_disp, dark_disp, final_disp)

    def convert_to_ctk_image(self, cv_img, is_gray=False, use_cmap=False):
        if use_cmap:
            norm_topo = cv2.normalize(cv_img, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
            color_mapped = cv2.applyColorMap(norm_topo, cv2.COLORMAP_VIRIDIS)
            rgb = cv2.cvtColor(color_mapped, cv2.COLOR_BGR2RGB)
        elif is_gray:
            rgb = cv2.cvtColor(cv_img, cv2.COLOR_GRAY2RGB)
        else:
            rgb = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)

        h, w = rgb.shape[:2]
        pil_img = Image.fromarray(rgb)
        return ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(w, h))

    def update_native_viewports(self, disp_img, mask, topology, white_disp, dark_disp, final_disp):
        ctk_img1 = self.convert_to_ctk_image(disp_img, is_gray=False)
        ctk_img2 = self.convert_to_ctk_image(mask, is_gray=True)
        ctk_img3 = self.convert_to_ctk_image(topology, use_cmap=True)
        ctk_img4 = self.convert_to_ctk_image(white_disp, is_gray=False)
        ctk_img5 = self.convert_to_ctk_image(dark_disp, is_gray=False)
        ctk_img6 = self.convert_to_ctk_image(final_disp, is_gray=False)

        self.lbl_view1.configure(image=ctk_img1, text="")
        self.lbl_view1.image = ctk_img1
        self.lbl_view2.configure(image=ctk_img2, text="")
        self.lbl_view2.image = ctk_img2
        self.lbl_view3.configure(image=ctk_img3, text="")
        self.lbl_view3.image = ctk_img3
        self.lbl_view4.configure(image=ctk_img4, text="")
        self.lbl_view4.image = ctk_img4
        self.lbl_view5.configure(image=ctk_img5, text="")
        self.lbl_view5.image = ctk_img5
        self.lbl_view6.configure(image=ctk_img6, text="")
        self.lbl_view6.image = ctk_img6

    def start_async_export(self):
        if not self.image_path and not self.folder_path:
            messagebox.showwarning("Export Error", "Please load a single image or batch folder first.")
            return

        selected_parent_dir = filedialog.askdirectory(title="Select Destination Folder")
        if not selected_parent_dir:
            return

        self.export_btn.configure(state="disabled", text="⏳ Running High-Res Batch Pool...")

        export_thread = threading.Thread(target=self.background_export_worker, args=(selected_parent_dir,))
        export_thread.daemon = True
        export_thread.start()

    def background_export_worker(self, target_base_path):
        try:
            p_dict = self.get_current_params_dict()

            if self.folder_path:
                output_dir = os.path.join(target_base_path, "Output_Images_Watershed")
                os.makedirs(output_dir, exist_ok=True)
                files_to_process = [
                    os.path.join(self.folder_path, f)
                    for f in os.listdir(self.folder_path)
                    if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp'))
                ]
            else:
                base_filename = os.path.splitext(os.path.basename(self.image_path))[0]
                output_dir = os.path.join(target_base_path, f"watershed_{base_filename}_outputs")
                os.makedirs(output_dir, exist_ok=True)
                files_to_process = [self.image_path]

            def process_single_file(file_path):
                file_name_only = os.path.splitext(os.path.basename(file_path))[0]

                if self.folder_path:
                    # Batch mode: keep this path lean (no debug_output) so
                    # processing 100s of full-resolution images stays as fast
                    # as possible - only the final overlay is written.
                    _, full_mask, full_topo, full_white, full_dark, full_final = process_powder_bed_pipeline(
                        file_path, None, p_dict
                    )
                    if full_final is None:
                        return
                    output_file_name = f"{file_name_only}_segmented.png"
                    cv2.imwrite(os.path.join(output_dir, output_file_name), cv2.cvtColor(full_final, cv2.COLOR_RGB2BGR))
                else:
                    # Single-image mode: also capture intermediate debug
                    # stages (DoG, contrast-enhanced, background estimate,
                    # distance transform, markers) for pipeline inspection.
                    # This does not touch the live-preview call or the
                    # 6-viewport layout - it only adds extra files here.
                    debug = {}
                    _, full_mask, full_topo, full_white, full_dark, full_final = process_powder_bed_pipeline(
                        file_path, None, p_dict, debug_output=debug
                    )
                    if full_final is None:
                        return

                    cv2.imwrite(os.path.join(output_dir, "export_1_input.png"), cv2.imread(file_path))
                    cv2.imwrite(os.path.join(output_dir, "export_2_binary_mask.png"), full_mask)

                    topo_norm = cv2.normalize(full_topo, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
                    cv2.imwrite(os.path.join(output_dir, "export_3_topography.png"), cv2.applyColorMap(topo_norm, cv2.COLORMAP_VIRIDIS))
                    cv2.imwrite(os.path.join(output_dir, "export_4_white_defects.png"), cv2.cvtColor(full_white, cv2.COLOR_RGB2BGR))
                    cv2.imwrite(os.path.join(output_dir, "export_5_dark_defects.png"), cv2.cvtColor(full_dark, cv2.COLOR_RGB2BGR))
                    cv2.imwrite(os.path.join(output_dir, "export_6_final_segmentation.png"), cv2.cvtColor(full_final, cv2.COLOR_RGB2BGR))

                    if "contrast_enhanced" in debug:
                        cv2.imwrite(os.path.join(output_dir, "export_7_contrast_enhanced.png"), debug["contrast_enhanced"])
                    if "dog" in debug:
                        dog_norm = cv2.normalize(debug["dog"], None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
                        cv2.imwrite(os.path.join(output_dir, "export_8_difference_of_gaussians.png"), dog_norm)
                    if "background_estimate" in debug:
                        cv2.imwrite(os.path.join(output_dir, "export_9_background_estimate.png"), debug["background_estimate"])
                    if "distance_transform" in debug:
                        dist_norm = cv2.normalize(debug["distance_transform"], None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
                        cv2.imwrite(os.path.join(output_dir, "export_10_distance_transform.png"), dist_norm)
                    if "markers" in debug:
                        markers_norm = cv2.normalize(debug["markers"].astype(np.float32), None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
                        cv2.imwrite(os.path.join(output_dir, "export_11_markers.png"), markers_norm)

                    with open(os.path.join(output_dir, "parameters.json"), "w") as f:
                        json.dump({"configured_parameters": p_dict, "engine": "topological_watershed_dual_polarity_v2"}, f, indent=4)

            with ThreadPoolExecutor() as executor:
                executor.map(process_single_file, files_to_process)

            self.after(0, lambda: self.on_export_complete(output_dir))

        except Exception as e:
            self.after(0, lambda: self.on_export_failed(str(e)))

    def on_export_complete(self, output_dir):
        self.export_btn.configure(state="normal", text="💾 Export Output\n(Single or Batch Folder)")
        messagebox.showinfo("Export Successful", f"Operations completed successfully!\nTarget Directory:\n{output_dir}")

    def on_export_failed(self, error_msg):
        self.export_btn.configure(state="normal", text="💾 Export Output\n(Single or Batch Folder)")
        messagebox.showerror("Export Error", f"An execution error occurred:\n{error_msg}")


if __name__ == "__main__":
    app = UltimateWatershedWorkstation()
    app.mainloop()
