import os
import json
import cv2
import numpy as np
import tkinter as tk
import customtkinter as ctk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import threading
from concurrent.futures import ThreadPoolExecutor

# --- ENGINE IMPORTS ---
from skimage.segmentation import watershed
from skimage.morphology import disk, ball, reconstruction
from skimage.feature import peak_local_max
from scipy import ndimage

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")


# =============================================================================
# MODULAR PROCESSING HELPERS
#
# Everything below was previously inlined once, non-reusably, inside
# process_powder_bed_pipeline(). It is now split into small, documented,
# single-purpose functions so that (a) the bright-region and dark-region
# code paths can share identical logic instead of only existing for bright
# regions, and (b) each algorithmic stage can be explained, tuned, and unit
# tested independently.
# =============================================================================

def _odd(n, minimum=1):
    """Force an integer kernel size to be odd and >= minimum (OpenCV kernels must be odd)."""
    n = int(n)
    if n < minimum:
        n = minimum
    if n % 2 == 0:
        n += 1
    return n


def apply_gaussian_division(gray_f32, k_size, sigma):
    """
    Illumination normalization via Gaussian Division:

        Corrected = Original / GaussianBlur(Original)

    WHY: A heavily blurred copy of the image is a low-pass estimate of the
    slowly-varying background illumination / powder-bed shading gradient.
    Dividing the original by this estimate cancels the *low-frequency*
    illumination component while leaving the *high-frequency* component
    (texture, edges, true defects) intact. Because this is a RATIO rather
    than a subtraction, it is symmetric: a bright anomaly produces a ratio
    > 1 and a dark anomaly produces a ratio < 1, with the *same* dynamic
    range on both sides of the neutral value (1.0). This symmetry is the
    root fix for "bright regions detect but dark regions don't" -- the
    original pipeline had no illumination-normalization stage at all, so
    the H-dome extraction downstream was implicitly biased toward bright
    peaks only (see extract_h_transform).

    KERNEL / SIGMA SELECTION: the blur must be wide enough that it averages
    over real defects and local texture (i.e. it estimates *background*,
    not *signal*), but narrow enough to still track genuine illumination
    gradients across the frame. Illumination-correction literature commonly
    places sigma at roughly 1/20 - 1/10 of the smaller image dimension.
    We expose k_size/sigma as tunable GUI parameters but default to a wide
    kernel (>= 31 px, sigma auto-derived by OpenCV when sigma=0) so that
    small-to-medium defects are never absorbed into the background
    estimate itself.
    """
    k_size = _odd(k_size, 3)
    background = cv2.GaussianBlur(gray_f32, (k_size, k_size), sigma)
    background = np.clip(background, 1.0, 255.0)  # guard against divide-by-zero
    corrected = (gray_f32 / background) * 128.0    # recenter ratio around mid-gray for 8-bit compatibility
    corrected = np.clip(corrected, 0, 255)
    return corrected, background


def extract_h_transform(image_f32, depth, invert=False):
    """
    Morphological H-dome (bright) / H-basin (dark) extraction via grayscale
    reconstruction by dilation.

    H-maxima transform (bright domes), the CORRECT formulation:
        seed          = image - depth
        reconstructed = reconstruction(seed, image, method='dilation')
        hdome         = image - reconstructed

    This floods/suppresses every regional maximum whose height above its
    surrounding saddle point is smaller than `depth`, leaving only bright
    peaks that are genuinely prominent by at least `depth` gray levels.
    This is illumination-robust (it responds to LOCAL prominence, not an
    absolute gray value) which is exactly why it works well for the
    bright case already in the original code.

    H-minima transform (dark basins) is mathematically the dual operation,
    performed on the photometric negative of the image:
        H-minima(image, depth) == H-maxima(255 - image, depth)
    ROOT CAUSE OF THE ORIGINAL "no dark detection" BUG: the original
    pipeline only ever computed the bright-side H-maxima transform
    (`reconstruction(image - depth, image, 'dilation')`) and never computed
    its dual on the inverted image, so dark pits were structurally
    invisible to the marker-generation stage no matter how the thresholds
    were tuned. `invert=True` here runs the identical, already-correct
    procedure on (255 - image) and returns the result using the same
    "domes are positive" convention as the bright case, so every stage
    downstream (thresholding, cleaning, marker generation, classification)
    can treat bright and dark uniformly instead of needing a parallel,
    separately-maintained dark-specific implementation.
    """
    working = (255.0 - image_f32) if invert else image_f32
    seed = np.clip(working - depth, 0, 255)
    reconstructed = reconstruction(seed, working, method='dilation')
    hdome = working - reconstructed
    return hdome


def clean_binary_blobs(binary_mask_u8, min_pixels=4, open_radius=1):
    """
    Noise suppression applied directly to the bright/dark candidate masks,
    BEFORE they ever reach distance-transform / marker generation:

      1. Morphological opening (erosion -> dilation) removes isolated
         single/few-pixel noise specks and thin spurious spurs left by
         sensor noise or powder-bed texture -- this is the single biggest
         lever against "image noise misclassified as defects", because it
         acts before any watershed marker can be seeded from a noise pixel.
      2. Connected-component area filtering then drops any surviving blob
         smaller than `min_pixels`. Real defect nuclei are essentially
         always larger than this after the H-dome threshold; anything
         smaller is overwhelmingly quantization/sensor noise.

    Doing this here (not just at the very end via min_area) prevents noise
    from ever spawning its own watershed marker/region in the first place,
    which is what previously caused excessive over-segmentation and noisy
    masks even when a min_area filter existed downstream.
    """
    if open_radius > 0:
        se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (open_radius * 2 + 1, open_radius * 2 + 1))
        binary_mask_u8 = cv2.morphologyEx(binary_mask_u8, cv2.MORPH_OPEN, se)

    if min_pixels > 0:
        n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(binary_mask_u8, connectivity=8)
        cleaned = np.zeros_like(binary_mask_u8)
        for lbl in range(1, n_labels):
            if stats[lbl, cv2.CC_STAT_AREA] >= min_pixels:
                cleaned[labels == lbl] = 255
        binary_mask_u8 = cleaned

    return binary_mask_u8


def generate_markers(binary_peaks_u8, dt_type, dt_mask, min_dist, refine_radius, label_offset=0):
    """
    Marker generation for a SINGLE polarity (bright OR dark) candidate mask.

      1. Distance transform of the binary candidate mask.
      2. Local-maxima detection on the distance map: regional peaks of the
         distance transform correspond to the "center" of each blob-like
         region, giving one marker per distinct region even when two
         regions touch. This is what lets watershed SPLIT touching defects
         instead of merging them (prevents under-segmentation).
      3. Fallback to plain connected components if no local maxima are
         found (e.g. very small / flat regions where peak_local_max finds
         nothing) -- preserves the original code's safety net.

    `label_offset` lets bright-polarity and dark-polarity markers be
    generated completely independently and then merged into one label
    space without numeric collision, so every watershed label can later be
    traced back to the polarity that produced it (used for bright/dark
    classification instead of a brittle fixed absolute intensity cutoff).
    """
    h, w = binary_peaks_u8.shape
    dist_trans = cv2.distanceTransform(binary_peaks_u8, dt_type, dt_mask)

    coordinates = peak_local_max(dist_trans, min_distance=max(1, min_dist), labels=binary_peaks_u8)

    markers = np.zeros((h, w), dtype=np.int32)
    for idx, pt in enumerate(coordinates):
        markers[pt[0], pt[1]] = idx + 1

    if np.max(markers) == 0 and np.any(binary_peaks_u8):
        _, markers = cv2.connectedComponents(binary_peaks_u8)

    if refine_radius > 0:
        se = cv2.getStructuringElement(cv2.MORPH_RECT, (refine_radius * 2 + 1, refine_radius * 2 + 1))
        markers = cv2.dilate(markers.astype(np.float32), se).astype(np.int32)

    out = np.zeros_like(markers)
    for lbl in np.unique(markers):
        if lbl == 0:
            continue
        out[markers == lbl] = lbl + label_offset

    return out, dist_trans


def region_shape_features(contour):
    """Geometric descriptors used for shape-based false-positive rejection."""
    area = cv2.contourArea(contour)
    perimeter = cv2.arcLength(contour, True)
    circularity = (4 * np.pi * area) / (perimeter ** 2) if perimeter > 0 else 0

    hull = cv2.convexHull(contour)
    hull_area = cv2.contourArea(hull)
    solidity = float(area) / hull_area if hull_area > 0 else 0

    x, y, w_b, h_b = cv2.boundingRect(contour)
    aspect_ratio = float(max(w_b, h_b)) / min(w_b, h_b) if min(w_b, h_b) > 0 else 0

    convexity = float(cv2.arcLength(hull, True)) / perimeter if perimeter > 0 else 0

    return area, circularity, solidity, aspect_ratio, convexity


def passes_shape_filter(area, circularity, solidity, aspect_ratio, convexity, fp):
    return (fp['min_area'] <= area <= fp['max_area'] and
            circularity >= fp['min_circularity'] and
            solidity >= fp['min_solidity'] and
            aspect_ratio <= fp['max_aspect_ratio'] and
            convexity >= fp['min_convexity'])


# =============================================================================
# HIGH-PRECISION POWDER BED TOPOLOGICAL PIPELINE (v2)
# =============================================================================
def process_powder_bed_pipeline(image_path, max_dim, params):
    """
    Returns a dict of named images (or None on failure) covering every
    processing stage, so the GUI and the exporter can each show/save
    whichever subset they need without recomputing anything.

    Keys: img_disp, gaussian_division, background, conditioned, gradient,
          markers, distance, binary_mask, white_display, dark_display,
          final_output
    """
    img = cv2.imread(image_path)
    if img is None:
        return None

    # ---- Perspective Correction / Flattening (unchanged from original) ----
    gray_full = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred_warp = cv2.GaussianBlur(gray_full, (5, 5), 0)
    _, warp_thresh = cv2.threshold(blurred_warp, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    contours, _ = cv2.findContours(warp_thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if len(contours) > 0:
        largest_contour = max(contours, key=cv2.contourArea)
        peri = cv2.arcLength(largest_contour, True)
        approx = cv2.approxPolyDP(largest_contour, 0.02 * peri, True)
        if len(approx) == 4:
            pts = approx.reshape(4, 2)
            rect = np.zeros((4, 2), dtype="float32")
            s = pts.sum(axis=1)
            rect[0] = pts[np.argmin(s)]
            rect[2] = pts[np.argmax(s)]
            diff = np.diff(pts, axis=1)
            rect[1] = pts[np.argmin(diff)]
            rect[3] = pts[np.argmax(diff)]

            (tl, tr, br, bl) = rect
            widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
            widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
            maxWidth = max(int(widthA), int(widthB))

            heightA = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
            heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
            maxHeight = max(int(heightA), int(heightB))

            dst = np.array([
                [0, 0],
                [maxWidth - 1, 0],
                [maxWidth - 1, maxHeight - 1],
                [0, maxHeight - 1]], dtype="float32")

            M = cv2.getPerspectiveTransform(rect, dst)
            img = cv2.warpPerspective(img, M, (maxWidth, maxHeight))

    # ---- Resize strategy for responsive live editing (unchanged) ----
    h, w = img.shape[:2]
    if max_dim is not None and max(h, w) > max_dim:
        scale = max_dim / float(max(h, w))
        img_disp = cv2.resize(img, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)
    else:
        img_disp = img.copy()

    gray = cv2.cvtColor(img_disp, cv2.COLOR_BGR2GRAY)
    gray_f = gray.astype(np.float32)

    # =========================================================================
    # STAGE 1 -- ILLUMINATION NORMALIZATION (Gaussian Division)
    # This is the new preprocessing stage requested in the brief, and it is
    # what makes symmetric bright/dark detection possible: everything after
    # this point operates on a background-flattened image instead of the
    # raw, illumination-biased grayscale frame.
    # =========================================================================
    gdiv_k = int(params.get("gdiv_k", 51))
    gdiv_sigma = float(params.get("gdiv_sigma", 0.0))
    corrected_f, background_f = apply_gaussian_division(gray_f, gdiv_k, gdiv_sigma)

    # =========================================================================
    # STAGE 2 -- NOISE SUPPRESSION / IMAGE CONDITIONING
    # Runs on the Gaussian-Division output rather than the raw image, so the
    # smoothing operators are working on an already illumination-flattened
    # signal (much less likely to blur a real gradient into "texture").
    # =========================================================================
    conditioned_u8 = np.clip(corrected_f, 0, 255).astype(np.uint8)

    blur_k = _odd(int(params.get("gaussian_k", 15)))
    conditioned_u8 = cv2.GaussianBlur(conditioned_u8, (blur_k, blur_k), 0)

    bilat_d = int(params.get("bilat_d", 9))
    bilat_sc = float(params.get("bilat_sc", 75.0))
    bilat_ss = float(params.get("bilat_ss", 75.0))
    # Edge-preserving smoothing: removes sensor / powder-texture noise while
    # keeping true defect boundaries sharp (a plain Gaussian blur alone would
    # also blur the edges we actually want to detect).
    conditioned_u8 = cv2.bilateralFilter(conditioned_u8, bilat_d, bilat_sc, bilat_ss)

    nlm_strength = float(params.get("nlm_strength", 0.0))
    if nlm_strength > 0:
        # Non-local means: averages pixels with similar neighborhoods across
        # the whole image (not just spatially nearby ones), which is very
        # effective against fine granular powder-bed noise without eroding
        # small genuine defects the way heavier morphological smoothing does.
        conditioned_u8 = cv2.fastNlMeansDenoising(
            conditioned_u8, None, h=nlm_strength, templateWindowSize=7, searchWindowSize=21)

    se_shape_idx = int(params.get("se_shape", 0))
    se_shapes = [cv2.MORPH_RECT, cv2.MORPH_ELLIPSE, cv2.MORPH_CROSS]
    se_shape = se_shapes[np.clip(se_shape_idx, 0, 2)]
    se_size = int(params.get("se_size", 3))
    se = cv2.getStructuringElement(se_shape, (se_size, se_size))

    # Opening then closing = morphological alternating-sequential filter:
    # opening removes small bright noise specks, closing then fills small
    # dark noise pits, suppressing residual texture symmetrically before it
    # ever reaches H-dome extraction.
    conditioned_u8 = cv2.morphologyEx(conditioned_u8, cv2.MORPH_OPEN, se, iterations=int(params.get("morph_open_it", 1)))
    conditioned_u8 = cv2.morphologyEx(conditioned_u8, cv2.MORPH_CLOSE, se, iterations=int(params.get("morph_close_it", 1)))

    conditioned_f = conditioned_u8.astype(np.float32)

    # =========================================================================
    # STAGE 3 -- TOPOGRAPHIC GRADIENT (watershed elevation surface)
    # Morphological gradient responds to boundary steepness regardless of
    # whether the region inside is brighter or darker than its surroundings,
    # so a single gradient surface can serve as the flooding landscape for
    # BOTH polarities -- no separate "bright gradient" / "dark gradient" is
    # needed here.
    # =========================================================================
    morph_grad = cv2.morphologyEx(conditioned_u8, cv2.MORPH_GRADIENT, se).astype(np.float32)

    ridge_enhancement = float(params.get("ridge_enhancement", 1.0))
    if ridge_enhancement > 1.0:
        morph_grad = cv2.multiply(morph_grad, ridge_enhancement)

    flooding_smoothness = int(params.get("flooding_smoothness", 0))
    if flooding_smoothness > 0:
        fk = _odd(flooding_smoothness)
        morph_grad = cv2.GaussianBlur(morph_grad, (fk, fk), 0)

    # =========================================================================
    # STAGE 4 -- DUAL-POLARITY H-DOME / H-BASIN DEFECT ISOLATION
    # This is the core algorithmic fix: bright and dark candidates are now
    # extracted by the SAME mathematically-dual operation (see
    # extract_h_transform) with independently tunable depth parameters,
    # instead of only ever computing the bright-side transform.
    # =========================================================================
    h_min_depth_bright = float(params.get("h_min_depth", 10.0))
    h_min_depth_dark = float(params.get("h_min_depth_dark", 10.0))
    ext_min_depth_bright = float(params.get("ext_min_depth", 5.0))
    ext_min_depth_dark = float(params.get("ext_min_depth_dark", 5.0))

    hdome_bright = extract_h_transform(conditioned_f, h_min_depth_bright, invert=False)
    hdome_dark = extract_h_transform(conditioned_f, h_min_depth_dark, invert=True)

    peaks_bright_raw = (hdome_bright > ext_min_depth_bright).astype(np.uint8) * 255
    peaks_dark_raw = (hdome_dark > ext_min_depth_dark).astype(np.uint8) * 255

    # Noise suppression applied directly to the candidate masks (Task 6):
    # morphological opening + connected-component area filtering, BEFORE
    # distance-transform / marker generation, so noise can never seed its
    # own watershed marker.
    min_peak_px = int(params.get("min_peak_pixels", 4))
    noise_open_r = int(params.get("noise_open_radius", 1))
    peaks_bright = clean_binary_blobs(peaks_bright_raw, min_peak_px, noise_open_r)
    peaks_dark = clean_binary_blobs(peaks_dark_raw, min_peak_px, noise_open_r)

    # =========================================================================
    # STAGE 5 -- MARKER GENERATION (per polarity, then merged into one space)
    # =========================================================================
    dist_types = [cv2.DIST_L1, cv2.DIST_L2, cv2.DIST_C]
    dt_type = dist_types[np.clip(int(params.get("dt_type", 1)), 0, 2)]
    dt_mask = int(params.get("dt_mask", 5))
    if dt_mask not in [0, 3, 5]:
        dt_mask = 5
    min_dist = int(params.get("local_max_min_dist", 5))
    refine_r = int(params.get("marker_refine_radius", 1))

    markers_bright, dist_bright = generate_markers(peaks_bright, dt_type, dt_mask, min_dist, refine_r, label_offset=0)
    max_bright_label = int(markers_bright.max())
    markers_dark, dist_dark = generate_markers(peaks_dark, dt_type, dt_mask, min_dist, refine_r, label_offset=max_bright_label)

    # Record which polarity produced each label BEFORE watershed runs, since
    # watershed preserves marker label identity into its output labels --
    # this lets final classification be based on provenance instead of a
    # brittle fixed absolute intensity threshold (fixes illumination
    # dependence of the bright/dark split, Task 4 / issue 4).
    label_polarity = {}
    for lbl in np.unique(markers_bright):
        if lbl != 0:
            label_polarity[int(lbl)] = "bright"
    for lbl in np.unique(markers_dark):
        if lbl != 0:
            label_polarity[int(lbl)] = "dark"

    markers_mask = markers_bright + markers_dark
    binary_peaks = cv2.bitwise_or(peaks_bright, peaks_dark)
    dist_trans = np.maximum(dist_bright, dist_dark)

    # =========================================================================
    # STAGE 6 -- WATERSHED SEGMENTATION
    # =========================================================================
    comp = float(params.get("compactness", 0.0))
    conn_radius = int(params.get("connectivity", 1))
    footprint = disk(conn_radius) if conn_radius > 1 else None

    if np.max(markers_mask) > 0:
        seg_labels = watershed(morph_grad, markers_mask, mask=binary_peaks, compactness=comp, connectivity=footprint)
    else:
        seg_labels = np.zeros_like(gray, dtype=np.int32)

    # =========================================================================
    # STAGE 7 -- SHAPE-BASED REGION VALIDATION (Task 8)
    # Defaults for min_circularity / min_solidity are no longer 0 (i.e. "no
    # filter") -- they now reject obviously non-defect-like blobs by
    # default, which is a direct fix for "noise treated as defects" (issue
    # 2) since a threshold-only pipeline has no shape concept at all.
    # =========================================================================
    final_mask = np.zeros_like(gray, dtype=np.uint8)
    filter_params = {
        'min_area': float(params.get("min_area", 50)),
        'max_area': float(params.get("max_area", 10000)),
        'min_circularity': float(params.get("min_circularity", 0.3)),
        'min_solidity': float(params.get("min_solidity", 0.5)),
        'max_aspect_ratio': float(params.get("max_aspect_ratio", 10.0)),
        'min_convexity': float(params.get("min_convexity", 0.0)),
    }

    for label in np.unique(seg_labels):
        if label == 0:
            continue
        component_mask = (seg_labels == label).astype(np.uint8) * 255
        cnts, _ = cv2.findContours(component_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            continue
        c = max(cnts, key=cv2.contourArea)
        area, circularity, solidity, aspect_ratio, convexity = region_shape_features(c)

        if passes_shape_filter(area, circularity, solidity, aspect_ratio, convexity, filter_params):
            final_mask[seg_labels == label] = 255

    # Final morphological polish: smooths single-pixel jaggedness left on the
    # mask boundary by watershed lines. A radius-1 closing cannot merge or
    # remove any accepted region (they already passed min_area above), it
    # only cleans the boundary -- directly addresses "segmentation masks
    # contain excessive noise" (issue 3).
    polish_se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    final_mask = cv2.morphologyEx(final_mask, cv2.MORPH_CLOSE, polish_se)

    # =========================================================================
    # STAGE 8 -- VISUALIZATION & DUAL ANOMALY EXTRACTION
    # =========================================================================
    bg_rgb = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
    white_display = bg_rgb.copy()
    dark_display = bg_rgb.copy()
    final_output = bg_rgb.copy()

    final_cnts, _ = cv2.findContours(final_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for c in final_cnts:
        m = cv2.moments(c)
        if m["m00"] == 0:
            continue
        cx = int(m["m10"] / m["m00"])
        cy = int(m["m01"] / m["m00"])

        label_here = 0
        if 0 <= cy < seg_labels.shape[0] and 0 <= cx < seg_labels.shape[1]:
            label_here = seg_labels[cy, cx]
        polarity = label_polarity.get(int(label_here))
        if polarity is None:
            # Fallback only occurs for pathological centroid/label mismatches;
            # keeps behavior defined without ever crashing.
            polarity = "bright" if gray[cy, cx] > 140 else "dark"

        if polarity == "bright":
            cv2.drawContours(white_display, [c], -1, (255, 0, 0), -1)
        else:
            cv2.drawContours(dark_display, [c], -1, (255, 0, 0), -1)

        cv2.drawContours(final_output, [c], -1, (255, 0, 0), -1)

    n_markers = int(markers_mask.max())
    if n_markers > 0:
        markers_disp = np.clip(markers_mask.astype(np.float32) * (255.0 / n_markers), 0, 255).astype(np.uint8)
    else:
        markers_disp = np.zeros_like(gray)

    return {
        "img_disp": img_disp,
        "gaussian_division": np.clip(corrected_f, 0, 255).astype(np.uint8),
        "background": np.clip(background_f, 0, 255).astype(np.uint8),
        "conditioned": conditioned_u8,
        "gradient": morph_grad,
        "markers": markers_disp,
        "distance": dist_trans,
        "binary_mask": final_mask,
        "white_display": white_display,
        "dark_display": dark_display,
        "final_output": final_output,
    }


# --- COMPONENT SPINBOX & SYNCHRONIZER (unchanged) ---
class CTkSpinbox(ctk.CTkFrame):
    def __init__(self, parent, from_val, to_val, current_val, is_float=False, resolution=1, linked_var=None, on_update_callback=None):
        super().__init__(parent, fg_color="transparent")
        self.from_val = from_val
        self.to_val = to_val
        self.is_float = is_float
        self.resolution = resolution
        self.linked_var = linked_var
        self.callback = on_update_callback

        self.btn_down = ctk.CTkButton(self, text="▼", width=28, height=28, font=("Arial", 10),
                                      fg_color="#37474f", hover_color="#263238", command=self.decrement)
        self.btn_down.pack(side=tk.LEFT, padx=2)

        self.entry = ctk.CTkEntry(self, width=65, height=28, font=('Helvetica', 12), justify='center')
        self.entry.insert(0, f"{current_val:.2f}" if self.is_float else str(int(current_val)))
        self.entry.pack(side=tk.LEFT, padx=2)

        self.btn_up = ctk.CTkButton(self, text="▲", width=28, height=28, font=("Arial", 10),
                                    fg_color="#37474f", hover_color="#263238", command=self.increment)
        self.btn_up.pack(side=tk.LEFT, padx=2)

    def get_value(self):
        try:
            return float(self.entry.get()) if self.is_float else int(float(self.entry.get()))
        except ValueError:
            return self.from_val

    def set_value(self, val):
        self.entry.delete(0, tk.END)
        self.entry.insert(0, f"{val:.2f}" if self.is_float else str(int(val)))
        if self.linked_var:
            self.linked_var.set(val)

    def increment(self):
        curr = self.get_value()
        new_val = np.clip(curr + self.resolution, self.from_val, self.to_val)
        self.set_value(new_val)
        if self.callback: self.callback()

    def decrement(self):
        curr = self.get_value()
        new_val = np.clip(curr - self.resolution, self.from_val, self.to_val)
        self.set_value(new_val)
        if self.callback: self.callback()


# --- ULTIMATE WATERSHED WORKSTATION ---
# Viewport definitions: (title, result_dict_key, display_kwargs)
# Driven by a list + loop (rather than one hand-written block per tile like
# the original) so that adding/removing an intermediate-stage viewport is a
# one-line change instead of touching six different places.
VIEWPORT_DEFS = [
    ("1. Raw Input", "img_disp", {}),
    ("2. Gaussian Division", "gaussian_division", {"is_gray": True}),
    ("3. Conditioned / Denoised", "conditioned", {"is_gray": True}),
    ("4. Gradient Topology", "gradient", {"use_cmap": True}),
    ("5. Clean Binary Mask", "binary_mask", {"is_gray": True}),
    ("6. White Defects (Red)", "white_display", {}),
    ("7. Dark Defects (Red)", "dark_display", {}),
    ("8. Unified Output", "final_output", {}),
]


class UltimateWatershedWorkstation(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Additive Manufacturing Powder Bed Inspection Workstation (Topological Engine v2)")
        self.geometry("1750x980")
        self.image_path = None
        self.folder_path = None
        self.max_display_dim = 400
        self.updating_ui = False
        self.params = {}
        self.lbl_views = []

        self.setup_ui_architecture()

    def setup_ui_architecture(self):
        top_bar = ctk.CTkFrame(self, height=60, corner_radius=0)
        top_bar.pack(side=tk.TOP, fill=tk.X)

        load_btn = ctk.CTkButton(top_bar, text="📂 Load Single Image", command=self.load_image_action,
                                 font=('Helvetica', 12, 'bold'), fg_color="#0288d1", hover_color="#01579b")
        load_btn.pack(side=tk.LEFT, padx=15, pady=10)

        load_folder_btn = ctk.CTkButton(top_bar, text="📁 Load Batch Folder", command=self.load_folder_action,
                                        font=('Helvetica', 12, 'bold'), fg_color="#ff8f00", hover_color="#c67100")
        load_folder_btn.pack(side=tk.LEFT, padx=10, pady=10)

        self.path_lbl = ctk.CTkLabel(top_bar, text="No source files loaded.", font=('Helvetica', 12, 'italic'), text_color="#90a4ae")
        self.path_lbl.pack(side=tk.LEFT, padx=15)

        # N-column high-speed layout viewport frame (N = len(VIEWPORT_DEFS))
        self.viewport_frame = ctk.CTkFrame(self, corner_radius=10, fg_color="#1e1e1e")
        self.viewport_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=15, pady=10)

        n_views = len(VIEWPORT_DEFS)
        for i in range(n_views):
            self.viewport_frame.columnconfigure(i, weight=1, uniform="viewport")
        self.viewport_frame.rowconfigure(1, weight=1)

        for i, (title, _key, _kwargs) in enumerate(VIEWPORT_DEFS):
            lbl = ctk.CTkLabel(self.viewport_frame, text=title, font=('Helvetica', 11, 'bold'), text_color="white")
            lbl.grid(row=0, column=i, pady=(10, 5), sticky="ew")

            view_lbl = ctk.CTkLabel(self.viewport_frame, text="Awaiting Data...", text_color="#616161")
            view_lbl.grid(row=1, column=i, padx=3, pady=5, sticky="nsew")
            self.lbl_views.append(view_lbl)

        # Control Panel Options Panel
        control_panel = ctk.CTkFrame(self, height=365)
        control_panel.pack(side=tk.BOTTOM, fill=tk.X, padx=15, pady=15)

        self.tabview = ctk.CTkTabview(control_panel, height=340)
        self.tabview.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=5)

        self.tab_prep = self.tabview.add(" Tab 1 — Illumination & Conditioning ")
        self.tab_marker = self.tabview.add(" Tab 2 — Marker Generation ")
        self.tab_ws = self.tabview.add(" Tab 3 — Watershed Optimization ")
        self.tab_filter = self.tabview.add(" Tab 4 — Defect Filtering ")

        self.build_tabs_layout()

        right_bar = ctk.CTkFrame(control_panel, width=240, fg_color="transparent")
        right_bar.pack(side=tk.RIGHT, fill=tk.Y, padx=10, pady=10)

        self.export_btn = ctk.CTkButton(right_bar, text="💾 Export Output\n(Single or Batch Folder)", command=self.start_async_export,
                                   font=('Helvetica', 12, 'bold'), fg_color="#2e7d32", hover_color="#1b5e20")
        self.export_btn.pack(fill=tk.BOTH, expand=True, pady=10)

    def create_parameter_row(self, parent, key, label_text, from_val, to_val, current_val, row_idx, is_float=False, resolution=1):
        lbl = ctk.CTkLabel(parent, text=label_text, font=('Helvetica', 11), anchor='w')
        lbl.grid(row=row_idx, column=0, sticky='w', pady=3, padx=10)

        var = tk.DoubleVar(value=current_val) if is_float else tk.IntVar(value=current_val)
        self.params[key] = var

        slider = ctk.CTkSlider(parent, from_=from_val, to=to_val, number_of_steps=int((to_val-from_val)/resolution), variable=var)
        slider.grid(row=row_idx, column=1, sticky='ew', padx=20, pady=3)

        spinbox = CTkSpinbox(parent, from_val, to_val, current_val, is_float, resolution, linked_var=var, on_update_callback=self.trigger_pipeline_refresh)
        spinbox.grid(row=row_idx, column=2, padx=10, pady=3)

        slider.bind("<ButtonRelease-1>", lambda event: self.sync_slider_to_spinbox(var, spinbox))
        spinbox.entry.bind("<Return>", lambda event: self.sync_spinbox_to_slider(spinbox, var, from_val, to_val))

        parent.columnconfigure(1, weight=1)
        return var, spinbox

    def sync_slider_to_spinbox(self, var, spinbox):
        if self.updating_ui: return
        self.updating_ui = True
        spinbox.set_value(var.get())
        self.updating_ui = False
        self.trigger_pipeline_refresh()

    def sync_spinbox_to_slider(self, spinbox, var, from_val, to_val):
        if self.updating_ui: return
        self.updating_ui = True
        val = spinbox.get_value()
        if from_val <= val <= to_val:
            var.set(val)
            self.updating_ui = False
            self.trigger_pipeline_refresh()
            return
        else:
            messagebox.showwarning("Out of Bounds", f"Value must be between {from_val} and {to_val}")
        self.updating_ui = False

    def build_tabs_layout(self):
        # Tab 1 — Illumination Normalization & Image Conditioning
        self.create_parameter_row(self.tab_prep, "gdiv_k", "Gaussian Division Kernel Size (Odd):", 15, 151, 51, 0, resolution=2)
        self.create_parameter_row(self.tab_prep, "gdiv_sigma", "Gaussian Division Sigma (0=auto):", 0.0, 60.0, 0.0, 1, is_float=True, resolution=1.0)
        self.create_parameter_row(self.tab_prep, "gaussian_k", "Post-Division Gaussian Kernel Size (Odd):", 1, 31, 9, 2, resolution=2)
        self.create_parameter_row(self.tab_prep, "bilat_d", "Bilateral Filter Diameter:", 1, 25, 9, 3, resolution=1)
        self.create_parameter_row(self.tab_prep, "bilat_sc", "Bilateral Sigma Color:", 5.0, 200.0, 75.0, 4, is_float=True, resolution=5.0)
        self.create_parameter_row(self.tab_prep, "bilat_ss", "Bilateral Sigma Space:", 5.0, 200.0, 75.0, 5, is_float=True, resolution=5.0)
        self.create_parameter_row(self.tab_prep, "nlm_strength", "Non-Local Means Strength (0=off):", 0.0, 30.0, 0.0, 6, is_float=True, resolution=1.0)
        self.create_parameter_row(self.tab_prep, "morph_open_it", "Morphological Opening Iterations:", 0, 10, 1, 7, resolution=1)
        self.create_parameter_row(self.tab_prep, "morph_close_it", "Morphological Closing Iterations:", 0, 10, 1, 8, resolution=1)
        self.create_parameter_row(self.tab_prep, "se_size", "Structuring Element Size:", 1, 15, 3, 9, resolution=1)
        self.create_parameter_row(self.tab_prep, "se_shape", "Structuring Element Shape (0:R, 1:E, 2:C):", 0, 2, 0, 10, resolution=1)

        # Tab 2 — Marker Generation (bright AND dark polarity, plus pre-marker noise cleanup)
        self.create_parameter_row(self.tab_marker, "dt_type", "Distance Transform Type (0:L1, 1:L2, 2:C):", 0, 2, 1, 0, resolution=1)
        self.create_parameter_row(self.tab_marker, "dt_mask", "Distance Mask Size (3 or 5):", 3, 5, 5, 1, resolution=2)
        self.create_parameter_row(self.tab_marker, "local_max_min_dist", "Local Maxima Minimum Distance:", 1, 50, 5, 2, resolution=1)
        self.create_parameter_row(self.tab_marker, "marker_refine_radius", "Marker Refinement Radius:", 0, 10, 1, 3, resolution=1)
        self.create_parameter_row(self.tab_marker, "h_min_depth", "H-Maxima Depth (Bright):", 0.0, 100.0, 10.0, 4, is_float=True, resolution=1.0)
        self.create_parameter_row(self.tab_marker, "ext_min_depth", "Extended Minima Cutoff (Bright):", 0.0, 100.0, 5.0, 5, is_float=True, resolution=1.0)
        self.create_parameter_row(self.tab_marker, "h_min_depth_dark", "H-Minima Depth (Dark):", 0.0, 100.0, 10.0, 6, is_float=True, resolution=1.0)
        self.create_parameter_row(self.tab_marker, "ext_min_depth_dark", "Extended Minima Cutoff (Dark):", 0.0, 100.0, 5.0, 7, is_float=True, resolution=1.0)
        self.create_parameter_row(self.tab_marker, "min_peak_pixels", "Min Candidate Blob Size (px, noise filter):", 0, 50, 4, 8, resolution=1)
        self.create_parameter_row(self.tab_marker, "noise_open_radius", "Candidate Mask Opening Radius:", 0, 5, 1, 9, resolution=1)

        # Tab 3 — Watershed Optimization (unchanged)
        self.create_parameter_row(self.tab_ws, "compactness", "Compactness Regularization Factor:", 0.0, 10.0, 0.0, 0, is_float=True, resolution=0.1)
        self.create_parameter_row(self.tab_ws, "connectivity", "Connectivity Neighborhood Radius:", 1, 8, 1, 1, resolution=1)
        self.create_parameter_row(self.tab_ws, "ridge_enhancement", "Ridge Enhancement Strength Scalar:", 1.0, 5.0, 1.0, 2, is_float=True, resolution=0.2)
        self.create_parameter_row(self.tab_ws, "flooding_smoothness", "Flooding Topology Smoothness Kernel:", 0, 15, 0, 3, resolution=1)

        # Tab 4 — Defect Filtering
        # NOTE: min_circularity / min_solidity now default to non-zero values
        # (0.3 / 0.5) instead of 0.0 -- a threshold-only pipeline has no shape
        # concept at all, which is why noise previously passed straight
        # through as "defects". These defaults reject obviously non-blob-like
        # noise fragments out of the box while still being fully tunable.
        self.create_parameter_row(self.tab_filter, "min_area", "Minimum Area Limit (Pixels):", 10, 20000, 50, 0, resolution=10)
        self.create_parameter_row(self.tab_filter, "max_area", "Maximum Area Limit (Pixels):", 100, 50000, 10000, 1, resolution=100)
        self.create_parameter_row(self.tab_filter, "min_circularity", "Minimum Circularity Metric:", 0.0, 1.0, 0.3, 2, is_float=True, resolution=0.05)
        self.create_parameter_row(self.tab_filter, "min_solidity", "Minimum Solidity Density:", 0.0, 1.0, 0.5, 3, is_float=True, resolution=0.05)
        self.create_parameter_row(self.tab_filter, "max_aspect_ratio", "Maximum Aspect Ratio Bound:", 1.0, 20.0, 10.0, 4, is_float=True, resolution=0.5)
        self.create_parameter_row(self.tab_filter, "min_convexity", "Minimum Boundary Convexity:", 0.0, 1.0, 0.0, 5, is_float=True, resolution=0.05)

    def load_image_action(self):
        file_path = filedialog.askopenfilename(filetypes=[("All Image Formats", "*.jpg *.jpeg *.png *.bmp *.tiff *.pgm")])
        if file_path:
            self.folder_path = None
            self.image_path = file_path
            self.path_lbl.configure(text=os.path.basename(file_path))
            self.trigger_pipeline_refresh()

    def load_folder_action(self):
        folder_path = filedialog.askdirectory(title="Select Batch Folder of AM Images")
        if folder_path:
            self.image_path = None
            self.folder_path = folder_path
            files = [f for f in os.listdir(folder_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp'))]
            self.path_lbl.configure(text=f"Batch Folder: {os.path.basename(folder_path)} ({len(files)} target images)")

            if len(files) > 0:
                self.image_path = os.path.join(folder_path, files[0])
                self.trigger_pipeline_refresh()

    def get_current_params_dict(self):
        return {k: v.get() for k, v in self.params.items()}

    def trigger_pipeline_refresh(self):
        if not self.image_path or self.updating_ui:
            return

        p_dict = self.get_current_params_dict()
        results = process_powder_bed_pipeline(self.image_path, self.max_display_dim, p_dict)

        if results is not None:
            self.update_native_viewports(results)

    def convert_to_ctk_image(self, cv_img, is_gray=False, use_cmap=False):
        if use_cmap:
            norm_topo = cv2.normalize(cv_img, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
            color_mapped = cv2.applyColorMap(norm_topo, cv2.COLORMAP_VIRIDIS)
            rgb = cv2.cvtColor(color_mapped, cv2.COLOR_BGR2RGB)
        elif is_gray:
            rgb = cv2.cvtColor(cv_img, cv2.COLOR_GRAY2RGB)
        else:
            rgb = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)

        h, w = rgb.shape[:2]
        pil_img = Image.fromarray(rgb)
        return ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(w, h))

    def update_native_viewports(self, results):
        for i, (_title, key, kwargs) in enumerate(VIEWPORT_DEFS):
            cv_img = results.get(key)
            if cv_img is None:
                continue
            ctk_img = self.convert_to_ctk_image(cv_img, **kwargs)
            self.lbl_views[i].configure(image=ctk_img, text="")
            self.lbl_views[i].image = ctk_img

    def start_async_export(self):
        if not self.image_path and not self.folder_path:
            messagebox.showwarning("Export Error", "Please load a single image or batch folder first.")
            return

        selected_parent_dir = filedialog.askdirectory(title="Select Destination Folder")
        if not selected_parent_dir:
            return

        self.export_btn.configure(state="disabled", text="⏳ Running High-Res Batch Pool...")

        export_thread = threading.Thread(target=self.background_export_worker, args=(selected_parent_dir,))
        export_thread.daemon = True
        export_thread.start()

    def background_export_worker(self, target_base_path):
        try:
            p_dict = self.get_current_params_dict()

            if self.folder_path:
                output_dir = os.path.join(target_base_path, "Output_Images_Watershed")
                os.makedirs(output_dir, exist_ok=True)
                files_to_process = [
                    os.path.join(self.folder_path, f)
                    for f in os.listdir(self.folder_path)
                    if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp'))
                ]
            else:
                base_filename = os.path.splitext(os.path.basename(self.image_path))[0]
                output_dir = os.path.join(target_base_path, f"watershed_{base_filename}_outputs")
                os.makedirs(output_dir, exist_ok=True)
                files_to_process = [self.image_path]

            def process_single_file(file_path):
                file_name_only = os.path.splitext(os.path.basename(file_path))[0]

                results = process_powder_bed_pipeline(file_path, None, p_dict)
                if results is None:
                    return

                if self.folder_path:
                    output_file_name = f"{file_name_only}_segmented.png"
                    cv2.imwrite(os.path.join(output_dir, output_file_name),
                                cv2.cvtColor(results["final_output"], cv2.COLOR_RGB2BGR))
                else:
                    # Single-image export: dump every intermediate stage so the
                    # full pipeline can be inspected/debugged offline (Task 9).
                    cv2.imwrite(os.path.join(output_dir, "export_1_input.png"), cv2.imread(file_path))
                    cv2.imwrite(os.path.join(output_dir, "export_2_gaussian_division.png"), results["gaussian_division"])
                    cv2.imwrite(os.path.join(output_dir, "export_3_background_estimate.png"), results["background"])
                    cv2.imwrite(os.path.join(output_dir, "export_4_conditioned.png"), results["conditioned"])

                    grad_norm = cv2.normalize(results["gradient"], None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
                    cv2.imwrite(os.path.join(output_dir, "export_5_gradient_topology.png"),
                                cv2.applyColorMap(grad_norm, cv2.COLORMAP_VIRIDIS))

                    cv2.imwrite(os.path.join(output_dir, "export_6_markers.png"), results["markers"])

                    dist_norm = cv2.normalize(results["distance"], None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
                    cv2.imwrite(os.path.join(output_dir, "export_7_distance_transform.png"), dist_norm)

                    cv2.imwrite(os.path.join(output_dir, "export_8_binary_mask.png"), results["binary_mask"])
                    cv2.imwrite(os.path.join(output_dir, "export_9_white_defects.png"),
                                cv2.cvtColor(results["white_display"], cv2.COLOR_RGB2BGR))
                    cv2.imwrite(os.path.join(output_dir, "export_10_dark_defects.png"),
                                cv2.cvtColor(results["dark_display"], cv2.COLOR_RGB2BGR))
                    cv2.imwrite(os.path.join(output_dir, "export_11_final_segmentation.png"),
                                cv2.cvtColor(results["final_output"], cv2.COLOR_RGB2BGR))

                    with open(os.path.join(output_dir, "parameters.json"), "w") as f:
                        json.dump({"configured_parameters": p_dict, "engine": "topological_watershed_v2_dual_polarity"}, f, indent=4)

            with ThreadPoolExecutor() as executor:
                executor.map(process_single_file, files_to_process)

            self.after(0, lambda: self.on_export_complete(output_dir))

        except Exception as e:
            self.after(0, lambda: self.on_export_failed(str(e)))

    def on_export_complete(self, output_dir):
        self.export_btn.configure(state="normal", text="💾 Export Output\n(Single or Batch Folder)")
        messagebox.showinfo("Export Successful", f"Operations completed successfully!\nTarget Directory:\n{output_dir}")

    def on_export_failed(self, error_msg):
        self.export_btn.configure(state="normal", text="💾 Export Output\n(Single or Batch Folder)")
        messagebox.showerror("Export Error", f"An execution error occurred:\n{error_msg}")


if __name__ == "__main__":
    app = UltimateWatershedWorkstation()
    app.mainloop()
