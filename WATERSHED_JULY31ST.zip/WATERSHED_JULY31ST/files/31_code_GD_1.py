"""
=============================================================================
 Additive Manufacturing Powder Bed Inspection Workstation  (v2 - Dual-Polarity
 Gaussian-Division Topological Engine)
=============================================================================

WHAT CHANGED AND WHY
---------------------------------------------------------------------------
The previous version ("JUL29th_fixed.py") only ever detected BRIGHT defects.
The root cause was algorithmic, not a bad parameter value:

    seed          = image - h_min_depth
    reconstructed = morphological_reconstruction(seed, image, method='dilation')
    hdome         = image - reconstructed

This is the classical "H-DOME" transform. Because the marker (seed) is
LOWER than the image and reconstruction-by-DILATION can only ever grow UP
to the mask, `reconstructed` can never fall below the image in a dark
pit/pore - it simply fills back up to the local floor of the image and
hdome == 0 there. In bright peaks (spatter, raised particles) shorter than
h_min_depth, the peak gets flattened by the reconstruction and hdome > 0.
So structurally, this transform is BLIND to dark defects: there is no
parameter value that fixes it, because the direction of the morphological
operator itself only lets bright relief through.

The complementary operator - the "H-MINIMA dome" (a.k.a. valley transform)
- is required to see dark defects:

    seed          = image + h_min_depth
    reconstructed = morphological_reconstruction(seed, image, method='erosion')
    vdome         = reconstructed - image

Here the marker is HIGHER than the image and reconstruction-by-EROSION can
only shrink DOWN to the mask, so it fills bright regions flat and leaves
deep, narrow dark pits standing out as positive `vdome` values. This is
the mathematical dual of the original transform and is the single most
important fix in this rewrite: the pipeline now runs BOTH transforms and
tracks bright/dark defects as two independent, always-present channels
(never a hidden secondary path).

Second problem: false positives from powder texture. Individual powder
particles create a locally very high-contrast granular texture (measured
directly on the supplied images: per-particle intensity ripples are large
enough that, prior to this fix, >99% of "detections" were single-grain
noise scattered uniformly across the whole image, not real defects).
No amount of thresholding on the dome height fixed this, because the
noise floor of the dome transform itself is proportional to how much
grain-scale texture survives into the image handed to it. The real fix
is to remove grain-scale spatial structure BEFORE the dome extraction
with heavy low-pass smoothing at a scale larger than an individual
particle but smaller than genuine defect footprints, and then to apply a
connected-component AREA gate before markers/watershed are ever computed
(so texture speckles never reach the expensive segmentation stage at
all). This was measured empirically on the provided PBF image set (see
"PARAMETER TUNING NOTES" below).

Third problem: illumination dependence. Block-averaging the supplied
images shows a smooth ~50-intensity-level vignette/gradient across the
frame (measured: block means ranged ~76-130 on a single frame while the
whole-dataset mean/std across 39 images was extremely stable at
112.3 +/- 0.7 / 18.0 +/- 0.7, i.e. the DATASET is consistent but each
FRAME has real internal shading). A single global threshold therefore
always over- or under-fires somewhere in the frame. Gaussian Division
(this file's central preprocessing stage) fixes this directly:

    corrected(x,y) = image(x,y) / gaussian_blur(image(x,y), large_kernel)

dividing out everything that varies slowly (illumination, vignetting,
recoater-blade shading gradients) while leaving high-frequency content
(texture, defects) intact. The result is renormalized back to the
original intensity scale so every later stage (which is intensity-based)
keeps working with familiar numbers.

Fourth problem: resolution dependence. The old code used fixed *pixel*
kernel sizes that behaved differently in the live low-res preview
(image resized to `max_dim`) than during full-resolution batch export -
parameters tuned by eye in the preview silently changed meaning on
export. All spatial kernel parameters in this file are now expressed
"as if the image were ~900 px on its long side" and rescaled per-image
by `scale = max(h, w) / 900` before use, so preview and export always
agree.

PARAMETER TUNING NOTES (measured on the supplied PBF recoat image set)
---------------------------------------------------------------------------
- Dataset stats (39 images, grayscale): mean intensity 112.3 (std across
  images 0.7), per-image texture std 18.0 (std across images 0.7) -> the
  dataset is photometrically consistent, so fixed default parameters are
  reasonable, but real per-frame illumination gradients still exist
  (measured ~50 intensity levels corner-to-corner on individual frames),
  which is what makes Gaussian Division necessary rather than optional.
- Powder-grain texture is a few pixels across. A light denoise (bilateral
  or small Gaussian, ~9x9) leaves the per-grain dome/valley noise floor
  at ~90-99th percentile dome heights of 6-9 intensity levels out of a
  10-level search depth - i.e. individual grains alone can look almost
  as "deep" as real defects, and no threshold on the dome height alone
  can separate them.
- Increasing the PRE-dome-extraction smoothing kernel to ~31 px
  (at 900 px reference resolution) and re-checking the dome map
  visually/statistically shows the noise collapses to sparse, spatially
  isolated blobs rather than a uniform mesh, while known defect clusters
  (e.g. the recoater-streak spatter chain visible in several sample
  frames) remain clearly elevated. This is the scale used by default.
- A connected-component AREA gate of ~60 px^2 (at reference resolution,
  scaled quadratically with image resolution) removes essentially all
  remaining single/few-grain speckles while preserving genuine defect
  blobs, which are consistently larger and more coherent.
- With these settings, defect counts across the sample set dropped from
  ~140 spurious components/image (before this rewrite) to a realistic
  ~5-30 components/image covering both polarities, concentrated at the
  visible spatter/streak locations rather than being spread uniformly
  across the frame.

Every numeric default below was chosen from this analysis, not picked
arbitrarily; each parameter remains exposed and adjustable in the GUI so
the operator can retune per-dataset.
=============================================================================
"""

import os
import json
import cv2
import numpy as np
import tkinter as tk
import customtkinter as ctk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import threading
from concurrent.futures import ThreadPoolExecutor

# --- ENGINE IMPORTS ---
from skimage.segmentation import watershed
from skimage.morphology import disk, reconstruction
from skimage.feature import peak_local_max

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

# All spatial-kernel parameters in this file are specified "as if the
# longest image side were REFERENCE_DIM pixels" and rescaled per-image so
# that the live preview (downsized to max_dim) and full-resolution batch
# export produce consistent results from the same slider values.
REFERENCE_DIM = 900.0


def _scaled_odd(value, scale):
    """Scale a kernel size by the image-resolution factor and force it to
    a valid odd, >=1 integer (required by cv2 blur / structuring element
    APIs)."""
    k = int(round(value * scale))
    if k < 1:
        k = 1
    if k % 2 == 0:
        k += 1
    return k


def _scaled_int(value, scale):
    k = int(round(value * scale))
    return max(1, k)


# =============================================================================
# STAGE 1 - ILLUMINATION CORRECTION (Gaussian Division)
# =============================================================================
def gaussian_division(gray_f, kernel_px):
    """
    Corrected Image = Original Image / Gaussian-Blurred Image.

    The Gaussian-blurred image is a slowly-varying estimate of the local
    background illumination (vignetting, recoater shading gradients, bed
    heater glow, etc). Dividing it out normalizes local contrast and
    removes low-frequency shading while leaving high-frequency content -
    powder texture AND defects - intact. The +1.0 in the denominator
    avoids division blow-ups in near-zero-intensity pixels; multiplying
    back by the mean background rescales the result to the original
    intensity range so every later intensity-based stage keeps working
    with familiar numbers.
    """
    background = cv2.GaussianBlur(gray_f, (kernel_px, kernel_px), 0)
    corrected = gray_f / (background + 1.0) * float(np.mean(background))
    return corrected, background


# =============================================================================
# STAGE 2 - DUAL H-DOME / H-MINIMA-DOME EXTRACTION
# =============================================================================
def extract_dome(image_f, depth, polarity):
    """
    Extracts regional relief of a given polarity via grayscale
    morphological reconstruction.

    polarity == 'bright' (H-DOME transform):
        seed = image - depth   (seed <= image everywhere)
        reconstruction by DILATION grows the seed back up to the image,
        but cannot climb over peaks narrower/shorter than `depth` -
        those peaks survive as (image - reconstructed) > 0.
        -> lights up spatter, raised particles, bright contamination.

    polarity == 'dark' (H-MINIMA / valley-dome transform - the fix for
    dark-defect blindness in the original pipeline):
        seed = image + depth   (seed >= image everywhere)
        reconstruction by EROSION shrinks the seed back down to the
        image, but cannot fall into pits narrower/deeper than `depth` -
        those pits survive as (reconstructed - image) > 0.
        -> lights up pores, depressions, lack-of-powder, incomplete
           fusion, dark contamination.
    """
    if polarity == 'bright':
        seed = image_f - depth
        reconstructed = reconstruction(seed, image_f, method='dilation')
        return image_f - reconstructed, reconstructed
    else:
        seed = image_f + depth
        reconstructed = reconstruction(seed, image_f, method='erosion')
        return reconstructed - image_f, reconstructed


# =============================================================================
# STAGE 3 - NOISE SUPPRESSION ON BINARY CANDIDATE MASKS
# =============================================================================
def binarize_and_clean(dome, threshold, open_k, min_area):
    """
    Threshold the dome map, then apply two complementary noise-removal
    steps before the (expensive, and noise-sensitive) watershed stage
    ever sees the data:

      1. Morphological opening - strips isolated single/few-pixel
         speckle while leaving larger blobs' shapes intact.
      2. Connected-component AREA filtering - removes every surviving
         component smaller than `min_area`, which (per the tuning notes
         above) is comfortably larger than residual grain-scale noise
         but smaller than genuine defect footprints.
    """
    binary = (dome > threshold).astype(np.uint8) * 255
    if open_k > 0:
        se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (open_k, open_k))
        binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, se)
    n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(binary, connectivity=8)
    cleaned = np.zeros_like(binary)
    for i in range(1, n_labels):
        if stats[i, cv2.CC_STAT_AREA] >= min_area:
            cleaned[labels == i] = 255
    return cleaned


# =============================================================================
# STAGE 4 - MARKER GENERATION (per polarity)
# =============================================================================
def build_markers(binary_mask, dt_type, dt_mask_size, min_dist, refine_radius):
    """Distance-transform + local-maxima marker generation, restricted to
    one polarity's cleaned candidate mask. Falls back to plain connected
    components if no clean local maxima are found (e.g. very small or
    perfectly flat blobs)."""
    if binary_mask.max() == 0:
        return np.zeros_like(binary_mask, dtype=np.int32), np.zeros_like(binary_mask, dtype=np.float32)

    dist_trans = cv2.distanceTransform(binary_mask, dt_type, dt_mask_size)
    coords = peak_local_max(dist_trans, min_distance=max(1, min_dist), labels=binary_mask)

    markers = np.zeros_like(binary_mask, dtype=np.int32)
    for idx, pt in enumerate(coords):
        markers[pt[0], pt[1]] = idx + 1

    if np.max(markers) == 0:
        _, markers = cv2.connectedComponents(binary_mask)

    if refine_radius > 0:
        se = cv2.getStructuringElement(cv2.MORPH_RECT, (refine_radius * 2 + 1, refine_radius * 2 + 1))
        markers = cv2.dilate(markers.astype(np.float32), se).astype(np.int32)

    return markers, dist_trans


# =============================================================================
# STAGE 5 - SHAPE-BASED DEFECT VALIDATION (unchanged geometry, reused per polarity)
# =============================================================================
def shape_filter(seg_labels, shape, min_area, max_area, min_circ, min_solid, max_aspect, min_conv):
    mask_out = np.zeros(shape, dtype=np.uint8)
    if seg_labels.max() == 0:
        return mask_out
    for label in np.unique(seg_labels):
        if label == 0:
            continue
        component_mask = (seg_labels == label).astype(np.uint8) * 255
        cnts, _ = cv2.findContours(component_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            continue
        c = max(cnts, key=cv2.contourArea)
        area = cv2.contourArea(c)
        if not (min_area <= area <= max_area):
            continue

        perimeter = cv2.arcLength(c, True)
        circularity = (4 * np.pi * area) / (perimeter ** 2) if perimeter > 0 else 0

        hull = cv2.convexHull(c)
        hull_area = cv2.contourArea(hull)
        solidity = float(area) / hull_area if hull_area > 0 else 0

        x, y, w_b, h_b = cv2.boundingRect(c)
        aspect_ratio = float(max(w_b, h_b)) / min(w_b, h_b) if min(w_b, h_b) > 0 else 0

        convexity = float(cv2.arcLength(hull, True)) / perimeter if perimeter > 0 else 0

        if (circularity >= min_circ and solidity >= min_solid and
                aspect_ratio <= max_aspect and convexity >= min_conv):
            mask_out[seg_labels == label] = 255
    return mask_out


# =============================================================================
# MAIN PIPELINE
# =============================================================================
def process_powder_bed_pipeline(image_path, max_dim, params, full_stage_output=False):
    """
    Runs the complete dual-polarity inspection pipeline.

    Returns (for the live 6-viewport GUI):
        img_disp        - perspective-corrected, resized input
        final_mask       - combined binary defect mask (bright OR dark)
        illum_disp       - Gaussian-Division illumination-corrected view
        white_display    - RGB image with BRIGHT defects highlighted (red)
        dark_display     - RGB image with DARK defects highlighted (blue)
        final_output     - RGB image with BOTH classes highlighted distinctly

    If full_stage_output=True, a 7th return value is included: a dict of
    every intermediate stage (background estimate, conditioned/denoised
    image, bright/dark dome maps, gradient, distance transforms, raw
    watershed label maps) for detailed offline export - see Task #9 in
    the design brief.
    """
    img = cv2.imread(image_path)
    if img is None:
        return (None,) * (7 if full_stage_output else 6)

    # --- Perspective Correction / Flattening (unchanged from original) ---
    gray_full = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred_warp = cv2.GaussianBlur(gray_full, (5, 5), 0)
    _, warp_thresh = cv2.threshold(blurred_warp, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    contours, _ = cv2.findContours(warp_thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if len(contours) > 0:
        largest_contour = max(contours, key=cv2.contourArea)
        peri = cv2.arcLength(largest_contour, True)
        approx = cv2.approxPolyDP(largest_contour, 0.02 * peri, True)
        if len(approx) == 4:
            pts = approx.reshape(4, 2)
            rect = np.zeros((4, 2), dtype="float32")
            s = pts.sum(axis=1)
            rect[0] = pts[np.argmin(s)]
            rect[2] = pts[np.argmax(s)]
            diff = np.diff(pts, axis=1)
            rect[1] = pts[np.argmin(diff)]
            rect[3] = pts[np.argmax(diff)]

            (tl, tr, br, bl) = rect
            widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
            widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
            maxWidth = max(int(widthA), int(widthB))

            heightA = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
            heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
            maxHeight = max(int(heightA), int(heightB))

            dst = np.array([
                [0, 0],
                [maxWidth - 1, 0],
                [maxWidth - 1, maxHeight - 1],
                [0, maxHeight - 1]], dtype="float32")

            M = cv2.getPerspectiveTransform(rect, dst)
            img = cv2.warpPerspective(img, M, (maxWidth, maxHeight))

    # --- Resize Strategy for responsive live editing (unchanged) ---
    h, w = img.shape[:2]
    if max_dim is not None and max(h, w) > max_dim:
        scale_disp = max_dim / float(max(h, w))
        img_disp = cv2.resize(img, (int(w * scale_disp), int(h * scale_disp)), interpolation=cv2.INTER_AREA)
    else:
        img_disp = img.copy()

    gray = cv2.cvtColor(img_disp, cv2.COLOR_BGR2GRAY)
    gray_f = gray.astype(np.float32)

    # Resolution-adaptive scale factor: every kernel size below is defined
    # "as if this image were REFERENCE_DIM px on its long side" and scaled
    # here so the preview and full-res export always agree.
    res_scale = max(gray.shape) / REFERENCE_DIM

    # ---------------- STAGE 1: Illumination Correction ----------------
    illum_k = _scaled_odd(params.get("illum_kernel", 121), res_scale)
    corrected, background = gaussian_division(gray_f, illum_k)

    # ---------------- STAGE 2: Grain-scale noise suppression ----------------
    presmooth_k = _scaled_odd(params.get("presmooth_k", 31), res_scale)
    conditioned = cv2.GaussianBlur(corrected, (presmooth_k, presmooth_k), 0)

    bilat_d = int(params.get("bilat_d", 9))
    bilat_sc = float(params.get("bilat_sc", 20.0))
    bilat_ss = float(params.get("bilat_ss", 9.0))
    conditioned = cv2.bilateralFilter(conditioned, bilat_d, bilat_sc, bilat_ss)

    # ---------------- STAGE 3: Dual dome extraction ----------------
    search_depth = float(params.get("search_depth", 15.0))
    bright_dome, bright_recon = extract_dome(conditioned, search_depth, 'bright')
    dark_dome, dark_recon = extract_dome(conditioned, search_depth, 'dark')

    # ---------------- STAGE 4: Threshold + clean each polarity ----------------
    open_k = int(params.get("cleanup_open_k", 3))
    prelim_min_area = max(1, int(round(params.get("prelim_min_area", 60) * (res_scale ** 2))))

    binary_bright = binarize_and_clean(bright_dome, float(params.get("bright_dome_thresh", 9.0)), open_k, prelim_min_area)
    binary_dark = binarize_and_clean(dark_dome, float(params.get("dark_dome_thresh", 9.0)), open_k, prelim_min_area)

    # ---------------- STAGE 5: Flooding surface for watershed ----------------
    # A polarity-agnostic gradient magnitude works as the flooding surface
    # for BOTH bright and dark watershed runs, since gradients are always
    # positive regardless of which side of a defect boundary they sit on.
    grad_se = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    topo_surface = cv2.morphologyEx(conditioned, cv2.MORPH_GRADIENT, grad_se)

    ridge_enhancement = float(params.get("ridge_enhancement", 1.0))
    if ridge_enhancement > 1.0:
        topo_surface = cv2.multiply(topo_surface, ridge_enhancement)

    flooding_smoothness = _scaled_odd(params.get("flooding_smoothness", 0), res_scale) \
        if params.get("flooding_smoothness", 0) > 0 else 0
    if flooding_smoothness > 0:
        topo_surface = cv2.GaussianBlur(topo_surface, (flooding_smoothness, flooding_smoothness), 0)

    # ---------------- STAGE 6: Marker generation (per polarity) ----------------
    dist_types = [cv2.DIST_L1, cv2.DIST_L2, cv2.DIST_C]
    dt_type = dist_types[np.clip(int(params.get("dt_type", 1)), 0, 2)]
    dt_mask = int(params.get("dt_mask", 5))
    if dt_mask not in (0, 3, 5):
        dt_mask = 5
    min_dist = _scaled_int(params.get("local_max_min_dist", 8), res_scale)
    refine_r = int(params.get("marker_refine_radius", 1))

    markers_bright, dist_bright = build_markers(binary_bright, dt_type, dt_mask, min_dist, refine_r)
    markers_dark, dist_dark = build_markers(binary_dark, dt_type, dt_mask, min_dist, refine_r)

    # ---------------- STAGE 7: Watershed (per polarity) ----------------
    comp = float(params.get("compactness", 0.0))
    conn_radius = int(params.get("connectivity", 1))
    footprint = disk(conn_radius) if conn_radius > 1 else None

    seg_bright = (watershed(topo_surface, markers_bright, mask=binary_bright, compactness=comp, connectivity=footprint)
                  if binary_bright.max() > 0 else np.zeros_like(binary_bright, dtype=np.int32))
    seg_dark = (watershed(topo_surface, markers_dark, mask=binary_dark, compactness=comp, connectivity=footprint)
                if binary_dark.max() > 0 else np.zeros_like(binary_dark, dtype=np.int32))

    # ---------------- STAGE 8: Shape-based validation (per polarity) ----------------
    min_area = int(params.get("min_area", 60))
    max_area = int(params.get("max_area", 8000))
    min_circ = float(params.get("min_circularity", 0.0))
    min_solid = float(params.get("min_solidity", 0.0))
    max_aspect = float(params.get("max_aspect_ratio", 10.0))
    min_conv = float(params.get("min_convexity", 0.0))

    final_bright_mask = shape_filter(seg_bright, gray.shape, min_area, max_area, min_circ, min_solid, max_aspect, min_conv)
    final_dark_mask = shape_filter(seg_dark, gray.shape, min_area, max_area, min_circ, min_solid, max_aspect, min_conv)

    final_mask = cv2.bitwise_or(final_bright_mask, final_dark_mask)

    # ---------------- STAGE 9: Visualization ----------------
    bg_rgb = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
    illum_disp = cv2.normalize(corrected, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)

    white_display = bg_rgb.copy()
    dark_display = bg_rgb.copy()
    final_output = bg_rgb.copy()

    bright_cnts, _ = cv2.findContours(final_bright_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    dark_cnts, _ = cv2.findContours(final_dark_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    cv2.drawContours(white_display, bright_cnts, -1, (255, 0, 0), -1)
    cv2.drawContours(dark_display, dark_cnts, -1, (0, 140, 255), -1)
    # Classification is now determined by WHICH transform produced the
    # region (a structural fact from the pipeline), not by re-guessing
    # from a single centroid intensity sample against a hardcoded
    # threshold as the original code did.
    cv2.drawContours(final_output, bright_cnts, -1, (255, 0, 0), -1)      # bright defects -> red
    cv2.drawContours(final_output, dark_cnts, -1, (0, 140, 255), -1)     # dark defects -> orange/blue

    if not full_stage_output:
        return img_disp, final_mask, illum_disp, white_display, dark_display, final_output

    stages = {
        "background_estimate": cv2.normalize(background, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U),
        "conditioned": cv2.normalize(conditioned, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U),
        "bright_dome": cv2.normalize(bright_dome, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U),
        "dark_dome": cv2.normalize(dark_dome, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U),
        "gradient": cv2.normalize(topo_surface, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U),
        "binary_bright": binary_bright,
        "binary_dark": binary_dark,
        "dist_bright": cv2.normalize(dist_bright, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U),
        "dist_dark": cv2.normalize(dist_dark, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U),
        "markers_bright": cv2.normalize(markers_bright.astype(np.float32), None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U),
        "markers_dark": cv2.normalize(markers_dark.astype(np.float32), None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U),
    }
    return img_disp, final_mask, illum_disp, white_display, dark_display, final_output, stages


# =============================================================================
# COMPONENT SPINBOX & SYNCHRONIZER (unchanged from original)
# =============================================================================
class CTkSpinbox(ctk.CTkFrame):
    def __init__(self, parent, from_val, to_val, current_val, is_float=False, resolution=1, linked_var=None, on_update_callback=None):
        super().__init__(parent, fg_color="transparent")
        self.from_val = from_val
        self.to_val = to_val
        self.is_float = is_float
        self.resolution = resolution
        self.linked_var = linked_var
        self.callback = on_update_callback

        self.btn_down = ctk.CTkButton(self, text="▼", width=28, height=28, font=("Arial", 10),
                                      fg_color="#37474f", hover_color="#263238", command=self.decrement)
        self.btn_down.pack(side=tk.LEFT, padx=2)

        self.entry = ctk.CTkEntry(self, width=65, height=28, font=('Helvetica', 12), justify='center')
        self.entry.insert(0, f"{current_val:.2f}" if self.is_float else str(int(current_val)))
        self.entry.pack(side=tk.LEFT, padx=2)

        self.btn_up = ctk.CTkButton(self, text="▲", width=28, height=28, font=("Arial", 10),
                                    fg_color="#37474f", hover_color="#263238", command=self.increment)
        self.btn_up.pack(side=tk.LEFT, padx=2)

    def get_value(self):
        try:
            return float(self.entry.get()) if self.is_float else int(float(self.entry.get()))
        except ValueError:
            return self.from_val

    def set_value(self, val):
        self.entry.delete(0, tk.END)
        self.entry.insert(0, f"{val:.2f}" if self.is_float else str(int(val)))
        if self.linked_var:
            self.linked_var.set(val)

    def increment(self):
        curr = self.get_value()
        new_val = np.clip(curr + self.resolution, self.from_val, self.to_val)
        self.set_value(new_val)
        if self.callback:
            self.callback()

    def decrement(self):
        curr = self.get_value()
        new_val = np.clip(curr - self.resolution, self.from_val, self.to_val)
        self.set_value(new_val)
        if self.callback:
            self.callback()


# =============================================================================
# ULTIMATE WATERSHED WORKSTATION (GUI - same overall architecture, updated
# tabs/viewports for the dual-polarity pipeline)
# =============================================================================
class UltimateWatershedWorkstation(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Additive Manufacturing Powder Bed Inspection Workstation (Dual-Polarity Topological Engine)")
        self.geometry("1650x980")
        self.image_path = None
        self.folder_path = None
        self.max_display_dim = 400
        self.updating_ui = False
        self.params = {}

        self.setup_ui_architecture()

    def setup_ui_architecture(self):
        top_bar = ctk.CTkFrame(self, height=60, corner_radius=0)
        top_bar.pack(side=tk.TOP, fill=tk.X)

        load_btn = ctk.CTkButton(top_bar, text="📂 Load Single Image", command=self.load_image_action,
                                 font=('Helvetica', 12, 'bold'), fg_color="#0288d1", hover_color="#01579b")
        load_btn.pack(side=tk.LEFT, padx=15, pady=10)

        load_folder_btn = ctk.CTkButton(top_bar, text="📁 Load Batch Folder", command=self.load_folder_action,
                                        font=('Helvetica', 12, 'bold'), fg_color="#ff8f00", hover_color="#c67100")
        load_folder_btn.pack(side=tk.LEFT, padx=10, pady=10)

        self.path_lbl = ctk.CTkLabel(top_bar, text="No source files loaded.", font=('Helvetica', 12, 'italic'), text_color="#90a4ae")
        self.path_lbl.pack(side=tk.LEFT, padx=15)

        # 6-Column High-Speed Layout Viewport Frame
        self.viewport_frame = ctk.CTkFrame(self, corner_radius=10, fg_color="#1e1e1e")
        self.viewport_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=15, pady=10)

        for i in range(6):
            self.viewport_frame.columnconfigure(i, weight=1, uniform="viewport")
        self.viewport_frame.rowconfigure(1, weight=1)

        titles = [
            "1. Raw Input View",
            "2. Gaussian Division (Illum. Corrected)",
            "3. Clean Binary Mask (Bright+Dark)",
            "4. Bright Defects (Red)",
            "5. Dark Defects (Orange)",
            "6. Unified Output"
        ]
        for i, t in enumerate(titles):
            lbl = ctk.CTkLabel(self.viewport_frame, text=t, font=('Helvetica', 11, 'bold'), text_color="white")
            lbl.grid(row=0, column=i, pady=(10, 5), sticky="ew")

        self.lbl_view1 = ctk.CTkLabel(self.viewport_frame, text="Awaiting Data...", text_color="#616161")
        self.lbl_view1.grid(row=1, column=0, padx=3, pady=5, sticky="nsew")
        self.lbl_view2 = ctk.CTkLabel(self.viewport_frame, text="Awaiting Data...", text_color="#616161")
        self.lbl_view2.grid(row=1, column=1, padx=3, pady=5, sticky="nsew")
        self.lbl_view3 = ctk.CTkLabel(self.viewport_frame, text="Awaiting Data...", text_color="#616161")
        self.lbl_view3.grid(row=1, column=2, padx=3, pady=5, sticky="nsew")
        self.lbl_view4 = ctk.CTkLabel(self.viewport_frame, text="Awaiting Data...", text_color="#616161")
        self.lbl_view4.grid(row=1, column=3, padx=3, pady=5, sticky="nsew")
        self.lbl_view5 = ctk.CTkLabel(self.viewport_frame, text="Awaiting Data...", text_color="#616161")
        self.lbl_view5.grid(row=1, column=4, padx=3, pady=5, sticky="nsew")
        self.lbl_view6 = ctk.CTkLabel(self.viewport_frame, text="Awaiting Data...", text_color="#616161")
        self.lbl_view6.grid(row=1, column=5, padx=3, pady=5, sticky="nsew")

        # Control Panel Options Panel
        control_panel = ctk.CTkFrame(self, height=380)
        control_panel.pack(side=tk.BOTTOM, fill=tk.X, padx=15, pady=15)

        self.tabview = ctk.CTkTabview(control_panel, height=355)
        self.tabview.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=5)

        self.tab_prep = self.tabview.add(" Tab 1 — Illumination & Conditioning ")
        self.tab_dome = self.tabview.add(" Tab 2 — Dual Dome Extraction ")
        self.tab_ws = self.tabview.add(" Tab 3 — Watershed Optimization ")
        self.tab_filter = self.tabview.add(" Tab 4 — Defect Filtering ")

        self.build_tabs_layout()

        right_bar = ctk.CTkFrame(control_panel, width=240, fg_color="transparent")
        right_bar.pack(side=tk.RIGHT, fill=tk.Y, padx=10, pady=10)

        self.export_btn = ctk.CTkButton(right_bar, text="💾 Export Output\n(Single or Batch Folder)", command=self.start_async_export,
                                   font=('Helvetica', 12, 'bold'), fg_color="#2e7d32", hover_color="#1b5e20")
        self.export_btn.pack(fill=tk.BOTH, expand=True, pady=10)

    def create_parameter_row(self, parent, key, label_text, from_val, to_val, current_val, row_idx, is_float=False, resolution=1):
        lbl = ctk.CTkLabel(parent, text=label_text, font=('Helvetica', 11), anchor='w')
        lbl.grid(row=row_idx, column=0, sticky='w', pady=3, padx=10)

        var = tk.DoubleVar(value=current_val) if is_float else tk.IntVar(value=current_val)
        self.params[key] = var

        slider = ctk.CTkSlider(parent, from_=from_val, to=to_val, number_of_steps=int((to_val-from_val)/resolution), variable=var)
        slider.grid(row=row_idx, column=1, sticky='ew', padx=20, pady=3)

        spinbox = CTkSpinbox(parent, from_val, to_val, current_val, is_float, resolution, linked_var=var, on_update_callback=self.trigger_pipeline_refresh)
        spinbox.grid(row=row_idx, column=2, padx=10, pady=3)

        slider.bind("<ButtonRelease-1>", lambda event: self.sync_slider_to_spinbox(var, spinbox))
        spinbox.entry.bind("<Return>", lambda event: self.sync_spinbox_to_slider(spinbox, var, from_val, to_val))

        parent.columnconfigure(1, weight=1)
        return var, spinbox

    def sync_slider_to_spinbox(self, var, spinbox):
        if self.updating_ui:
            return
        self.updating_ui = True
        spinbox.set_value(var.get())
        self.updating_ui = False
        self.trigger_pipeline_refresh()

    def sync_spinbox_to_slider(self, spinbox, var, from_val, to_val):
        if self.updating_ui:
            return
        self.updating_ui = True
        val = spinbox.get_value()
        if from_val <= val <= to_val:
            var.set(val)
            self.updating_ui = False
            self.trigger_pipeline_refresh()
            return
        else:
            messagebox.showwarning("Out of Bounds", f"Value must be between {from_val} and {to_val}")
        self.updating_ui = False

    def build_tabs_layout(self):
        # Tab 1 — Illumination Correction & Grain-Texture Conditioning
        self.create_parameter_row(self.tab_prep, "illum_kernel", "Gaussian Division Background Kernel (px @900px ref):", 21, 301, 121, 0, resolution=2)
        self.create_parameter_row(self.tab_prep, "presmooth_k", "Grain-Texture Suppression Kernel (px @900px ref):", 3, 81, 31, 1, resolution=2)
        self.create_parameter_row(self.tab_prep, "bilat_d", "Bilateral Filter Diameter:", 1, 25, 9, 2, resolution=1)
        self.create_parameter_row(self.tab_prep, "bilat_sc", "Bilateral Sigma Color:", 5.0, 100.0, 20.0, 3, is_float=True, resolution=5.0)
        self.create_parameter_row(self.tab_prep, "bilat_ss", "Bilateral Sigma Space:", 5.0, 100.0, 9.0, 4, is_float=True, resolution=5.0)
        self.create_parameter_row(self.tab_prep, "cleanup_open_k", "Binary Cleanup — Morphological Opening Size:", 0, 15, 3, 5, resolution=1)
        self.create_parameter_row(self.tab_prep, "prelim_min_area", "Binary Cleanup — Min Component Area (px @900px ref):", 0, 2000, 60, 6, resolution=10)

        # Tab 2 — Dual Dome Extraction & Marker Generation
        self.create_parameter_row(self.tab_dome, "search_depth", "H-Dome / H-Minima Search Depth:", 1.0, 60.0, 15.0, 0, is_float=True, resolution=1.0)
        self.create_parameter_row(self.tab_dome, "bright_dome_thresh", "Bright Dome Binarization Threshold:", 0.0, 40.0, 9.0, 1, is_float=True, resolution=0.5)
        self.create_parameter_row(self.tab_dome, "dark_dome_thresh", "Dark Dome (Valley) Binarization Threshold:", 0.0, 40.0, 9.0, 2, is_float=True, resolution=0.5)
        self.create_parameter_row(self.tab_dome, "dt_type", "Distance Transform Type (0:L1, 1:L2, 2:C):", 0, 2, 1, 3, resolution=1)
        self.create_parameter_row(self.tab_dome, "dt_mask", "Distance Mask Size (3 or 5):", 3, 5, 5, 4, resolution=2)
        self.create_parameter_row(self.tab_dome, "local_max_min_dist", "Local Maxima Minimum Distance (px @900px ref):", 1, 50, 8, 5, resolution=1)
        self.create_parameter_row(self.tab_dome, "marker_refine_radius", "Marker Refinement Radius:", 0, 10, 1, 6, resolution=1)

        # Tab 3 — Watershed Optimization
        self.create_parameter_row(self.tab_ws, "compactness", "Compactness Regularization Factor:", 0.0, 10.0, 0.0, 0, is_float=True, resolution=0.1)
        self.create_parameter_row(self.tab_ws, "connectivity", "Connectivity Neighborhood Radius:", 1, 8, 1, 1, resolution=1)
        self.create_parameter_row(self.tab_ws, "ridge_enhancement", "Ridge Enhancement Strength Scalar:", 1.0, 5.0, 1.0, 2, is_float=True, resolution=0.2)
        self.create_parameter_row(self.tab_ws, "flooding_smoothness", "Flooding Topology Smoothness Kernel (px @900px ref):", 0, 15, 0, 3, resolution=1)

        # Tab 4 — Defect Filtering (shared by both polarities)
        self.create_parameter_row(self.tab_filter, "min_area", "Minimum Area Limit (Pixels):", 10, 20000, 60, 0, resolution=10)
        self.create_parameter_row(self.tab_filter, "max_area", "Maximum Area Limit (Pixels):", 100, 50000, 8000, 1, resolution=100)
        self.create_parameter_row(self.tab_filter, "min_circularity", "Minimum Circularity Metric:", 0.0, 1.0, 0.0, 2, is_float=True, resolution=0.05)
        self.create_parameter_row(self.tab_filter, "min_solidity", "Minimum Solidity Density:", 0.0, 1.0, 0.0, 3, is_float=True, resolution=0.05)
        self.create_parameter_row(self.tab_filter, "max_aspect_ratio", "Maximum Aspect Ratio Bound:", 1.0, 20.0, 10.0, 4, is_float=True, resolution=0.5)
        self.create_parameter_row(self.tab_filter, "min_convexity", "Minimum Boundary Convexity:", 0.0, 1.0, 0.0, 5, is_float=True, resolution=0.05)

    def load_image_action(self):
        file_path = filedialog.askopenfilename(filetypes=[("All Image Formats", "*.jpg *.jpeg *.png *.bmp *.tiff *.pgm")])
        if file_path:
            self.folder_path = None
            self.image_path = file_path
            self.path_lbl.configure(text=os.path.basename(file_path))
            self.trigger_pipeline_refresh()

    def load_folder_action(self):
        folder_path = filedialog.askdirectory(title="Select Batch Folder of AM Images")
        if folder_path:
            self.image_path = None
            self.folder_path = folder_path
            files = [f for f in os.listdir(folder_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp'))]
            self.path_lbl.configure(text=f"Batch Folder: {os.path.basename(folder_path)} ({len(files)} target images)")

            if len(files) > 0:
                self.image_path = os.path.join(folder_path, files[0])
                self.trigger_pipeline_refresh()

    def get_current_params_dict(self):
        return {k: v.get() for k, v in self.params.items()}

    def trigger_pipeline_refresh(self):
        if not self.image_path or self.updating_ui:
            return

        p_dict = self.get_current_params_dict()
        disp_img, mask, illum_disp, white_disp, dark_disp, final_disp = process_powder_bed_pipeline(
            self.image_path, self.max_display_dim, p_dict
        )

        if disp_img is not None:
            self.update_native_viewports(disp_img, mask, illum_disp, white_disp, dark_disp, final_disp)

    def convert_to_ctk_image(self, cv_img, is_gray=False, use_cmap=False):
        if use_cmap:
            norm_topo = cv2.normalize(cv_img, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
            color_mapped = cv2.applyColorMap(norm_topo, cv2.COLORMAP_VIRIDIS)
            rgb = cv2.cvtColor(color_mapped, cv2.COLOR_BGR2RGB)
        elif is_gray:
            rgb = cv2.cvtColor(cv_img, cv2.COLOR_GRAY2RGB)
        else:
            rgb = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)

        h, w = rgb.shape[:2]
        pil_img = Image.fromarray(rgb)
        return ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(w, h))

    def update_native_viewports(self, disp_img, mask, illum_disp, white_disp, dark_disp, final_disp):
        ctk_img1 = self.convert_to_ctk_image(disp_img, is_gray=False)
        ctk_img2 = self.convert_to_ctk_image(illum_disp, is_gray=True)
        ctk_img3 = self.convert_to_ctk_image(mask, is_gray=True)
        ctk_img4 = self.convert_to_ctk_image(white_disp, is_gray=False)
        ctk_img5 = self.convert_to_ctk_image(dark_disp, is_gray=False)
        ctk_img6 = self.convert_to_ctk_image(final_disp, is_gray=False)

        self.lbl_view1.configure(image=ctk_img1, text="")
        self.lbl_view1.image = ctk_img1
        self.lbl_view2.configure(image=ctk_img2, text="")
        self.lbl_view2.image = ctk_img2
        self.lbl_view3.configure(image=ctk_img3, text="")
        self.lbl_view3.image = ctk_img3
        self.lbl_view4.configure(image=ctk_img4, text="")
        self.lbl_view4.image = ctk_img4
        self.lbl_view5.configure(image=ctk_img5, text="")
        self.lbl_view5.image = ctk_img5
        self.lbl_view6.configure(image=ctk_img6, text="")
        self.lbl_view6.image = ctk_img6

    def start_async_export(self):
        if not self.image_path and not self.folder_path:
            messagebox.showwarning("Export Error", "Please load a single image or batch folder first.")
            return

        selected_parent_dir = filedialog.askdirectory(title="Select Destination Folder")
        if not selected_parent_dir:
            return

        self.export_btn.configure(state="disabled", text="⏳ Running High-Res Batch Pool...")

        export_thread = threading.Thread(target=self.background_export_worker, args=(selected_parent_dir,))
        export_thread.daemon = True
        export_thread.start()

    def background_export_worker(self, target_base_path):
        try:
            p_dict = self.get_current_params_dict()

            if self.folder_path:
                output_dir = os.path.join(target_base_path, "Output_Images_Watershed")
                os.makedirs(output_dir, exist_ok=True)
                files_to_process = [
                    os.path.join(self.folder_path, f)
                    for f in os.listdir(self.folder_path)
                    if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp'))
                ]
            else:
                base_filename = os.path.splitext(os.path.basename(self.image_path))[0]
                output_dir = os.path.join(target_base_path, f"watershed_{base_filename}_outputs")
                os.makedirs(output_dir, exist_ok=True)
                files_to_process = [self.image_path]

            def process_single_file(file_path):
                file_name_only = os.path.splitext(os.path.basename(file_path))[0]

                if self.folder_path:
                    # Batch mode: keep exports lightweight (just the final overlay).
                    _, _, _, _, _, full_final = process_powder_bed_pipeline(
                        file_path, None, p_dict
                    )
                    if full_final is None:
                        return
                    output_file_name = f"{file_name_only}_segmented.png"
                    cv2.imwrite(os.path.join(output_dir, output_file_name), cv2.cvtColor(full_final, cv2.COLOR_RGB2BGR))
                else:
                    # Single-image mode: export every intermediate stage
                    # requested in the design brief (Task #9), at full
                    # resolution, for detailed offline review.
                    result = process_powder_bed_pipeline(file_path, None, p_dict, full_stage_output=True)
                    if result[0] is None:
                        return
                    (_, full_mask, illum_disp, full_white, full_dark, full_final, stages) = result

                    cv2.imwrite(os.path.join(output_dir, "export_01_input.png"), cv2.imread(file_path))
                    cv2.imwrite(os.path.join(output_dir, "export_02_gaussian_division.png"), illum_disp)
                    cv2.imwrite(os.path.join(output_dir, "export_03_background_estimate.png"), stages["background_estimate"])
                    cv2.imwrite(os.path.join(output_dir, "export_04_conditioned_denoised.png"), stages["conditioned"])
                    cv2.imwrite(os.path.join(output_dir, "export_05_bright_dome.png"), stages["bright_dome"])
                    cv2.imwrite(os.path.join(output_dir, "export_06_dark_dome.png"), stages["dark_dome"])
                    cv2.imwrite(os.path.join(output_dir, "export_07_gradient.png"), stages["gradient"])
                    cv2.imwrite(os.path.join(output_dir, "export_08_binary_bright.png"), stages["binary_bright"])
                    cv2.imwrite(os.path.join(output_dir, "export_09_binary_dark.png"), stages["binary_dark"])
                    cv2.imwrite(os.path.join(output_dir, "export_10_dist_transform_bright.png"), stages["dist_bright"])
                    cv2.imwrite(os.path.join(output_dir, "export_11_dist_transform_dark.png"), stages["dist_dark"])
                    cv2.imwrite(os.path.join(output_dir, "export_12_markers_bright.png"), stages["markers_bright"])
                    cv2.imwrite(os.path.join(output_dir, "export_13_markers_dark.png"), stages["markers_dark"])
                    cv2.imwrite(os.path.join(output_dir, "export_14_binary_mask_combined.png"), full_mask)
                    cv2.imwrite(os.path.join(output_dir, "export_15_bright_defects_overlay.png"), cv2.cvtColor(full_white, cv2.COLOR_RGB2BGR))
                    cv2.imwrite(os.path.join(output_dir, "export_16_dark_defects_overlay.png"), cv2.cvtColor(full_dark, cv2.COLOR_RGB2BGR))
                    cv2.imwrite(os.path.join(output_dir, "export_17_final_unified_overlay.png"), cv2.cvtColor(full_final, cv2.COLOR_RGB2BGR))

                    with open(os.path.join(output_dir, "parameters.json"), "w") as f:
                        json.dump({"configured_parameters": p_dict, "engine": "dual_polarity_gaussian_division_topological"}, f, indent=4)

            with ThreadPoolExecutor() as executor:
                list(executor.map(process_single_file, files_to_process))

            self.after(0, lambda: self.on_export_complete(output_dir))

        except Exception as e:
            self.after(0, lambda: self.on_export_failed(str(e)))

    def on_export_complete(self, output_dir):
        self.export_btn.configure(state="normal", text="💾 Export Output\n(Single or Batch Folder)")
        messagebox.showinfo("Export Successful", f"Operations completed successfully!\nTarget Directory:\n{output_dir}")

    def on_export_failed(self, error_msg):
        self.export_btn.configure(state="normal", text="💾 Export Output\n(Single or Batch Folder)")
        messagebox.showerror("Export Error", f"An execution error occurred:\n{error_msg}")


if __name__ == "__main__":
    app = UltimateWatershedWorkstation()
    app.mainloop()
