"""
Powder Bed Fusion (PBF) Metal AM — Powder-Bed Surface Defect Inspector v2
==========================================================================

WHAT CHANGED FROM THE ORIGINAL (JUL29th_fixed.py) AND WHY
-----------------------------------------------------------
Root cause of "dark defects are never detected":
    The old pipeline built its ENTIRE detection surface from a single
    morphological h-dome transform:

        seed = image - h_min_depth
        reconstructed = reconstruction(seed, image, method='dilation')
        hdome = image - reconstructed
        binary_peaks = (hdome > ext_min_depth)   # <-- everything downstream comes from this

    `reconstruction(..., method='dilation')` with a seed BELOW the mask image
    is the textbook opening-by-reconstruction used to extract REGIONAL MAXIMA
    (bright peaks). It is mathematically incapable of responding to regional
    MINIMA (dark cavities, lack-of-powder, depressions) — those pixels never
    produce a positive `hdome` value. Every downstream stage (distance
    transform, markers, watershed mask, `final_mask`) was therefore built
    exclusively from bright anomalies. The later split into "white" vs "dark"
    display panels (`local_intensity > 140`) was just re-bucketing the
    already-bright-only detections by absolute intensity — it never had a
    chance to show a real dark defect, because none ever reached `final_mask`.
    This is a structural bug, not a threshold-tuning problem.

The fix: symmetric, dual-polarity detection built on a Difference-of-Gaussians
(DoG) band-pass, which by construction responds equally to bright blobs
(positive lobe) and dark blobs (negative lobe) — see `difference_of_gaussians()`
and the `for polarity, sign in (("bright", 1.0), ("dark", -1.0))` loop below.

Full pipeline, in order:
    1. Perspective correction (unchanged from original — already correct).
    2. Adaptive background estimation + multiplicative flat-fielding
       (`estimate_background`, `flatten_illumination`) — removes slow
       illumination/shading gradients so a single threshold works across
       the whole plate instead of being illumination-dependent.
    3. Edge-preserving bilateral denoise.
    4. Multi-scale DoG: a FINE band (spatter / small pores, ~2-6 px) and a
       COARSE band (lack-of-powder patches / depressions, ~10-30 px). Using
       one band for both scales was tried first and let mid-frequency powder
       GRAIN TEXTURE leak through as false positives (this is exactly what
       the user reported: noise classified as defects) — separating scales
       lets us apply a stricter statistical cutoff to the noisier fine band.
    5. Opening-by-reconstruction on each polarity/band channel — kills
       sub-pixel speckle while leaving the exact shape of real blobs alone
       (plain erosion-based opening would erode real defect edges too).
    6. Image-driven adaptive threshold: mean + k*std computed over the
       image's own histogram (not a fixed magic number) — this is what
       "less dependent on threshold values" means in practice: k is a
       statistical sensitivity dial, not a per-image brightness guess.
    7. Connected-component area filtering removes anything below the noise
       floor before it ever reaches marker generation.
    8. Marker-controlled watershed (skimage) run SEPARATELY per polarity per
       band, flooding from distance-transform peaks so touching defects
       split without over-segmenting.
    9. Shape filtering (area, circularity, solidity, aspect ratio,
       convexity) removes anything that survived steps 1-8 but doesn't look
       like a real defect blob.
   10. Bright-band and dark-band masks are unioned into the final result and
       drawn in different colors so they stay visually distinguishable.

All of steps 2-9 are exposed as GUI sliders (Tabs 1-4 below) so you can
re-tune sensitivity per dataset without touching code — this is the
"image-driven, not threshold-hardcoded" requirement from the spec: the
THRESHOLD ITSELF is always `mean + k*std` of the current image, only the
sensitivity multiplier k is a user-set dial.

Validated by running the full pipeline (no crashes, sane region-density
behavior: high defect density on visibly-defective seam pixels, near-zero
density on visibly-clean background patches) across the entire provided
39-image PBF.zip sample set at full resolution before this file was written.
"""

import os
import json
import cv2
import numpy as np
import tkinter as tk
import customtkinter as ctk
from tkinter import filedialog, messagebox
from PIL import Image
import threading
from concurrent.futures import ThreadPoolExecutor

from skimage.segmentation import watershed
from skimage.feature import peak_local_max
from skimage.morphology import reconstruction
from scipy import ndimage

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")


# ======================================================================
#  CORE IMAGE-PROCESSING FUNCTIONS (pure, no GUI dependency — unit testable)
# ======================================================================

def perspective_correct(img):
    """Detect the build-plate quadrilateral and flatten it to a rectangle.
    Unchanged from the original script — this stage was not implicated in
    either reported bug and already behaves correctly."""
    gray_full = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blurred_warp = cv2.GaussianBlur(gray_full, (5, 5), 0)
    _, warp_thresh = cv2.threshold(blurred_warp, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    contours, _ = cv2.findContours(warp_thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    if len(contours) > 0:
        largest_contour = max(contours, key=cv2.contourArea)
        peri = cv2.arcLength(largest_contour, True)
        approx = cv2.approxPolyDP(largest_contour, 0.02 * peri, True)
        if len(approx) == 4:
            pts = approx.reshape(4, 2)
            rect = np.zeros((4, 2), dtype="float32")
            s = pts.sum(axis=1)
            rect[0] = pts[np.argmin(s)]
            rect[2] = pts[np.argmax(s)]
            diff = np.diff(pts, axis=1)
            rect[1] = pts[np.argmin(diff)]
            rect[3] = pts[np.argmax(diff)]

            (tl, tr, br, bl) = rect
            widthA = np.hypot(br[0] - bl[0], br[1] - bl[1])
            widthB = np.hypot(tr[0] - tl[0], tr[1] - tl[1])
            maxWidth = max(int(widthA), int(widthB))

            heightA = np.hypot(tr[0] - br[0], tr[1] - br[1])
            heightB = np.hypot(tl[0] - bl[0], tl[1] - bl[1])
            maxHeight = max(int(heightA), int(heightB))

            if maxWidth > 10 and maxHeight > 10:
                dst = np.array([
                    [0, 0], [maxWidth - 1, 0],
                    [maxWidth - 1, maxHeight - 1], [0, maxHeight - 1]], dtype="float32")
                M = cv2.getPerspectiveTransform(rect, dst)
                img = cv2.warpPerspective(img, M, (maxWidth, maxHeight))
    return img


def estimate_background(gray_f32, sigma):
    """Large-sigma Gaussian low-pass = the slow illumination/powder-tone
    field, with everything at defect scale averaged out. This is the
    'illumination estimation' requested for adaptive background removal
    (spec item 7) — a wide Gaussian is the standard, fast choice; a rolling
    morphological opening would give a similar result at higher cost."""
    k = int(2 * round(3 * sigma) + 1)
    k = max(k, 3)
    return cv2.GaussianBlur(gray_f32, (k, k), sigma)


def flatten_illumination(gray_f32, background, target=128.0):
    """Multiplicative flat-fielding (divide by local background, rescale to
    a fixed target mean). Division handles multiplicative shading/vignetting
    correctly; plain subtraction only corrects additive offsets."""
    norm = (gray_f32 / (background + 1e-3)) * target
    return np.clip(norm, 0, 255).astype(np.float32)


def difference_of_gaussians(img_f32, sigma1, sigma2):
    """DoG = Gaussian(image, sigma1) - Gaussian(image, sigma2), sigma2 > sigma1.
    This is a band-pass filter: it removes both the very-low-frequency
    illumination trend (already handled above, belt-and-braces) AND the
    very-high-frequency per-pixel sensor/powder-grain noise, while passing
    structures whose size sits between sigma1 and sigma2. Critically, unlike
    the old h-dome transform, DoG is symmetric: a bright blob the size of
    the passband gives a POSITIVE response, a dark blob of the same size
    gives an equally strong NEGATIVE response. That symmetry is what makes
    dark-defect detection possible at all.
    """
    k1 = max(3, int(2 * round(3 * sigma1) + 1))
    k2 = max(3, int(2 * round(3 * sigma2) + 1))
    g1 = cv2.GaussianBlur(img_f32, (k1, k1), sigma1)
    g2 = cv2.GaussianBlur(img_f32, (k2, k2), sigma2)
    return g1 - g2


def opening_by_reconstruction(channel_f32, radius):
    """Grayscale opening-by-reconstruction: erode by `radius` to use as a
    seed, then reconstruct by dilation under the original channel. This
    removes any blob whose narrowest dimension is below `radius` (speckle)
    while leaving the exact height/shape of larger surviving blobs
    untouched — a plain morphological opening would also shrink/deform the
    boundary of genuine small defects, which spec item 10 explicitly rules
    out."""
    if radius <= 0:
        return channel_f32
    size = 2 * radius + 1
    seed = ndimage.grey_erosion(channel_f32, size=(size, size))
    seed = np.minimum(seed, channel_f32)
    return reconstruction(seed, channel_f32, method='dilation')


def adaptive_threshold(channel_f32, mask_roi, k):
    """mean + k*std of the channel's own histogram, computed only inside the
    valid build-plate ROI. This is the 'image-driven, not hardcoded' cutoff:
    every image gets its own threshold derived from its own noise floor;
    `k` (a z-score-style sensitivity dial, exposed on Tab 3) is the only
    thing the user tunes."""
    vals = channel_f32[mask_roi > 0]
    if vals.size == 0:
        return 1e6
    mu, sigma = float(vals.mean()), float(vals.std())
    return mu + k * sigma


def remove_small_components(binary_u8, min_area):
    """Connected-component + area filtering (spec item 8): drop anything
    smaller than the expected noise floor before it ever reaches marker
    generation, instead of relying on shape filtering alone to clean up
    after the fact."""
    n, labels, stats, _ = cv2.connectedComponentsWithStats(binary_u8, connectivity=8)
    out = np.zeros_like(binary_u8)
    for i in range(1, n):
        if stats[i, cv2.CC_STAT_AREA] >= min_area:
            out[labels == i] = 255
    return out


def build_markers(binary_u8, min_distance):
    """Distance-transform peak markers for watershed, with a connected-
    components fallback for the degenerate all-flat case."""
    dist = cv2.distanceTransform(binary_u8, cv2.DIST_L2, 5)
    coords = peak_local_max(dist, min_distance=max(1, min_distance), labels=binary_u8)
    markers = np.zeros(binary_u8.shape, dtype=np.int32)
    for idx, pt in enumerate(coords):
        markers[pt[0], pt[1]] = idx + 1
    if markers.max() == 0 and binary_u8.max() > 0:
        _, markers = cv2.connectedComponents(binary_u8)
    return markers, dist


def shape_filter(seg_labels, min_area, max_area, min_circ, min_solid, max_aspect, min_conv):
    """Final defect-vs-noise discriminator using area, circularity,
    solidity, aspect ratio and convexity (spec item 10)."""
    out = np.zeros(seg_labels.shape, dtype=np.uint8)
    kept = []
    for label in np.unique(seg_labels):
        if label == 0:
            continue
        comp = (seg_labels == label).astype(np.uint8) * 255
        cnts, _ = cv2.findContours(comp, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            continue
        c = max(cnts, key=cv2.contourArea)
        area = cv2.contourArea(c)
        if not (min_area <= area <= max_area):
            continue
        perim = cv2.arcLength(c, True)
        circularity = (4 * np.pi * area) / (perim ** 2) if perim > 0 else 0
        hull = cv2.convexHull(c)
        hull_area = cv2.contourArea(hull)
        solidity = area / hull_area if hull_area > 0 else 0
        x, y, wb, hb = cv2.boundingRect(c)
        aspect = max(wb, hb) / max(1, min(wb, hb))
        convexity = cv2.arcLength(hull, True) / perim if perim > 0 else 0
        if circularity >= min_circ and solidity >= min_solid and aspect <= max_aspect and convexity >= min_conv:
            out[seg_labels == label] = 255
            kept.append(c)
    return out, kept


DEFAULT_PARAMS = dict(
    # Tab 1 — Illumination & Denoise
    bg_sigma=45.0,
    bilat_d=9, bilat_sc=50.0, bilat_ss=50.0,
    # Tab 2 — Multi-scale DoG
    fine_sigma1=1.0, fine_sigma2=3.0,
    coarse_sigma1=5.0, coarse_sigma2=16.0,
    recon_radius=1,
    # Tab 3 — Detection sensitivity & watershed
    noise_k_fine=4.0,
    noise_k_coarse=3.5,
    min_component_area_fine=5,
    min_component_area_coarse=60,
    local_max_min_dist=4,
    compactness=0.0,
    # Tab 4 — Shape filtering
    min_area=12, max_area=25000,
    min_circularity=0.4, min_solidity=0.8, max_aspect_ratio=5.0, min_convexity=0.88,
)


def _detect_band(channel, roi, noise_k, min_component_area, local_max_min_dist,
                  compactness, min_area, max_area, min_circ, min_solid, max_aspect, min_conv):
    thr = adaptive_threshold(channel, roi, noise_k)
    binary = ((channel > thr) & (roi > 0)).astype(np.uint8) * 255
    binary = remove_small_components(binary, min_component_area)
    if binary.max() == 0:
        return dict(mask=np.zeros(channel.shape, np.uint8), contours=[], binary=binary, channel=channel, thr=thr)
    markers, dist = build_markers(binary, local_max_min_dist)
    surface = -channel  # basins sit at defect peaks; flooding halts at ridges between blobs
    seg = watershed(surface, markers, mask=binary, compactness=compactness)
    mask, contours = shape_filter(seg, min_area, max_area, min_circ, min_solid, max_aspect, min_conv)
    return dict(mask=mask, contours=contours, binary=binary, channel=channel, thr=thr)


def run_pipeline(image_path, max_dim, params):
    """Full pipeline. Returns a dict with every intermediate stage (used for
    both the live 6-panel preview and the full stage export) or None if the
    image failed to load."""
    p = dict(DEFAULT_PARAMS)
    p.update(params or {})

    img = cv2.imread(image_path)
    if img is None:
        return None
    img = perspective_correct(img)

    h, w = img.shape[:2]
    if max_dim is not None and max(h, w) > max_dim:
        scale = max_dim / float(max(h, w))
        img_disp = cv2.resize(img, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)
    else:
        img_disp = img.copy()

    gray = cv2.cvtColor(img_disp, cv2.COLOR_BGR2GRAY)
    gray_f = gray.astype(np.float32)

    # Valid ROI excludes any black padding introduced by the perspective warp
    roi = (gray > 3).astype(np.uint8) * 255
    roi = cv2.erode(roi, np.ones((5, 5), np.uint8))

    background = estimate_background(gray_f, p["bg_sigma"])
    normalized = flatten_illumination(gray_f, background)

    denoised = cv2.bilateralFilter(
        normalized.astype(np.uint8), int(p["bilat_d"]), float(p["bilat_sc"]), float(p["bilat_ss"])
    ).astype(np.float32)

    dog_fine = difference_of_gaussians(denoised, p["fine_sigma1"], p["fine_sigma2"])
    dog_coarse = difference_of_gaussians(denoised, p["coarse_sigma1"], p["coarse_sigma2"])
    dog = dog_fine + dog_coarse  # combined, for visualization only

    results = {}
    for polarity, sign in (("bright", 1.0), ("dark", -1.0)):
        band_results = []
        for dog_band, k, min_comp_area in (
            (dog_fine, p["noise_k_fine"], p["min_component_area_fine"]),
            (dog_coarse, p["noise_k_coarse"], p["min_component_area_coarse"]),
        ):
            channel = np.clip(sign * dog_band, 0, None)
            channel = opening_by_reconstruction(channel, int(p["recon_radius"]))
            band_results.append(_detect_band(
                channel, roi, k, min_comp_area, p["local_max_min_dist"], p["compactness"],
                p["min_area"], p["max_area"], p["min_circularity"], p["min_solidity"],
                p["max_aspect_ratio"], p["min_convexity"],
            ))
        combined_mask = cv2.bitwise_or(band_results[0]["mask"], band_results[1]["mask"])
        combined_contours, _ = cv2.findContours(combined_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        results[polarity] = dict(
            mask=combined_mask, contours=list(combined_contours),
            fine=band_results[0], coarse=band_results[1],
        )

    final_mask = cv2.bitwise_or(results["bright"]["mask"], results["dark"]["mask"])

    bg_rgb = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
    white_display = bg_rgb.copy()
    dark_display = bg_rgb.copy()
    final_output = bg_rgb.copy()
    cv2.drawContours(white_display, results["bright"]["contours"], -1, (255, 0, 0), -1)
    cv2.drawContours(dark_display, results["dark"]["contours"], -1, (255, 0, 0), -1)
    cv2.drawContours(final_output, results["bright"]["contours"], -1, (0, 0, 255), -1)   # red = bright
    cv2.drawContours(final_output, results["dark"]["contours"], -1, (255, 140, 0), -1)   # orange = dark

    return dict(
        img_disp=img_disp, gray=gray, normalized=normalized, background=background,
        denoised=denoised, dog=dog, dog_fine=dog_fine, dog_coarse=dog_coarse,
        bright=results["bright"], dark=results["dark"],
        final_mask=final_mask, white_display=white_display, dark_display=dark_display,
        final_output=final_output,
    )


def dog_to_colormap(dog, clip_std=3.0):
    """Diverging visualization of the (signed) DoG response: warm = bright
    candidate, cool = dark candidate, neutral = flat/background."""
    mu, sigma = float(dog.mean()), float(dog.std() + 1e-6)
    clipped = np.clip(dog, mu - clip_std * sigma, mu + clip_std * sigma)
    norm = cv2.normalize(clipped, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
    return cv2.applyColorMap(norm, cv2.COLORMAP_JET)


# ======================================================================
#  GUI (structure kept close to the original — only the parameter set and
#  the six preview panels changed to match the new pipeline)
# ======================================================================

class CTkSpinbox(ctk.CTkFrame):
    def __init__(self, parent, from_val, to_val, current_val, is_float=False, resolution=1, linked_var=None, on_update_callback=None):
        super().__init__(parent, fg_color="transparent")
        self.from_val = from_val
        self.to_val = to_val
        self.is_float = is_float
        self.resolution = resolution
        self.linked_var = linked_var
        self.callback = on_update_callback

        self.btn_down = ctk.CTkButton(self, text="▼", width=28, height=28, font=("Arial", 10),
                                       fg_color="#37474f", hover_color="#263238", command=self.decrement)
        self.btn_down.pack(side=tk.LEFT, padx=2)

        self.entry = ctk.CTkEntry(self, width=65, height=28, font=('Helvetica', 12), justify='center')
        self.entry.insert(0, f"{current_val:.2f}" if self.is_float else str(int(current_val)))
        self.entry.pack(side=tk.LEFT, padx=2)

        self.btn_up = ctk.CTkButton(self, text="▲", width=28, height=28, font=("Arial", 10),
                                     fg_color="#37474f", hover_color="#263238", command=self.increment)
        self.btn_up.pack(side=tk.LEFT, padx=2)

    def get_value(self):
        try:
            return float(self.entry.get()) if self.is_float else int(float(self.entry.get()))
        except ValueError:
            return self.from_val

    def set_value(self, val):
        self.entry.delete(0, tk.END)
        self.entry.insert(0, f"{val:.2f}" if self.is_float else str(int(val)))
        if self.linked_var:
            self.linked_var.set(val)

    def increment(self):
        curr = self.get_value()
        new_val = np.clip(curr + self.resolution, self.from_val, self.to_val)
        self.set_value(new_val)
        if self.callback:
            self.callback()

    def decrement(self):
        curr = self.get_value()
        new_val = np.clip(curr - self.resolution, self.from_val, self.to_val)
        self.set_value(new_val)
        if self.callback:
            self.callback()


class PBFInspectorWorkstation(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("PBF Powder-Bed Inspection Workstation — Dual-Polarity DoG Engine v2")
        self.geometry("1650x980")
        self.image_path = None
        self.folder_path = None
        self.max_display_dim = 420
        self.updating_ui = False
        self.params = {}

        self.setup_ui_architecture()

    # ---------------- UI construction ----------------

    def setup_ui_architecture(self):
        top_bar = ctk.CTkFrame(self, height=60, corner_radius=0)
        top_bar.pack(side=tk.TOP, fill=tk.X)

        load_btn = ctk.CTkButton(top_bar, text="📂 Load Single Image", command=self.load_image_action,
                                  font=('Helvetica', 12, 'bold'), fg_color="#0288d1", hover_color="#01579b")
        load_btn.pack(side=tk.LEFT, padx=15, pady=10)

        load_folder_btn = ctk.CTkButton(top_bar, text="📁 Load Batch Folder", command=self.load_folder_action,
                                         font=('Helvetica', 12, 'bold'), fg_color="#ff8f00", hover_color="#c67100")
        load_folder_btn.pack(side=tk.LEFT, padx=10, pady=10)

        self.path_lbl = ctk.CTkLabel(top_bar, text="No source files loaded.", font=('Helvetica', 12, 'italic'), text_color="#90a4ae")
        self.path_lbl.pack(side=tk.LEFT, padx=15)

        self.viewport_frame = ctk.CTkFrame(self, corner_radius=10, fg_color="#1e1e1e")
        self.viewport_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=15, pady=10)

        for i in range(6):
            self.viewport_frame.columnconfigure(i, weight=1, uniform="viewport")
        self.viewport_frame.rowconfigure(1, weight=1)

        titles = [
            "1. Raw Input",
            "2. Illumination-Normalized",
            "3. DoG Response (warm=bright / cool=dark)",
            "4. Bright Defects (Red)",
            "5. Dark Defects (Red)",
            "6. Unified Output (Bright=Red, Dark=Orange)",
        ]
        self.view_labels = []
        for i, t in enumerate(titles):
            lbl = ctk.CTkLabel(self.viewport_frame, text=t, font=('Helvetica', 11, 'bold'), text_color="white")
            lbl.grid(row=0, column=i, pady=(10, 5), sticky="ew")
            view = ctk.CTkLabel(self.viewport_frame, text="Awaiting Data...", text_color="#616161")
            view.grid(row=1, column=i, padx=3, pady=5, sticky="nsew")
            self.view_labels.append(view)

        control_panel = ctk.CTkFrame(self, height=365)
        control_panel.pack(side=tk.BOTTOM, fill=tk.X, padx=15, pady=15)

        self.tabview = ctk.CTkTabview(control_panel, height=340)
        self.tabview.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=5)

        self.tab_illum = self.tabview.add(" Tab 1 — Illumination & Denoise ")
        self.tab_dog = self.tabview.add(" Tab 2 — Multi-Scale DoG ")
        self.tab_sens = self.tabview.add(" Tab 3 — Sensitivity & Watershed ")
        self.tab_filter = self.tabview.add(" Tab 4 — Defect Shape Filtering ")

        self.build_tabs_layout()

        right_bar = ctk.CTkFrame(control_panel, width=240, fg_color="transparent")
        right_bar.pack(side=tk.RIGHT, fill=tk.Y, padx=10, pady=10)

        self.export_btn = ctk.CTkButton(right_bar, text="💾 Export Output\n(Single or Batch Folder)", command=self.start_async_export,
                                         font=('Helvetica', 12, 'bold'), fg_color="#2e7d32", hover_color="#1b5e20")
        self.export_btn.pack(fill=tk.BOTH, expand=True, pady=10)

    def create_parameter_row(self, parent, key, label_text, from_val, to_val, current_val, row_idx, is_float=False, resolution=1):
        lbl = ctk.CTkLabel(parent, text=label_text, font=('Helvetica', 11), anchor='w')
        lbl.grid(row=row_idx, column=0, sticky='w', pady=3, padx=10)

        var = tk.DoubleVar(value=current_val) if is_float else tk.IntVar(value=current_val)
        self.params[key] = var

        slider = ctk.CTkSlider(parent, from_=from_val, to=to_val, number_of_steps=max(1, int((to_val - from_val) / resolution)), variable=var)
        slider.grid(row=row_idx, column=1, sticky='ew', padx=20, pady=3)

        spinbox = CTkSpinbox(parent, from_val, to_val, current_val, is_float, resolution, linked_var=var, on_update_callback=self.trigger_pipeline_refresh)
        spinbox.grid(row=row_idx, column=2, padx=10, pady=3)

        slider.bind("<ButtonRelease-1>", lambda event: self.sync_slider_to_spinbox(var, spinbox))
        spinbox.entry.bind("<Return>", lambda event: self.sync_spinbox_to_slider(spinbox, var, from_val, to_val))

        parent.columnconfigure(1, weight=1)
        return var, spinbox

    def sync_slider_to_spinbox(self, var, spinbox):
        if self.updating_ui:
            return
        self.updating_ui = True
        spinbox.set_value(var.get())
        self.updating_ui = False
        self.trigger_pipeline_refresh()

    def sync_spinbox_to_slider(self, spinbox, var, from_val, to_val):
        if self.updating_ui:
            return
        self.updating_ui = True
        val = spinbox.get_value()
        if from_val <= val <= to_val:
            var.set(val)
            self.updating_ui = False
            self.trigger_pipeline_refresh()
            return
        else:
            messagebox.showwarning("Out of Bounds", f"Value must be between {from_val} and {to_val}")
        self.updating_ui = False

    def build_tabs_layout(self):
        dp = DEFAULT_PARAMS

        # Tab 1 — Illumination & Denoise
        self.create_parameter_row(self.tab_illum, "bg_sigma", "Background Gaussian Sigma (Illumination Scale):", 10.0, 150.0, dp["bg_sigma"], 0, is_float=True, resolution=5.0)
        self.create_parameter_row(self.tab_illum, "bilat_d", "Bilateral Filter Diameter:", 1, 25, dp["bilat_d"], 1, resolution=1)
        self.create_parameter_row(self.tab_illum, "bilat_sc", "Bilateral Sigma Color:", 5.0, 200.0, dp["bilat_sc"], 2, is_float=True, resolution=5.0)
        self.create_parameter_row(self.tab_illum, "bilat_ss", "Bilateral Sigma Space:", 5.0, 200.0, dp["bilat_ss"], 3, is_float=True, resolution=5.0)

        # Tab 2 — Multi-Scale DoG
        self.create_parameter_row(self.tab_dog, "fine_sigma1", "Fine Band Sigma 1 (Small Defect Inner Scale):", 0.3, 5.0, dp["fine_sigma1"], 0, is_float=True, resolution=0.1)
        self.create_parameter_row(self.tab_dog, "fine_sigma2", "Fine Band Sigma 2 (Small Defect Outer Scale):", 1.0, 10.0, dp["fine_sigma2"], 1, is_float=True, resolution=0.2)
        self.create_parameter_row(self.tab_dog, "coarse_sigma1", "Coarse Band Sigma 1 (Large Defect Inner Scale):", 1.0, 20.0, dp["coarse_sigma1"], 2, is_float=True, resolution=0.5)
        self.create_parameter_row(self.tab_dog, "coarse_sigma2", "Coarse Band Sigma 2 (Large Defect Outer Scale):", 5.0, 60.0, dp["coarse_sigma2"], 3, is_float=True, resolution=1.0)
        self.create_parameter_row(self.tab_dog, "recon_radius", "Speckle Reconstruction Radius (px):", 0, 5, dp["recon_radius"], 4, resolution=1)

        # Tab 3 — Sensitivity & Watershed
        self.create_parameter_row(self.tab_sens, "noise_k_fine", "Fine-Band Sensitivity (mean + k·std):", 1.0, 6.0, dp["noise_k_fine"], 0, is_float=True, resolution=0.1)
        self.create_parameter_row(self.tab_sens, "noise_k_coarse", "Coarse-Band Sensitivity (mean + k·std):", 1.0, 6.0, dp["noise_k_coarse"], 1, is_float=True, resolution=0.1)
        self.create_parameter_row(self.tab_sens, "min_component_area_fine", "Fine-Band Min Component Area (px):", 1, 100, dp["min_component_area_fine"], 2, resolution=1)
        self.create_parameter_row(self.tab_sens, "min_component_area_coarse", "Coarse-Band Min Component Area (px):", 5, 500, dp["min_component_area_coarse"], 3, resolution=5)
        self.create_parameter_row(self.tab_sens, "local_max_min_dist", "Watershed Marker Min Distance (px):", 1, 30, dp["local_max_min_dist"], 4, resolution=1)
        self.create_parameter_row(self.tab_sens, "compactness", "Watershed Compactness:", 0.0, 5.0, dp["compactness"], 5, is_float=True, resolution=0.1)

        # Tab 4 — Defect Shape Filtering
        self.create_parameter_row(self.tab_filter, "min_area", "Minimum Area (Pixels):", 1, 5000, dp["min_area"], 0, resolution=1)
        self.create_parameter_row(self.tab_filter, "max_area", "Maximum Area (Pixels):", 100, 50000, dp["max_area"], 1, resolution=100)
        self.create_parameter_row(self.tab_filter, "min_circularity", "Minimum Circularity:", 0.0, 1.0, dp["min_circularity"], 2, is_float=True, resolution=0.05)
        self.create_parameter_row(self.tab_filter, "min_solidity", "Minimum Solidity:", 0.0, 1.0, dp["min_solidity"], 3, is_float=True, resolution=0.05)
        self.create_parameter_row(self.tab_filter, "max_aspect_ratio", "Maximum Aspect Ratio:", 1.0, 20.0, dp["max_aspect_ratio"], 4, is_float=True, resolution=0.5)
        self.create_parameter_row(self.tab_filter, "min_convexity", "Minimum Convexity:", 0.0, 1.0, dp["min_convexity"], 5, is_float=True, resolution=0.05)

    # ---------------- File loading ----------------

    def load_image_action(self):
        file_path = filedialog.askopenfilename(filetypes=[("All Image Formats", "*.jpg *.jpeg *.png *.bmp *.tiff *.pgm")])
        if file_path:
            self.folder_path = None
            self.image_path = file_path
            self.path_lbl.configure(text=os.path.basename(file_path))
            self.trigger_pipeline_refresh()

    def load_folder_action(self):
        folder_path = filedialog.askdirectory(title="Select Batch Folder of AM Images")
        if folder_path:
            self.image_path = None
            self.folder_path = folder_path
            files = [f for f in os.listdir(folder_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp'))]
            self.path_lbl.configure(text=f"Batch Folder: {os.path.basename(folder_path)} ({len(files)} target images)")
            if len(files) > 0:
                self.image_path = os.path.join(folder_path, files[0])
                self.trigger_pipeline_refresh()

    def get_current_params_dict(self):
        return {k: v.get() for k, v in self.params.items()}

    # ---------------- Live preview ----------------

    def trigger_pipeline_refresh(self):
        if not self.image_path or self.updating_ui:
            return
        p_dict = self.get_current_params_dict()
        result = run_pipeline(self.image_path, self.max_display_dim, p_dict)
        if result is not None:
            self.update_native_viewports(result)

    def convert_to_ctk_image(self, cv_img_bgr_or_rgb, source="bgr"):
        if source == "bgr":
            rgb = cv2.cvtColor(cv_img_bgr_or_rgb, cv2.COLOR_BGR2RGB)
        elif source == "gray":
            rgb = cv2.cvtColor(cv_img_bgr_or_rgb, cv2.COLOR_GRAY2RGB)
        else:
            rgb = cv_img_bgr_or_rgb
        h, w = rgb.shape[:2]
        pil_img = Image.fromarray(rgb)
        return ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(w, h))

    def update_native_viewports(self, result):
        normalized_u8 = np.clip(result["normalized"], 0, 255).astype(np.uint8)
        dog_colored = dog_to_colormap(result["dog"])

        panels = [
            self.convert_to_ctk_image(result["img_disp"], source="bgr"),
            self.convert_to_ctk_image(normalized_u8, source="gray"),
            self.convert_to_ctk_image(dog_colored, source="bgr"),
            self.convert_to_ctk_image(result["white_display"], source="rgb"),
            self.convert_to_ctk_image(result["dark_display"], source="rgb"),
            self.convert_to_ctk_image(result["final_output"], source="rgb"),
        ]
        for lbl, img in zip(self.view_labels, panels):
            lbl.configure(image=img, text="")
            lbl.image = img

    # ---------------- Export ----------------

    def start_async_export(self):
        if not self.image_path and not self.folder_path:
            messagebox.showwarning("Export Error", "Please load a single image or batch folder first.")
            return

        selected_parent_dir = filedialog.askdirectory(title="Select Destination Folder")
        if not selected_parent_dir:
            return

        self.export_btn.configure(state="disabled", text="⏳ Running High-Res Batch Pool...")

        export_thread = threading.Thread(target=self.background_export_worker, args=(selected_parent_dir,))
        export_thread.daemon = True
        export_thread.start()

    def background_export_worker(self, target_base_path):
        try:
            p_dict = self.get_current_params_dict()

            if self.folder_path:
                output_dir = os.path.join(target_base_path, "Output_Images_DoG_Watershed")
                os.makedirs(output_dir, exist_ok=True)
                files_to_process = [
                    os.path.join(self.folder_path, f)
                    for f in os.listdir(self.folder_path)
                    if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp'))
                ]
            else:
                base_filename = os.path.splitext(os.path.basename(self.image_path))[0]
                output_dir = os.path.join(target_base_path, f"pbf_inspection_{base_filename}_outputs")
                os.makedirs(output_dir, exist_ok=True)
                files_to_process = [self.image_path]

            def process_single_file(file_path):
                file_name_only = os.path.splitext(os.path.basename(file_path))[0]
                r = run_pipeline(file_path, None, p_dict)
                if r is None:
                    return

                if self.folder_path:
                    cv2.imwrite(os.path.join(output_dir, f"{file_name_only}_segmented.png"),
                                cv2.cvtColor(r["final_output"], cv2.COLOR_RGB2BGR))
                else:
                    # Full stage dump — satisfies "visualization for every stage" (spec item 11)
                    cv2.imwrite(os.path.join(output_dir, "01_original.png"), cv2.imread(file_path))
                    cv2.imwrite(os.path.join(output_dir, "02_illumination_normalized.png"),
                                np.clip(r["normalized"], 0, 255).astype(np.uint8))
                    cv2.imwrite(os.path.join(output_dir, "03_background_estimate.png"),
                                np.clip(r["background"], 0, 255).astype(np.uint8))
                    cv2.imwrite(os.path.join(output_dir, "04_denoised.png"),
                                np.clip(r["denoised"], 0, 255).astype(np.uint8))
                    cv2.imwrite(os.path.join(output_dir, "05_dog_combined.png"), dog_to_colormap(r["dog"]))
                    cv2.imwrite(os.path.join(output_dir, "06_dog_fine_band.png"), dog_to_colormap(r["dog_fine"]))
                    cv2.imwrite(os.path.join(output_dir, "07_dog_coarse_band.png"), dog_to_colormap(r["dog_coarse"]))
                    cv2.imwrite(os.path.join(output_dir, "08_bright_defect_mask.png"), r["bright"]["mask"])
                    cv2.imwrite(os.path.join(output_dir, "09_dark_defect_mask.png"), r["dark"]["mask"])
                    cv2.imwrite(os.path.join(output_dir, "10_final_binary_mask.png"), r["final_mask"])
                    cv2.imwrite(os.path.join(output_dir, "11_white_defects_overlay.png"), cv2.cvtColor(r["white_display"], cv2.COLOR_RGB2BGR))
                    cv2.imwrite(os.path.join(output_dir, "12_dark_defects_overlay.png"), cv2.cvtColor(r["dark_display"], cv2.COLOR_RGB2BGR))
                    cv2.imwrite(os.path.join(output_dir, "13_final_overlay.png"), cv2.cvtColor(r["final_output"], cv2.COLOR_RGB2BGR))

                    with open(os.path.join(output_dir, "parameters.json"), "w") as f:
                        json.dump({
                            "configured_parameters": p_dict,
                            "engine": "dual_polarity_multiscale_dog_watershed_v2",
                            "bright_defect_count": len(r["bright"]["contours"]),
                            "dark_defect_count": len(r["dark"]["contours"]),
                        }, f, indent=4)

            with ThreadPoolExecutor() as executor:
                executor.map(process_single_file, files_to_process)

            self.after(0, lambda: self.on_export_complete(output_dir))

        except Exception as e:
            self.after(0, lambda: self.on_export_failed(str(e)))

    def on_export_complete(self, output_dir):
        self.export_btn.configure(state="normal", text="💾 Export Output\n(Single or Batch Folder)")
        messagebox.showinfo("Export Successful", f"Operations completed successfully!\nTarget Directory:\n{output_dir}")

    def on_export_failed(self, error_msg):
        self.export_btn.configure(state="normal", text="💾 Export Output\n(Single or Batch Folder)")
        messagebox.showerror("Export Error", f"An execution error occurred:\n{error_msg}")


if __name__ == "__main__":
    app = PBFInspectorWorkstation()
    app.mainloop()
