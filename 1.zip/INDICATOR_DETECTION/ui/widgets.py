"""Reusable GUI widget factories (scrollable cards, browse rows, styled buttons).
Relocated verbatim from ImageAnalyzerApp in the original single-file app."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from PIL import Image, ImageTk
import cv2
import numpy as np
from scipy import ndimage as ndi
from skimage.segmentation import watershed as _skimage_watershed
from skimage.morphology import disk
import json
import math
import os
import sys
import gc
import threading
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path


class WidgetsMixin:
    """
    Mixin holding methods relocated verbatim from the original
    ``ImageAnalyzerApp`` god-class. It is combined with the other
    mixins in ``app.Application`` via multiple inheritance, so every
    method below still shares the same ``self`` (and therefore the
    same widgets / state) as before -- nothing about how these
    methods call each other or access ``self.*`` attributes changed.
    """

    def _make_scrollable_card(self, parent, max_width=700):
        """Create a scrollable canvas with a centred card frame. Returns card frame."""
        outer = tk.Frame(parent, bg=self.BG)
        outer.pack(fill='both', expand=True)
        _canvas = tk.Canvas(outer, bg=self.BG, highlightthickness=0)
        _vsb = ttk.Scrollbar(outer, orient='vertical', command=_canvas.yview)
        _canvas.configure(yscrollcommand=_vsb.set)
        _vsb.pack(side='right', fill='y')
        _canvas.pack(side='left', fill='both', expand=True)
        card = tk.Frame(_canvas, bg=self.PANEL, bd=0, relief='flat')
        _card_id = _canvas.create_window((0, 0), window=card, anchor='n')
        def _on_card_resize(e):
            _canvas.configure(scrollregion=_canvas.bbox('all'))
        def _on_canvas_resize(e):
            w = min(max_width, e.width)
            _canvas.itemconfig(_card_id, width=w)
            _canvas.coords(_card_id, e.width // 2, 0)
            card.configure(width=w)
        card.bind('<Configure>', _on_card_resize)
        _canvas.bind('<Configure>', _on_canvas_resize)
        _canvas.bind_all('<MouseWheel>',
                         lambda e: _canvas.yview_scroll(int(-1*(e.delta/120)), 'units'))
        return card

    def _make_browse_row(self, parent, label, var, pick_fn):
        """Shared label + readonly entry + Browse button row."""
        tk.Label(parent, text=label, bg=self.PANEL, fg=self.FG2,
                 font=('self.FONT', 9, 'bold')).pack(anchor='w', padx=30)
        row = tk.Frame(parent, bg=self.PANEL)
        row.pack(fill='x', padx=30, pady=(2, 10))
        tk.Entry(row, textvariable=var, bg=self.ENTRY_BG, fg=self.FG2,
                 relief='flat', font=('self.FONT', 9), state='readonly',
                 readonlybackground=self.ENTRY_BG, bd=0
                 ).pack(side='left', fill='x', expand=True, ipady=6, padx=(0, 8))
        tk.Button(row, text='Browse', command=pick_fn,
                  bg=self.BTN_BG, fg=self.FG, relief='flat',
                  font=('self.FONT', 9, 'bold'), padx=10, pady=3,
                  activebackground=self.HIGHLIGHT, cursor='hand2').pack(side='right')

    def _make_btn(self, parent, text, cmd, primary=False, **kw):
        """Shared styled button factory. Caller can override any kwarg via **kw."""
        bg  = self.HIGHLIGHT if primary else self.BTN_BG
        act = self.BTN_ACT   if primary else self.HIGHLIGHT
        # Build defaults; caller's **kw takes precedence for any key
        defaults = dict(
            bg=bg, fg='#ffffff' if primary else self.FG,
            relief='flat', font=('self.FONT', 10, 'bold'),
            padx=14, pady=6,
            activebackground=act, cursor='hand2',
        )
        defaults.update(kw)   # caller wins on any duplicate key
        return tk.Button(parent, text=text, command=cmd, **defaults)

