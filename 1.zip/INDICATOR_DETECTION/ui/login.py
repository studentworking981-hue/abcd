"""
Login window shown before the main application (independent of the
in-app login popup used to unlock the Single Image tab).

Relocated verbatim from the original single-file application. The only
change is where ``_resolve_font_family`` / ``_resolve_font_mono`` and
``_launch_main`` come from: they used to be module-level functions in
the same file, so they are now imported instead. ``_launch_main`` is
imported *inside* the methods that use it (rather than at module top)
purely to avoid a circular import between this module and
``main.py`` (main.py launches this window, and this window launches
back into main.py's ``_launch_main``); the call itself is unchanged.
"""

import tkinter as tk

from utils.fonts import _resolve_font_family, _resolve_font_mono


class LoginWindow:
    """Login screen shown before the main app."""

    USERNAME = 'admin'
    PASSWORD = 'admin'

    def __init__(self, root):
        self.root = root
        #self.root.title("Indicator Detection – Login")
        self.root.title("")
        self.root.geometry("420x520")
        self.root.resizable(False, False)

        self.FONT = _resolve_font_family()
        self.FONT_MONO = _resolve_font_mono()

        BG      = '#1e2328'
        PANEL   = '#252b33'
        ACCENT  = '#2e3a4a'
        BLUE    = '#2d7dd2'
        FG      = '#dde3ea'
        FG2     = '#7f8c9a'
        ENTRY   = '#181d22'

        self.root.configure(bg=BG)

        # ── Card ──────────────────────────────────────────────────────
        card = tk.Frame(self.root, bg=PANEL, bd=0)
        card.place(relx=0.5, rely=0.5, anchor='center', width=340, height=480)

        
        # Username
        tk.Label(card, text='Username', bg=PANEL, fg=FG2,
                 font=('Segoe UI', 9), anchor='w').pack(fill='x', padx=36)
        self.user_var = tk.StringVar()
        user_entry = tk.Entry(card, textvariable=self.user_var,
                              bg=ENTRY, fg=FG, relief='flat',
                              font=('Segoe UI', 11), insertbackground=FG, bd=0)
        user_entry.pack(fill='x', padx=36, ipady=8, pady=(3, 14))

        # Username
        tk.Label(card, text='Username', bg=PANEL, fg=FG2,
                 font=(self.FONT, 9), anchor='w').pack(fill='x', padx=36)
        self.user_var = tk.StringVar()
        user_entry = tk.Entry(card, textvariable=self.user_var,
                              bg=ENTRY, fg=FG, relief='flat',
                              font=(self.FONT, 11), insertbackground=FG, bd=0)
        user_entry.pack(fill='x', padx=36, ipady=8, pady=(3, 14))

        # Password
        tk.Label(card, text='Password', bg=PANEL, fg=FG2,
                 font=(self.FONT, 9), anchor='w').pack(fill='x', padx=36)
        self.pass_var = tk.StringVar()
        self.pass_entry = tk.Entry(card, textvariable=self.pass_var,
                                   show='●', bg=ENTRY, fg=FG, relief='flat',
                                   font=(self.FONT, 11), insertbackground=FG, bd=0)
        self.pass_entry.pack(fill='x', padx=36, ipady=8, pady=(3, 6))

        # Error label
        self.err_label = tk.Label(card, text='', bg=PANEL, fg='#e05c5c',
                                  font=(self.FONT, 9))
        self.err_label.pack(pady=(0, 12))

        # Login button
        login_btn = tk.Button(card, text='Login',
                              command=self._try_login,
                              bg=BLUE, fg='#ffffff', relief='flat',
                              font=(self.FONT, 11, 'bold'), padx=20, pady=8,
                              activebackground='#1a5fa8', activeforeground='#ffffff',
                              cursor='hand2')
        login_btn.pack(padx=36, fill='x')

        # Skip / continue as guest
        skip_btn = tk.Button(card, text='Continue without login \u2192',
                             command=self._skip_login,
                             bg=PANEL, fg=FG2, relief='flat',
                             font=(self.FONT, 9), pady=4,
                             activebackground=PANEL, activeforeground=FG,
                             cursor='hand2', bd=0)
        skip_btn.pack(pady=(8, 0))

        # ── Bindings ─────────────────────────────────────────────────
        user_entry.bind('<Return>', lambda e: self.pass_entry.focus())
        self.pass_entry.bind('<Return>', lambda e: self._try_login())

        user_entry.focus()

    def _try_login(self):
        from main import _launch_main
        u = self.user_var.get().strip()
        p = self.pass_var.get().strip()
        if u == self.USERNAME and p == self.PASSWORD:
            self.root.destroy()
            _launch_main()
        else:
            self.err_label.config(text='Invalid username or password.')
            self.pass_var.set('')

    def _skip_login(self):
        from main import _launch_main
        self.root.destroy()
        _launch_main()
