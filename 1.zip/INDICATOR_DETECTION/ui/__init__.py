"""UI package: Tkinter GUI components (login, tabs, dialogs, widgets)."""
