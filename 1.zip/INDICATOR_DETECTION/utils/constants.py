"""
Application-wide constants.

These values were originally hardcoded inline inside
``ImageAnalyzerApp.__init__`` in the single-file version of this
application. They are reproduced here **unchanged** (same literal
values) and simply referenced from ``app.py`` instead of being
duplicated inline, per the "centralize configuration values" goal of
the refactor. No value has been altered.
"""

# ── Colour palette (professional dark-steel theme) ─────────────────────────
COLOR_BG = '#1e2328'   # near-black charcoal
COLOR_PANEL = '#252b33'   # dark steel panel
COLOR_ACCENT = '#2e3a4a'   # muted slate-blue accent
COLOR_HIGHLIGHT = '#2d7dd2'   # professional azure blue
COLOR_FG = '#dde3ea'   # soft white text
COLOR_FG2 = '#7f8c9a'   # muted grey-blue subtext
COLOR_BTN_BG = '#2e3a4a'   # slate button
COLOR_BTN_ACT = '#1a5fa8'   # darker azure on hover
COLOR_ENTRY_BG = '#181d22'   # deep input background

# ── Window sizing ───────────────────────────────────────────────────────────
MAIN_WINDOW_GEOMETRY = "1400x900"
HEADER_HEIGHT = 54
FOOTER_HEIGHT = 28

# ── Header / footer text ────────────────────────────────────────────────────
APP_HEADER_TITLE = 'ADDITIVE MANUFACTURING DEFECT DETECTION'
APP_FOOTER_TEXT = 'Designed and Developed by RCI-DAIV'

# ── Navigation tab keys/labels (used to build the nav pill buttons) ────────
NAV_TABS = [
    ('single', 'Single Image'),
    ('batch', 'Batch Processing & 3D Visualization'),
]
