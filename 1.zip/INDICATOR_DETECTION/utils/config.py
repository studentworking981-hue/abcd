"""
Default application configuration.

These are the same hardcoded default paths that existed inline inside
``_init_tab_batch_3d`` in the original single-file application. They
are centralized here so they are easy to find/update, but their
*values* are unchanged.
"""

# ── Hardcoded default 3D-visualisation tool paths (preserved as-is) ────────
DEFAULT_FREECAD_EXE = (
    r"/home/dlpda/AI_PROBLEM_STATEMENTS/Additive_Manufacturing/ws/"
    r"prathyusha/squashfs-root/usr/bin/freecadcmd"
)
DEFAULT_SLICER_EXE = r"/home/dlpda/manaswini/Defects_analysis_GUI/Slicer/Slicer"

# ── 3D-visualisation hardcoded defaults (preserved from original) ──────────
VIZ3D_SP_X = 1.0
VIZ3D_SP_Y = 1.0
VIZ3D_SP_Z = 1.5  # 10.0 0.48  0.6
VIZ3D_ISLAND = 50
VIZ3D_R_MIN = 255
VIZ3D_G_MAX = 0
VIZ3D_B_MAX = 0

VIZ3D_SX = 8
VIZ3D_SY = 8
VIZ3D_SZ = 8
VIZ3D_TX = -1088
VIZ3D_TY = 1088
VIZ3D_TZ = 0

# 3D Viz parameters for the seg.nrrd segmentation model, independent of the
# STL parameters above. Defaults to an identity transform (scale=1,
# translate=0) so existing behaviour is unchanged unless these are
# explicitly set to something else.
VIZ3D_NRRD_SX = 1
VIZ3D_NRRD_SY = 1
VIZ3D_NRRD_SZ = 1
VIZ3D_NRRD_TX = 0
VIZ3D_NRRD_TY = 0
VIZ3D_NRRD_TZ = 0
