"""
Font-resolution helpers.

Moved verbatim from the original single-file application. Note: the
original code referenced ``tkfont.families()`` without ever importing
``tkinter.font as tkfont`` at module level. That means the ``try``
block below always raises ``NameError``, is swallowed by the bare
``except Exception``, and the function always falls back to the
default ('Helvetica' / 'Courier'). This refactor intentionally
preserves that exact behaviour rather than "fixing" it, per the
refactor rule of not changing any logic.
"""

_RESOLVED_FONT_FAMILY = None
_RESOLVED_FONT_MONO = None


def _resolve_font_family():
    """Return a modern, professional sans-serif UI font installed on this system."""
    global _RESOLVED_FONT_FAMILY
    if _RESOLVED_FONT_FAMILY is None:
        preferred = ('Segoe UI Variable', 'Segoe UI', 'Inter', 'Helvetica Neue',
                     'Ubuntu', 'Noto Sans', 'DejaVu Sans', 'Helvetica', 'Arial')
        try:
            available = set(tkfont.families())
        except Exception:
            available = set()
        _RESOLVED_FONT_FAMILY = next((f for f in preferred if f in available), 'Helvetica')
    return _RESOLVED_FONT_FAMILY

def _resolve_font_mono():
    """Return a modern monospace font (for status/log style text) installed on this system."""
    global _RESOLVED_FONT_MONO
    if _RESOLVED_FONT_MONO is None:
        preferred = ('Cascadia Mono', 'Consolas', 'JetBrains Mono', 'Ubuntu Mono',
                     'DejaVu Sans Mono', 'Courier New', 'Courier')
        try:
            available = set(tkfont.families())
        except Exception:
            available = set()
        _RESOLVED_FONT_MONO = next((f for f in preferred if f in available), 'Courier')
    return _RESOLVED_FONT_MONO

