"""
Reusable image helper functions (resize, PIL/OpenCV conversion, etc).

The original single-file application never factored these operations
out into standalone helpers -- each tab method called ``cv2``, PIL's
``Image``/``ImageTk``, and ``numpy`` directly inline, often with
step-specific quirks (e.g. particular interpolation flags, colour
channel orders) baked into that exact call site. Pulling any one of
those call sites out into a shared function here would mean rewriting
that logic instead of relocating it, which risks changing behaviour --
against the refactor's primary objective.

This module is kept as the designated home for such helpers per the
target project structure. If/when you factor out a genuine duplicate
(e.g. the BGR->RGB->PhotoImage conversion that appears in both
``processing/slicer.py`` and ``processing/single.py``), add it here
and import it from both call sites.
"""
