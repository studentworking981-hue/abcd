"""
Logging configuration.

The original single-file application did not use Python's ``logging``
module at all -- its only "logging" was the in-GUI status console on
the Batch tab (``tab3_log``, preserved as-is in
``processing/batch.py``, which writes into the on-screen
``ScrolledText`` widget). That GUI behaviour is untouched.

This module adds a standard, opt-in ``logging`` setup so uncaught
exceptions and startup/shutdown events can also be captured to a file
for debugging, without changing any existing GUI/processing behaviour.
It is wired up from ``main.py`` only, and nowhere else, so it is purely
additive.
"""

import logging
import os

_LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "outputs")
_LOG_FILE = os.path.join(_LOG_DIR, "app.log")

_logger = None


def get_logger():
    """Return the application-wide logger, creating it on first use."""
    global _logger
    if _logger is not None:
        return _logger

    os.makedirs(_LOG_DIR, exist_ok=True)

    logger = logging.getLogger("indicator_detection")
    logger.setLevel(logging.INFO)

    if not logger.handlers:
        file_handler = logging.FileHandler(_LOG_FILE)
        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    _logger = logger
    return _logger
