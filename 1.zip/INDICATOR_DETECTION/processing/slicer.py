"""ROI selection / slicing workflow (the original 'Tab 1'): loading an
image, drawing/clicking polygon points, clearing points, saving ROI
coordinates. Relocated verbatim from ImageAnalyzerApp in the original
single-file app."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from PIL import Image, ImageTk
import cv2
import numpy as np
from scipy import ndimage as ndi
from skimage.segmentation import watershed as _skimage_watershed
from skimage.morphology import disk
import json
import math
import os
import sys
import gc
import threading
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path


class SlicerMixin:
    """
    Mixin holding methods relocated verbatim from the original
    ``ImageAnalyzerApp`` god-class. It is combined with the other
    mixins in ``app.Application`` via multiple inheritance, so every
    method below still shares the same ``self`` (and therefore the
    same widgets / state) as before -- nothing about how these
    methods call each other or access ``self.*`` attributes changed.
    """

    def open_roi_window(self):
        """Open ROI Selection as a top-level window."""
        if self._roi_win is not None and self._roi_win.winfo_exists():
            self._roi_win.lift()
            return

        win = tk.Toplevel(self.root)
        win.title("ROI Selection")
        win.geometry("900x650")
        win.configure(bg=self.BG)
        self._roi_win = win

        ctrl = tk.Frame(win, bg=self.PANEL, height=44)
        ctrl.pack(side='top', fill='x')
        ctrl.pack_propagate(False)

        for txt, cmd in [("Upload Image",     self.tab1_upload_image),
                         ("Clear Points",     self.tab1_clear_points),
                         ("Save Coordinates", self.tab1_save_coordinates)]:
            tk.Button(ctrl, text=txt, command=cmd,
                      bg=self.BTN_BG, fg=self.FG, relief='flat',
                      font=(self.FONT, 9, 'bold'), padx=10, pady=4,
                      activebackground=self.HIGHLIGHT, cursor='hand2').pack(side='left', padx=6, pady=6)

        self.tab1_info_label = tk.Label(ctrl,
            text="Click on image to select polygon points (click on first point to close)",
            bg=self.PANEL, fg=self.FG2, font=(self.FONT, 9))
        self.tab1_info_label.pack(side='left', padx=16)

        canvas_frame = tk.Frame(win, bg=self.BG)
        canvas_frame.pack(fill='both', expand=True, padx=5, pady=5)

        self.tab1_canvas = tk.Canvas(canvas_frame, bg='#181d22', highlightthickness=0)
        v_scrollbar = ttk.Scrollbar(canvas_frame, orient='vertical',
                                    command=self.tab1_canvas.yview)
        h_scrollbar = ttk.Scrollbar(canvas_frame, orient='horizontal',
                                    command=self.tab1_canvas.xview)
        self.tab1_canvas.configure(yscrollcommand=v_scrollbar.set,
                                   xscrollcommand=h_scrollbar.set)
        v_scrollbar.pack(side='right', fill='y')
        h_scrollbar.pack(side='bottom', fill='x')
        self.tab1_canvas.pack(side='left', fill='both', expand=True)

        self.tab1_canvas.bind('<Button-1>', self.tab1_canvas_click)
        self.tab1_canvas.bind('<MouseWheel>',
                              lambda e: self.tab1_canvas.yview_scroll(int(-1*(e.delta/120)), "units"))
        self.tab1_canvas.bind('<Shift-MouseWheel>',
                              lambda e: self.tab1_canvas.xview_scroll(int(-1*(e.delta/120)), "units"))
        self.tab1_canvas.bind('<Control-MouseWheel>', self.tab1_zoom)
        self.tab1_canvas.bind('<plus>',  lambda e: self.tab1_zoom_button(1.1))
        self.tab1_canvas.bind('<minus>', lambda e: self.tab1_zoom_button(0.9))
        self.tab1_canvas.bind('<equal>', lambda e: self.tab1_zoom_button(1.1))

        if self.tab1_image is not None:
            self.tab1_display_image()

    def tab1_upload_image(self):
        """Upload image for ROI selection"""
        file_path = filedialog.askopenfilename(
            title="Select Image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png"),
                       ("All files", "*.*")]
        )

        if file_path:
            self.tab1_image_path = file_path
            self.tab1_cv_image = cv2.imread(file_path)
            self.tab1_image = cv2.cvtColor(self.tab1_cv_image, cv2.COLOR_BGR2RGB)
            self.tab1_polygon_points = []

            self.tab1_polygon_closed = False
            self.tab1_display_image()

    def tab1_zoom(self, event):
        """Zoom image with Ctrl+MouseWheel"""
        if self.tab1_image is None:
            return
        
        factor = 1.1 if event.delta > 0 else 0.9
        self.tab1_zoom_level *= factor
        self.tab1_zoom_level = max(0.1, min(10.0, self.tab1_zoom_level))
        self.tab1_display_image()

    def tab1_zoom_button(self, factor):
        """Zoom image with +/- keys"""
        if self.tab1_image is None:
            return
        
        self.tab1_zoom_level *= factor
        self.tab1_zoom_level = max(0.1, min(10.0, self.tab1_zoom_level))
        self.tab1_display_image()

    def tab1_display_image(self):
        """Display image on canvas"""
        if self.tab1_image is not None:
            display_img = self.tab1_image.copy()

            if len(self.tab1_polygon_points) > 0:
                for i in range(len(self.tab1_polygon_points) - 1):
                    cv2.line(display_img, self.tab1_polygon_points[i],
                            self.tab1_polygon_points[i + 1], (0, 255, 0), 2)

                if self.tab1_polygon_closed:
                    cv2.line(display_img, self.tab1_polygon_points[-1],
                            self.tab1_polygon_points[0], (0, 255, 0), 2)

                for idx, point in enumerate(self.tab1_polygon_points):
                    cv2.circle(display_img, point, 7, (255, 0, 0), -1)
                    cv2.circle(display_img, point, 8, (255, 255, 255), 2)

            pil_img = Image.fromarray(display_img)
            new_width = int(pil_img.width * self.tab1_zoom_level)
            new_height = int(pil_img.height * self.tab1_zoom_level)
            pil_img = pil_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
            self.tab1_photo = ImageTk.PhotoImage(pil_img)

            self.tab1_canvas.delete("all")
            self.tab1_canvas.create_image(0, 0, anchor='nw', image=self.tab1_photo)
            self.tab1_canvas.configure(scrollregion=self.tab1_canvas.bbox("all"))

    def tab1_canvas_click(self, event):
        """Handle canvas click to add polygon points or close polygon"""
        if self.tab1_image is not None and not self.tab1_polygon_closed:
            x = int(self.tab1_canvas.canvasx(event.x))
            y = int(self.tab1_canvas.canvasy(event.y))

            # Check if clicking near first point to close polygon
            if len(self.tab1_polygon_points) >= 3:
                first_point = self.tab1_polygon_points[0]
                distance = math.sqrt((x - first_point[0])**2 + (y - first_point[1])**2)

                if distance <= 15:
                    self.tab1_polygon_closed = True
                    self.tab1_display_image()
                    self.tab1_info_label.config(
                        text=f"Polygon closed with {len(self.tab1_polygon_points)} points. Ready to save."
                    )
                    return

            # Add new point
            self.tab1_polygon_points.append((int(x), int(y)))
            self.tab1_display_image()

            if len(self.tab1_polygon_points) < 3:
                self.tab1_info_label.config(
                    text=f"Points selected: {len(self.tab1_polygon_points)} (need at least 3)"
                )
            else:
                self.tab1_info_label.config(
                    text=f"Points selected: {len(self.tab1_polygon_points)} (click on point 1 to close)"
                )

    def tab1_clear_points(self):
        """Clear all polygon points"""
        self.tab1_polygon_points = []
        self.tab1_polygon_closed = False
        self.tab1_display_image()
        self.tab1_info_label.config(
            text="Click on image to select polygon points (click on first point to close)"
        )

    def tab1_save_coordinates(self):
        """Save polygon coordinates to JSON file"""
        if len(self.tab1_polygon_points) < 3:
            messagebox.showwarning("Warning",
                                   "Please select at least 3 points to form a polygon")
            return

        if self.tab1_image_path is None:
            messagebox.showwarning("Warning", "No image loaded")
            return

        save_path = filedialog.asksaveasfilename(
            title="Save Coordinates",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )

        if save_path:
            data = {
                "image_path": self.tab1_image_path,
                "image_shape": self.tab1_image.shape[:2],
                "polygon_points": self.tab1_polygon_points
            }

            with open(save_path, 'w') as f:
                json.dump(data, f, indent=4)

            messagebox.showinfo("Success", f"Coordinates saved to {save_path}")

