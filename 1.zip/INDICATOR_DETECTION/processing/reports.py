"""Report generation: evaluating predictions against ground truth and
exporting the results/metrics to Excel. Relocated verbatim from
ImageAnalyzerApp in the original single-file app."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from PIL import Image, ImageTk
import cv2
import numpy as np
from scipy import ndimage as ndi
from skimage.segmentation import watershed as _skimage_watershed
from skimage.morphology import disk
import json
import math
import os
import sys
import gc
import threading
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path


class ReportsMixin:
    """
    Mixin holding methods relocated verbatim from the original
    ``ImageAnalyzerApp`` god-class. It is combined with the other
    mixins in ``app.Application`` via multiple inheritance, so every
    method below still shares the same ``self`` (and therefore the
    same widgets / state) as before -- nothing about how these
    methods call each other or access ``self.*`` attributes changed.
    """

    def _rpt_generate(self):
        """Collect folders, match images, compute metrics, update UI."""
        pred_folder = self._rpt_pred_var.get().strip()
        gt_folder   = self._rpt_gt_var.get().strip()

        if pred_folder == 'No folder selected' or not os.path.isdir(pred_folder):
            messagebox.showwarning('Reports', 'Please select a valid Predicted Results folder.')
            return
        if gt_folder == 'No folder selected' or not os.path.isdir(gt_folder):
            messagebox.showwarning('Reports', 'Please select a valid Ground Truth folder.')
            return

        self._rpt_status_var.set('Processing ')
        self._rpt_generate_btn.config(state='disabled')
        self.root.update_idletasks()

        try:
            results, metrics, warnings = self._rpt_evaluate(pred_folder, gt_folder)
        except Exception as exc:
            messagebox.showerror('Reports Error', f'Evaluation failed:\n{exc}')
            self._rpt_generate_btn.config(state='normal')
            self._rpt_status_var.set('Error during evaluation. Check folder structure.')
            return

        # Store for later saving
        self._rpt_results_data = results
        self._rpt_metrics_data = metrics
        self._rpt_pred_folder  = pred_folder
        self._rpt_gt_folder    = gt_folder

        # Update metric tiles
        total = len(results)
        warn_txt = f'  {len(warnings)} warning(s): {"; ".join(warnings[:3])}{"..." if len(warnings) > 3 else ""}' if warnings else ''
        self._rpt_status_var.set(
            f'Evaluation complete -- {total} image(s) processed. '
            f'TP={metrics["tp"]}  TN={metrics["tn"]}  FP={metrics["fp"]}  FN={metrics["fn"]}.{warn_txt}  '
            f'Click "Save Excel" to export the report.')

        self._rpt_save_btn.config(state='normal')
        self._rpt_generate_btn.config(state='normal')

    def _rpt_evaluate(self, pred_folder, gt_folder):
        """
        Match images by filename, compute TP/TN/FP/FN.
        Returns (results_list, metrics_dict, warnings_list).
        """
        DEFECT     = 'defects'
        NON_DEFECT = 'non_defects'

        def _load_folder(root_path):
            """Return {filename_lower: category_string} from defects/ non_defects/ subfolders."""
            mapping = {}
            for sub in os.listdir(root_path):
                sub_path = os.path.join(root_path, sub)
                if not os.path.isdir(sub_path):
                    continue
                sub_lower = sub.lower().strip()
                # Normalise: accept 'defect', 'defects', 'indicator', 'indicators',
                # 'non_defect', 'non_defects', 'non_indicator', 'non_indicators', etc.
                if sub_lower in ('defects', 'defect', 'indicators', 'indicator'):
                    category = DEFECT
                elif sub_lower in ('non_defects', 'non_defect', 'non_indicators', 'non_indicator'):
                    category = NON_DEFECT
                else:
                    continue  # skip unknown subfolders
                for fname in os.listdir(sub_path):
                    if fname.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif')):
                        mapping[fname.lower()] = category
            return mapping

        pred_map = _load_folder(pred_folder)
        gt_map   = _load_folder(gt_folder)

        all_filenames = set(pred_map.keys()) | set(gt_map.keys())

        results  = []
        warnings = []
        tp = tn = fp = fn = 0

        for fname in sorted(all_filenames):
            gt_cat   = gt_map.get(fname)
            pred_cat = pred_map.get(fname)

            # ── Edge cases ───────────────────────────────────────────────
            if gt_cat is None:
                # In prediction but not in GT    note separately
                results.append({
                    'Image Name':   fname,
                    'Ground Truth': 'N/A (missing)',
                    'Predicted':    pred_cat,
                    'Result':       'No GT',
                })
                warnings.append(f'{fname}: exists in Prediction but not in Ground Truth')
                continue

            if pred_cat is None:
                # In GT but not in Prediction    treat as FN
                results.append({
                    'Image Name':   fname,
                    'Ground Truth': gt_cat,
                    'Predicted':    'N/A (missing)',
                    'Result':       'FN (missing prediction)',
                })
                fn += 1
                warnings.append(f'{fname}: exists in Ground Truth but not in Prediction (counted as FN)')
                continue

            # ── Normal classification ────────────────────────────────────
            if gt_cat == DEFECT and pred_cat == DEFECT:
                label = 'TP'; tp += 1
            elif gt_cat == NON_DEFECT and pred_cat == NON_DEFECT:
                label = 'TN'; tn += 1
            elif gt_cat == NON_DEFECT and pred_cat == DEFECT:
                label = 'FP'; fp += 1
            else:  # gt==defect, pred==non_defect
                label = 'FN'; fn += 1

            results.append({
                'Image Name':   fname,
                'Ground Truth': gt_cat,
                'Predicted':    pred_cat,
                'Result':       label,
            })

        # ── Metrics ──────────────────────────────────────────────────────
        total_classified = tp + tn + fp + fn
        accuracy  = (tp + tn) / total_classified if total_classified > 0 else 0.0
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall    = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1        = (2 * precision * recall / (precision + recall)
                     if (precision + recall) > 0 else 0.0)

        metrics = {
            'accuracy':  round(accuracy,  4),
            'precision': round(precision, 4),
            'recall':    round(recall,    4),
            'f1':        round(f1,        4),
            'tp': tp, 'tn': tn, 'fp': fp, 'fn': fn,
        }
        return results, metrics, warnings

    def _rpt_save_excel(self):
        """Save two-sheet Excel report to user-chosen path."""
        if not self._rpt_results_data or not self._rpt_metrics_data:
            messagebox.showwarning('Reports', 'No report data. Please generate a report first.')
            return

        save_path = filedialog.asksaveasfilename(
            title='Save Excel Report',
            defaultextension='.xlsx',
            filetypes=[('Excel files', '*.xlsx'), ('All files', '*.*')],
            initialfile='classification_report.xlsx',
        )
        if not save_path:
            return

        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        except ImportError:
            messagebox.showerror(
                'Missing Library',
                'openpyxl is required to save Excel files.\n\n'
                'Install it with:  pip install openpyxl')
            return

        wb = openpyxl.Workbook()

        # ── Colour palette for Excel ─────────────────────────────────────
        HDR_FILL   = PatternFill('solid', fgColor='2D7DD2')
        HDR_FONT   = Font(bold=True, color='FFFFFF', size=10)
        TP_FILL    = PatternFill('solid', fgColor='D1ECF1')
        TN_FILL    = PatternFill('solid', fgColor='D1ECF1')
        FP_FILL    = PatternFill('solid', fgColor='FFF3CD')
        FN_FILL    = PatternFill('solid', fgColor='FFF3CD')
        NOGT_FILL  = PatternFill('solid', fgColor='E2E3E5')
        THIN       = Border(
            left=Side(style='thin'), right=Side(style='thin'),
            top=Side(style='thin'), bottom=Side(style='thin'))
        CENTER     = Alignment(horizontal='center', vertical='center')
        LEFT       = Alignment(horizontal='left',   vertical='center')

        def _hdr_cell(ws, row, col, value):
            c = ws.cell(row=row, column=col, value=value)
            c.font      = HDR_FONT
            c.fill      = HDR_FILL
            c.alignment = CENTER
            c.border    = THIN
            return c

        # ── Sheet 1 : Detailed image-wise report ─────────────────────────
        ws1 = wb.active
        ws1.title = 'Image-wise Report'

        headers1 = ['Image Name', 'Ground Truth', 'Predicted', 'Result']
        col_widths1 = [32, 18, 18, 26]
        for col, (h, w) in enumerate(zip(headers1, col_widths1), start=1):
            _hdr_cell(ws1, 1, col, h)
            ws1.column_dimensions[
                openpyxl.utils.get_column_letter(col)].width = w

        result_fill_map = {
            'TP': TP_FILL, 'TN': TN_FILL,
            'FP': FP_FILL, 'FN': FN_FILL,
        }

        for r_idx, row_data in enumerate(self._rpt_results_data, start=2):
            result_val = row_data['Result']
            row_fill   = result_fill_map.get(result_val[:2], NOGT_FILL)

            for col, key in enumerate(['Image Name', 'Ground Truth', 'Predicted', 'Result'],
                                       start=1):
                c = ws1.cell(row=r_idx, column=col, value=row_data[key])
                c.fill      = row_fill
                c.border    = THIN
                c.alignment = LEFT if col == 1 else CENTER
            ws1.row_dimensions[r_idx].height = 16

        ws1.freeze_panes = 'A2'

        # ── Sheet 2 : Overall metrics summary ────────────────────────────
        ws2 = wb.create_sheet(title='Overall Metrics')

        headers2 = ['Dataset / Path', 'Accuracy', 'Precision', 'Recall',
                    'F1 Score', 'TP', 'TN', 'FP', 'FN']
        col_widths2 = [48, 12, 12, 12, 12, 8, 8, 8, 8]
        for col, (h, w) in enumerate(zip(headers2, col_widths2), start=1):
            _hdr_cell(ws2, 1, col, h)
            ws2.column_dimensions[
                openpyxl.utils.get_column_letter(col)].width = w

        m = self._rpt_metrics_data
        dataset_label = (f'Pred: {self._rpt_pred_folder}  |  GT: {self._rpt_gt_folder}')
        row_vals = [
            dataset_label,
            m['accuracy'], m['precision'], m['recall'], m['f1'],
            m['tp'], m['tn'], m['fp'], m['fn'],
        ]
        for col, val in enumerate(row_vals, start=1):
            c = ws2.cell(row=2, column=col, value=val)
            c.border    = THIN
            c.alignment = LEFT if col == 1 else CENTER
        ws2.row_dimensions[2].height = 18
        ws2.freeze_panes = 'A2'

        # ── Save ─────────────────────────────────────────────────────────
        try:
            wb.save(save_path)
            messagebox.showinfo('Reports', f'Excel report saved successfully:\n{save_path}')
            self._rpt_status_var.set(f'Report saved to: {save_path}')
            # Keep the main tab's "latest report" hyperlink in sync (Change 3).
            self._batch3d_set_report_link(save_path)
        except Exception as exc:
            messagebox.showerror('Save Error', f'Could not save file:\n{exc}')

