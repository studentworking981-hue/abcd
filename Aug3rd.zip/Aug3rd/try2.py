"""
pbf_inspector_monolithic.py
============================
Single-file build of the PBF Powder-Bed Inspection Workstation.

This is a straight merge of the original modular project (app.py,
config.py, utilities.py, preprocessing.py, enhancement.py,
segmentation.py, postprocessing.py, visualization.py, roi_selection.py,
pipeline.py) into one file, for environments where shipping/copying a
single script is more convenient than a package of modules.

No behavior changes were made. No third-party dependency was added or
removed -- this file imports exactly what the modular version imported:
Python standard library, OpenCV (cv2), NumPy, SciPy (scipy.ndimage),
scikit-image (skimage.morphology / .measure / .segmentation / .feature),
Pillow (PIL), Tkinter, and customtkinter.

The only changes made while merging:
  * Removed the per-file `sys.path.insert(...)` shims that existed only
    to make sibling-module imports (`from config import ...`, etc.) work
    regardless of the launcher -- unnecessary once everything lives in
    one file.
  * Removed one duplicate local `import cv2` inside a function (the
    module already imports cv2 at the top).
  * Removed the `from postprocessing import local_contrast_rescue`
    inside `run_multiband_detection` -- that function is now defined
    earlier in this same file.
  * Removed the `from config import DEFAULT_PARAMS` duplicate at
    call sites since it's already imported once at module scope.

calibration/analyze_dataset.py was intentionally NOT folded in here --
it is an independent command-line calibration tool with its own
`if __name__ == "__main__":` / argv-driven entry point (run as
`python analyze_dataset.py /path/to/images`), not part of the running
GUI application, so merging it would only make both harder to invoke
correctly. It still imports from the modular files
(preprocessing.py, enhancement.py, segmentation.py, postprocessing.py),
so keep those alongside it if you continue to use that script; it does
not need anything from this monolithic file.

Section map (search for these headers):
    SECTION 1  -- Logging setup
    SECTION 2  -- config.DEFAULT_PARAMS
    SECTION 3  -- utilities (I/O, ROI polygon math, display resize, config persistence)
    SECTION 4  -- preprocessing (Stage 1: illumination flatten, CLAHE, bilateral denoise)
    SECTION 5  -- enhancement (Stage 2: DoG bands, opening-by-reconstruction, h-dome)
    SECTION 6  -- postprocessing (Stage 4: small-component removal, close/fill, shape filter,
                                    minute-defect rescue, region-properties table)
    SECTION 7  -- segmentation (Stage 3: adaptive threshold, watershed, band orchestration)
    SECTION 8  -- visualization (colormaps, overlays)
    SECTION 9  -- pipeline (top-level orchestrator: run_pipeline)
    SECTION 10 -- GUI (CTkSpinbox, ROIPolygonEditor, PBFInspectorWorkstation)
    SECTION 11 -- entry point
"""

import os
import sys
import json
import logging
import threading
from concurrent.futures import ThreadPoolExecutor

import cv2
import numpy as np
from scipy import ndimage
from skimage.morphology import reconstruction
from skimage.measure import regionprops, label as sk_label
from skimage.segmentation import watershed
from skimage.feature import peak_local_max

import tkinter as tk
import customtkinter as ctk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk


# ======================================================================
# SECTION 1 -- Logging setup
# ======================================================================

logger = logging.getLogger("pbf_inspector")
if not logger.handlers:
    _h = logging.StreamHandler()
    _h.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    logger.addHandler(_h)
    logger.setLevel(logging.INFO)


# ======================================================================
# SECTION 2 -- config.DEFAULT_PARAMS
# ======================================================================
#
# Single source of truth for default parameters. Every value here is
# either a previously-validated constant (documented in the enhancement/
# segmentation/postprocessing rationale below) or a value recalibrated
# against the real dataset provided for this project -- see
# calibration/CALIBRATION_REPORT.md for the full derivation of every
# sensitivity/area parameter, and calibration/analyze_dataset.py for the
# reusable script that produced them (re-runnable against a different
# dataset later).

DEFAULT_PARAMS = dict(
    # Stage 1 -- Preprocessing (illumination & denoise)
    bg_sigma=45.0,
    bilat_d=9, bilat_sc=50.0, bilat_ss=50.0,
    clahe_clip_limit=2.5, clahe_tile_grid=(8, 8),

    # Stage 2 -- Enhancement (multi-scale DoG)
    fine_sigma1=1.0, fine_sigma2=3.0,
    coarse_sigma1=5.0, coarse_sigma2=16.0,
    recon_radius=1,

    # Stage 3 -- Segmentation (sensitivity & watershed)
    # noise_k_fine/coarse recalibrated 4.0->7.0, 3.5->6.0 -- see
    # CALIBRATION_REPORT.md ("Sensitivity recalibration").
    noise_k_fine=7.0,
    noise_k_coarse=6.0,
    min_component_area_fine=5,
    min_component_area_coarse=60,
    local_max_min_dist=4,
    compactness=0.0,

    # Stage 3b -- Full-extent band (h-dome/h-minima) & continuity
    # extent_k recalibrated 3.0->5.0, min_component_area_extent 120->300 --
    # see CALIBRATION_REPORT.md ("Extent-band recalibration").
    close_radius_fine=1,
    close_radius_coarse=2,
    close_radius_extent=3,
    extent_k=5.0,
    min_component_area_extent=300,
    local_max_min_dist_extent=15,

    # Stage 4 -- Postprocessing (shape/region-property filtering)
    min_area=12, max_area=25000,
    min_circularity=0.4, min_solidity=0.8, max_aspect_ratio=5.0, min_convexity=0.88,

    # Stage 4b -- Minute-defect rescue
    micro_rescue_trim_enabled=True,
    micro_rescue_relaxed_enabled=True,  # see local_contrast_rescue() docstring below:
    # disabling this dropped minute synthetic-defect recall from 100% to 0%
    # once noise_k_fine was recalibrated upward for the real dataset, which
    # conflicts with Requirement 5's explicit "very small defects" goal.
    # Enabled by default as a deliberate sensitivity-over-specificity choice
    # (miss a real defect vs. flag one extra candidate for human review) --
    # trades a moderate increase in raw candidate count on the real dataset
    # (roughly +5-20 per image) for full minute-defect recall. Exposed as an
    # easy single-switch toggle (Tab 6) for anyone who wants fewer
    # candidates and is confident they aren't missing faint real defects.
    micro_rescue_ring_px=6,
    micro_rescue_min_z=3.0,
    micro_rescue_max_area=40,
)

# ----------------------------------------------------------------------
# Future AI integration (Requirement 11)
# ----------------------------------------------------------------------
# `run_pipeline()` calls `run_multiband_detection()` through a single,
# narrow interface:
#
#     run_multiband_detection(denoised, dog_fine, dog_coarse, roi, params)
#         -> {"bright": {"mask": ..., "contours": ..., "bands": ...},
#             "dark":   {"mask": ..., "contours": ..., "bands": ...}}
#
# A future learned model (YOLOv8 for bounding-box detection, U-Net or
# Mask R-CNN for pixel-level segmentation) can be integrated WITHOUT
# restructuring the rest of the application by writing a new function
# with the same input/output contract and switching which one
# `run_pipeline()` calls based on a config flag
# (`params["backend"] = "classical" | "dl"`). Every downstream stage
# (shape filter, region-properties table, visualization, export) only
# consumes that dict shape and would not need to change at all.


# ======================================================================
# SECTION 3 -- utilities (I/O, ROI polygon math, display resize, config)
# ======================================================================
#
# Generic, dependency-light helpers: image I/O, ROI polygon math,
# display-only resizing, and config persistence. Contains NO detection
# logic and NO GUI code.
#
# Two non-negotiable rules enforced here:
#   1. Never crop, rotate, deskew, or perspective-warp an image
#      automatically. `load_image_no_transform()` is the ONLY function
#      that touches disk, and it does nothing except `cv2.imread`.
#   2. Never resize for anything except on-screen display.
#      `resize_for_display()` is the one place that ever changes an
#      array's dimensions; it always preserves aspect ratio, and its
#      output must never be fed back into detection -- only into a
#      GUI label/canvas.


def load_image_no_transform(path):
    """Load an image exactly as captured. No crop, no rotate, no deskew,
    no perspective correction, no resize. Returns a BGR uint8 array (as
    OpenCV always does) or raises FileNotFoundError / ValueError."""
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Image not found: {path}")
    img = cv2.imread(path, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"OpenCV could not decode image: {path}")
    return img


def to_grayscale(bgr_img):
    """BGR -> single-channel grayscale. Pure colour-space conversion, no
    resize, no crop."""
    return cv2.cvtColor(bgr_img, cv2.COLOR_BGR2GRAY)


def polygon_to_mask(shape_hw, polygon_pts_norm):
    """polygon_pts_norm: list of (x_frac, y_frac), each in [0, 1],
    relative to whatever image they were drawn on. Returns a uint8
    0/255 mask sized to `shape_hw`.

    Returns an all-255 ("no restriction / process everything") mask if
    the polygon has fewer than 3 points, so callers never need a
    special case for "ROI not yet defined"."""
    h, w = shape_hw
    if polygon_pts_norm is None or len(polygon_pts_norm) < 3:
        return np.full((h, w), 255, dtype=np.uint8)
    mask = np.zeros((h, w), dtype=np.uint8)
    pts = np.array([(fx * w, fy * h) for (fx, fy) in polygon_pts_norm], dtype=np.int32).reshape(-1, 1, 2)
    cv2.fillPoly(mask, [pts], 255)
    return mask


def polygon_bounding_box(shape_hw, polygon_pts_norm, pad=0):
    """Pixel-space (x0, y0, x1, y1) bounding box of a normalized polygon,
    clamped to the image and optionally padded. Used to restrict
    processing to the ROI's bounding box for speed on very large images
    with a small ROI -- purely an internal compute-cost optimization,
    never a replacement for the full-image display."""
    h, w = shape_hw
    if polygon_pts_norm is None or len(polygon_pts_norm) < 3:
        return 0, 0, w, h
    xs = [fx * w for (fx, fy) in polygon_pts_norm]
    ys = [fy * h for (fx, fy) in polygon_pts_norm]
    x0 = max(0, int(min(xs)) - pad)
    y0 = max(0, int(min(ys)) - pad)
    x1 = min(w, int(max(xs)) + pad)
    y1 = min(h, int(max(ys)) + pad)
    return x0, y0, x1, y1


def resize_for_display(img, max_dim):
    """Aspect-ratio-preserving downsize, for on-screen rendering ONLY.
    Never resizes upward. Returns the original array unchanged (same
    object, not a copy) if it already fits within max_dim -- callers
    must not rely on getting a fresh array back."""
    h, w = img.shape[:2]
    if max(h, w) <= max_dim:
        return img
    scale = max_dim / float(max(h, w))
    new_w, new_h = max(1, int(round(w * scale))), max(1, int(round(h * scale)))
    interp = cv2.INTER_AREA if scale < 1.0 else cv2.INTER_LINEAR
    return cv2.resize(img, (new_w, new_h), interpolation=interp)


def save_config(path, params, roi_polygon=None, extra=None):
    payload = {"parameters": params, "roi_polygon_normalized": roi_polygon}
    if extra:
        payload.update(extra)
    with open(path, "w") as f:
        json.dump(payload, f, indent=2)


def load_config(path):
    with open(path, "r") as f:
        return json.load(f)


# ======================================================================
# SECTION 4 -- preprocessing (Stage 1)
# ======================================================================
#
# Turn a raw grayscale frame into a denoised, illumination-flattened
# array ready for enhancement/segmentation. Every function below
# operates on whatever array it is given -- none of them crop, rotate,
# or resize. ROI masking is applied by restricting statistics
# computation to the mask, never by slicing the array down to a smaller
# shape, so array shape is identical from raw input through to the
# final overlay.
#
# See the original project's preprocessing.py module docstring (kept in
# calibration/CALIBRATION_REPORT.md-adjacent history) for the full
# stage-by-stage rationale (why illumination flattening via a large
# Gaussian background estimate, why CLAHE is visualization-only, why
# bilateral filtering over a plain Gaussian blur, and the specific
# parameter sweeps behind bg_sigma=45 / bilat d=9,sc=50,ss=50).


def estimate_background(gray_f32, sigma):
    """Large-sigma Gaussian low-pass -- the slow illumination/vignette
    field."""
    k = int(2 * round(3 * sigma) + 1)
    k = max(k, 3)
    return cv2.GaussianBlur(gray_f32, (k, k), sigma)


def flatten_illumination(gray_f32, background, target=128.0):
    """Multiplicative flat-fielding: divide out the estimated
    background, rescale so the mean sits near `target`."""
    norm = (gray_f32 / (background + 1e-3)) * target
    return np.clip(norm, 0, 255).astype(np.float32)


def apply_clahe(gray_u8, clip_limit=2.5, tile_grid_size=(8, 8)):
    """Contrast-Limited Adaptive Histogram Equalization -- VISUALIZATION
    ONLY, never fed into the quantitative detection channels (CLAHE
    boosts contrast uniformly, including powder-grain texture, which
    measurably increased raw detection count during development)."""
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_grid_size)
    return clahe.apply(gray_u8)


def bilateral_denoise(normalized_u8, d=9, sigma_color=50.0, sigma_space=50.0):
    """Edge-preserving denoise. Input/output both uint8; caller converts
    to float32 afterwards for the enhancement stage."""
    return cv2.bilateralFilter(normalized_u8, int(d), float(sigma_color), float(sigma_space))


def preprocess(gray_u8, params):
    """Orchestrates Stage 1: illumination flattening + denoise, and
    (separately) a CLAHE view for the operator. Returns a dict; every
    array in it has the SAME shape as `gray_u8` -- nothing is cropped or
    resized here."""
    gray_f = gray_u8.astype(np.float32)
    background = estimate_background(gray_f, params["bg_sigma"])
    normalized = flatten_illumination(gray_f, background, target=128.0)
    denoised = bilateral_denoise(
        normalized.astype(np.uint8), params["bilat_d"], params["bilat_sc"], params["bilat_ss"]
    ).astype(np.float32)
    clahe_view = apply_clahe(gray_u8, params.get("clahe_clip_limit", 2.5), params.get("clahe_tile_grid", (8, 8)))
    return dict(background=background, normalized=normalized, denoised=denoised, clahe_view=clahe_view)


# ======================================================================
# SECTION 5 -- enhancement (Stage 2)
# ======================================================================
#
# Turn the denoised, illumination-flattened image into one or more
# "channels" that respond strongly to candidate defects and weakly to
# everything else:
#   * Multi-scale Difference-of-Gaussians (DoG) -- band-pass, scale-
#     tuned, excellent for small-to-medium defects with a visible
#     interior/edge structure.
#   * Topographic h-dome / h-minima extraction via morphological
#     reconstruction -- captures the FULL extent of a large, spatially
#     homogeneous defect, which a band-pass filter structurally cannot.


def difference_of_gaussians(img_f32, sigma1, sigma2):
    k1 = max(3, int(2 * round(3 * sigma1) + 1))
    k2 = max(3, int(2 * round(3 * sigma2) + 1))
    g1 = cv2.GaussianBlur(img_f32, (k1, k1), sigma1)
    g2 = cv2.GaussianBlur(img_f32, (k2, k2), sigma2)
    return g1 - g2


def opening_by_reconstruction(channel_f32, radius):
    """Grayscale opening-by-reconstruction: removes single-pixel/
    sub-pixel speckle from a channel while leaving the SHAPE of any
    surviving blob untouched (unlike a plain morphological opening,
    which can erode and distort real blob boundaries)."""
    if radius <= 0:
        return channel_f32
    size = 2 * radius + 1
    seed = ndimage.grey_erosion(channel_f32, size=(size, size))
    seed = np.minimum(seed, channel_f32)
    return reconstruction(seed, channel_f32, method='dilation')


def robust_mu_sigma(vals):
    """Median / MAD (robust) statistics. Used for sizing the h-dome
    depth from raw (non zero-inflated) intensity data -- must NOT be
    used on a zero-inflated channel (e.g. a clipped DoG response); that
    was tried during development and caused a measured false-positive
    spike."""
    med = float(np.median(vals))
    mad = float(np.median(np.abs(vals - med)))
    return med, 1.4826 * mad + 1e-6


def hdome_response(signed_f32, depth):
    """Regional-maxima ('h-dome') extraction via morphological
    reconstruction. signed_f32 = +denoised image for the bright
    polarity, -denoised image for the dark polarity."""
    seed = signed_f32 - depth
    recon = reconstruction(seed, signed_f32, method='dilation')
    return signed_f32 - recon


def compute_enhancement_channels(denoised_f32, params):
    """Orchestrates Stage 2 for ONE polarity's worth of raw DoG bands
    (shared between bright/dark -- the sign flip happens in the
    segmentation stage, since the same DoG array is reused for both
    polarities). Returns the fine/coarse DoG bands."""
    dog_fine = difference_of_gaussians(denoised_f32, params["fine_sigma1"], params["fine_sigma2"])
    dog_coarse = difference_of_gaussians(denoised_f32, params["coarse_sigma1"], params["coarse_sigma2"])
    return dict(dog_fine=dog_fine, dog_coarse=dog_coarse)


# ======================================================================
# SECTION 6 -- postprocessing (Stage 4)
# ======================================================================
#
# Clean up raw watershed segments into the final defect set: making
# regions continuous (no holes/broken rings), rejecting non-defect
# shapes, rescuing minute defects from over-aggressive global
# thresholds, and producing a region-properties table
# (skimage.measure.regionprops) for export/future ML feature
# engineering.
#
# Defined BEFORE segmentation in this file because segmentation calls
# into remove_small_components / close_and_fill / shape_filter /
# local_contrast_rescue.


def remove_small_components(binary_u8, min_area):
    """Connected-component + area filter, vectorized via a label lookup
    table (fast even with hundreds of components at realistic
    resolutions)."""
    n, labels, stats, _ = cv2.connectedComponentsWithStats(binary_u8, connectivity=8)
    keep = stats[:, cv2.CC_STAT_AREA] >= min_area
    keep[0] = False
    lut = keep.astype(np.uint8) * 255
    return lut[labels]


def close_and_fill(binary_u8, radius):
    """Morphological closing + hole-fill. radius<=0 disables it (same
    opt-out convention as recon_radius in the enhancement stage)."""
    if radius <= 0 or binary_u8.max() == 0:
        return binary_u8
    k = 2 * radius + 1
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
    closed = cv2.morphologyEx(binary_u8, cv2.MORPH_CLOSE, kernel)
    filled = ndimage.binary_fill_holes(closed > 0).astype(np.uint8) * 255
    return filled


def shape_filter(seg_labels, min_area, max_area, min_circ, min_solid, max_aspect, min_conv):
    """Area / circularity / solidity / aspect / convexity discriminator
    -- the single most important texture-vs-defect discriminator on
    the calibration dataset (see CALIBRATION_REPORT.md)."""
    out = np.zeros(seg_labels.shape, dtype=np.uint8)
    kept = []
    for label in np.unique(seg_labels):
        if label == 0:
            continue
        comp = (seg_labels == label).astype(np.uint8) * 255
        cnts, _ = cv2.findContours(comp, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            continue
        c = max(cnts, key=cv2.contourArea)
        area = cv2.contourArea(c)
        if not (min_area <= area <= max_area):
            continue
        perim = cv2.arcLength(c, True)
        circularity = (4 * np.pi * area) / (perim ** 2) if perim > 0 else 0
        hull = cv2.convexHull(c)
        hull_area = cv2.contourArea(hull)
        solidity = area / hull_area if hull_area > 0 else 0
        x, y, wb, hb = cv2.boundingRect(c)
        aspect = max(wb, hb) / max(1, min(wb, hb))
        convexity = cv2.arcLength(hull, True) / perim if perim > 0 else 0
        if circularity >= min_circ and solidity >= min_solid and aspect <= max_aspect and convexity >= min_conv:
            out[seg_labels == label] = 255
            kept.append(c)
    return out, kept


def local_contrast_rescue(candidate_binary, gray_or_channel, roi, ring_px=6, min_z=3.0, max_seed_area=40):
    """Per-instance local-neighbourhood validation for minute candidates.
    Re-examines each small candidate against its OWN local surrounding
    annulus rather than a single image-wide statistical cutoff. Used in
    two modes by the caller (segmentation stage): "trim" (can only
    remove candidates -- always safe) and "relaxed" (re-examines a
    second, more permissive candidate set to catch faint defects the
    main threshold missed)."""
    if candidate_binary.max() == 0:
        return candidate_binary
    n, labels, stats, _ = cv2.connectedComponentsWithStats(candidate_binary, connectivity=8)
    out = np.zeros_like(candidate_binary)
    k_ring = 2 * ring_px + 1
    ring_kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k_ring, k_ring))
    H, W = candidate_binary.shape
    for i in range(1, n):
        area = stats[i, cv2.CC_STAT_AREA]
        if area > max_seed_area:
            out[labels == i] = 255
            continue
        x, y, wc, hc = (stats[i, cv2.CC_STAT_LEFT], stats[i, cv2.CC_STAT_TOP],
                        stats[i, cv2.CC_STAT_WIDTH], stats[i, cv2.CC_STAT_HEIGHT])
        x0, y0 = max(0, x - ring_px), max(0, y - ring_px)
        x1, y1 = min(W, x + wc + ring_px), min(H, y + hc + ring_px)
        comp_patch = (labels[y0:y1, x0:x1] == i).astype(np.uint8) * 255
        dilated = cv2.dilate(comp_patch, ring_kernel)
        annulus = (dilated > 0) & (comp_patch == 0) & (roi[y0:y1, x0:x1] > 0)
        if annulus.sum() < 8:
            out[labels == i] = 255  # not enough local context to judge -- fail open
            continue
        local_vals = gray_or_channel[y0:y1, x0:x1][annulus]
        local_mu, local_sigma = float(local_vals.mean()), float(local_vals.std()) + 1e-6
        blob_val = float(gray_or_channel[labels == i].mean())
        z = abs(blob_val - local_mu) / local_sigma
        if z >= min_z:
            out[labels == i] = 255
    return out


def region_properties_table(final_mask, intensity_image, polarity_label):
    """skimage.measure.regionprops-based summary of every final defect --
    one row per defect. Returned as a list of plain dicts (no pandas
    dependency) so callers can write CSV/JSON directly or hand it to a
    future ML feature pipeline unchanged."""
    labeled = sk_label(final_mask > 0, connectivity=2)
    rows = []
    for rp in regionprops(labeled, intensity_image=intensity_image):
        equiv_diam = getattr(rp, "equivalent_diameter_area", None)
        if equiv_diam is None:
            equiv_diam = rp.equivalent_diameter
        mean_i = getattr(rp, "intensity_mean", None)
        mean_i = float(mean_i) if mean_i is not None else float(rp.mean_intensity)
        max_i = getattr(rp, "intensity_max", None)
        max_i = float(max_i) if max_i is not None else float(rp.max_intensity)
        min_i = getattr(rp, "intensity_min", None)
        min_i = float(min_i) if min_i is not None else float(rp.min_intensity)
        rows.append(dict(
            polarity=polarity_label,
            label=int(rp.label),
            area_px=int(rp.area),
            centroid_row=float(rp.centroid[0]),
            centroid_col=float(rp.centroid[1]),
            bbox=tuple(int(v) for v in rp.bbox),
            eccentricity=float(rp.eccentricity),
            solidity=float(rp.solidity),
            extent=float(rp.extent),
            equivalent_diameter=float(equiv_diam),
            orientation=float(rp.orientation),
            mean_intensity=mean_i,
            max_intensity=max_i,
            min_intensity=min_i,
        ))
    return rows


# ======================================================================
# SECTION 7 -- segmentation (Stage 3)
# ======================================================================
#
# Turn an enhancement channel into a labeled set of candidate defect
# regions. Three bands are run per polarity (bright, dark): "fine" and
# "coarse" DoG-based bands, and the "extent" h-dome/h-minima band -- all
# three funnel through the same threshold -> connected-components ->
# watershed pipeline (`detect_band`).
#
# Thresholding uses adaptive mean+k*std (NOT Otsu -- Otsu assumes a
# roughly bimodal histogram; the actual DoG-band channel data is
# zero-inflated and decays in a single steep tail, so Otsu selected a
# threshold classifying 15.4% of pixels as "foreground" on a real test
# image, versus 0.2% for mean+k*std with k=7 -- see
# CALIBRATION_REPORT.md).


def adaptive_threshold(channel_f32, mask_roi, k, robust=False):
    """mean + k*std (or, if robust=True, median + k*MAD) of the
    channel's own histogram inside the ROI. `robust=True` must only be
    used on non-zero-inflated data -- using it on the zero-inflated DoG
    channel was tried and caused a large false-positive spike during
    development (mean/MAD collapses toward 0 on a mostly-zero
    distribution)."""
    vals = channel_f32[mask_roi > 0]
    if vals.size == 0:
        return 1e6
    if robust:
        mu, sigma = robust_mu_sigma(vals)
    else:
        mu, sigma = float(vals.mean()), float(vals.std())
    return mu + k * sigma


def build_markers(binary_u8, min_distance):
    """Distance-transform peak markers for watershed."""
    dist = cv2.distanceTransform(binary_u8, cv2.DIST_L2, 5)
    coords = peak_local_max(dist, min_distance=max(1, min_distance), labels=binary_u8)
    markers = np.zeros(binary_u8.shape, dtype=np.int32)
    for idx, pt in enumerate(coords):
        markers[pt[0], pt[1]] = idx + 1
    if markers.max() == 0 and binary_u8.max() > 0:
        _, markers = cv2.connectedComponents(binary_u8)
    return markers, dist


def watershed_segment(channel_f32, binary_u8, markers, compactness=0.0):
    surface = -channel_f32
    return watershed(surface, markers, mask=binary_u8, compactness=compactness)


def detect_band(channel, roi, noise_k, min_component_area, local_max_min_dist,
                 compactness, min_area, max_area, min_circ, min_solid, max_aspect, min_conv,
                 close_radius=0, robust=False):
    """One full band's worth of Stage 3+4: threshold -> area filter ->
    morphological closing/hole-fill -> watershed -> shape filter. Shared
    by the fine, coarse, and extent bands."""
    thr = adaptive_threshold(channel, roi, noise_k, robust=robust)
    binary = ((channel > thr) & (roi > 0)).astype(np.uint8) * 255
    binary = remove_small_components(binary, min_component_area)
    binary = close_and_fill(binary, close_radius)
    if binary.max() == 0:
        return dict(mask=np.zeros(channel.shape, np.uint8), contours=[], binary=binary, channel=channel, thr=thr)
    markers, dist = build_markers(binary, local_max_min_dist)
    seg = watershed_segment(channel, binary, markers, compactness)
    mask, contours = shape_filter(seg, min_area, max_area, min_circ, min_solid, max_aspect, min_conv)
    return dict(mask=mask, contours=contours, binary=binary, channel=channel, thr=thr)


def run_multiband_detection(denoised, dog_fine, dog_coarse, roi, params):
    """Stage 3 orchestrator for BOTH polarities: builds the fine/coarse/
    extent bands, unions their masks, and (optionally) runs the
    minute-defect rescue pass. Returns a dict keyed by 'bright'/'dark'.
    """
    roi_vals = denoised[roi > 0]
    if roi_vals.size == 0:
        roi_vals = denoised.reshape(-1)
    _, base_sigma = robust_mu_sigma(roi_vals)

    results = {}
    for polarity, sign in (("bright", 1.0), ("dark", -1.0)):
        band_defs = [
            ("fine", dog_fine, params["noise_k_fine"], params["min_component_area_fine"],
             params["close_radius_fine"], params["local_max_min_dist"]),
            ("coarse", dog_coarse, params["noise_k_coarse"], params["min_component_area_coarse"],
             params["close_radius_coarse"], params["local_max_min_dist"]),
        ]
        band_results = {}
        for name, dog_band, k, min_comp_area, close_r, mdist in band_defs:
            channel = np.clip(sign * dog_band, 0, None)
            channel = opening_by_reconstruction(channel, int(params["recon_radius"]))
            band_results[name] = detect_band(
                channel, roi, k, min_comp_area, mdist, params["compactness"],
                params["min_area"], params["max_area"], params["min_circularity"], params["min_solidity"],
                params["max_aspect_ratio"], params["min_convexity"], close_radius=close_r, robust=False,
            )

        extent_depth = params["extent_k"] * base_sigma
        extent_channel = hdome_response(sign * denoised, extent_depth)
        band_results["extent"] = detect_band(
            extent_channel, roi, 0.0, params["min_component_area_extent"], params["local_max_min_dist_extent"],
            params["compactness"], params["min_area"], params["max_area"], params["min_circularity"],
            params["min_solidity"], params["max_aspect_ratio"], params["min_convexity"],
            close_radius=params["close_radius_extent"], robust=False,
        )
        # k=0 here is deliberate: hdome_response() is already zero outside a
        # region at least `extent_depth` above/below its local baseline, so a
        # second global cutoff on top would reintroduce a single whole-image
        # number -- exactly what this band exists to avoid.

        combined_mask = band_results["fine"]["mask"]
        for name in ("coarse", "extent"):
            combined_mask = cv2.bitwise_or(combined_mask, band_results[name]["mask"])

        if params.get("micro_rescue_trim_enabled", True):
            combined_mask = local_contrast_rescue(
                combined_mask, denoised, roi,
                ring_px=params["micro_rescue_ring_px"], min_z=params["micro_rescue_min_z"],
                max_seed_area=params["micro_rescue_max_area"],
            )
        if params.get("micro_rescue_relaxed_enabled", True):
            relaxed_channel = band_results["fine"]["channel"]
            relaxed_thr = adaptive_threshold(relaxed_channel, roi, max(1.0, params["noise_k_fine"] - 1.5), robust=False)
            relaxed_binary = ((relaxed_channel > relaxed_thr) & (roi > 0)).astype(np.uint8) * 255
            relaxed_binary = remove_small_components(relaxed_binary, max(1, params["min_component_area_fine"] // 2))
            rescued = local_contrast_rescue(
                relaxed_binary, denoised, roi,
                ring_px=params["micro_rescue_ring_px"], min_z=params["micro_rescue_min_z"] + 0.5,
                max_seed_area=params["micro_rescue_max_area"],
            )
            combined_mask = cv2.bitwise_or(combined_mask, rescued)

        combined_contours, _ = cv2.findContours(combined_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        results[polarity] = dict(mask=combined_mask, contours=list(combined_contours), bands=band_results)

    return results


# ======================================================================
# SECTION 8 -- visualization
# ======================================================================
#
# Turn detection results into images a human looks at. No detection
# logic lives here -- this section only draws.


def dog_to_colormap(dog, clip_std=3.0):
    """Diverging visualization of a signed DoG response: blue-ish for
    the dark lobe, red/warm for the bright lobe, via JET after
    symmetric clipping at `clip_std` standard deviations (purely
    cosmetic)."""
    mu, sigma = float(dog.mean()), float(dog.std() + 1e-6)
    clipped = np.clip(dog, mu - clip_std * sigma, mu + clip_std * sigma)
    norm = cv2.normalize(clipped, None, 0, 255, cv2.NORM_MINMAX, dtype=cv2.CV_8U)
    return cv2.applyColorMap(norm, cv2.COLORMAP_JET)


def draw_roi_outline(bgr_img, roi_polygon_norm, color=(0, 229, 255), thickness=2):
    """Outline the active ROI polygon (if any) on a display copy.
    Purely cosmetic -- never affects detection. Returns a NEW array;
    does not mutate the input."""
    if not roi_polygon_norm or len(roi_polygon_norm) < 3:
        return bgr_img
    h, w = bgr_img.shape[:2]
    pts = np.array([(fx * w, fy * h) for (fx, fy) in roi_polygon_norm], dtype=np.int32)
    out = bgr_img.copy()
    cv2.polylines(out, [pts], isClosed=True, color=color, thickness=thickness)
    return out


def draw_defect_overlay(base_gray_u8, bright_contours, dark_contours,
                         bright_color=(0, 0, 255), dark_color=(0, 140, 255)):
    """Compose the unified overlay: bright defects in `bright_color`
    (default red, BGR), dark defects in `dark_color` (default orange,
    BGR), filled contours, on top of the grayscale base converted to
    3-channel."""
    rgb = cv2.cvtColor(base_gray_u8, cv2.COLOR_GRAY2BGR)
    cv2.drawContours(rgb, bright_contours, -1, bright_color, -1)
    cv2.drawContours(rgb, dark_contours, -1, dark_color, -1)
    return rgb


def draw_single_polarity_overlay(base_gray_u8, contours, color=(0, 0, 255)):
    rgb = cv2.cvtColor(base_gray_u8, cv2.COLOR_GRAY2BGR)
    cv2.drawContours(rgb, contours, -1, color, -1)
    return rgb


# ======================================================================
# SECTION 9 -- pipeline (top-level orchestrator)
# ======================================================================
#
# This is the ONLY place that wires preprocessing -> enhancement ->
# segmentation -> postprocessing -> visualization together. Both the
# GUI's live preview and its batch export call `run_pipeline()` and
# nothing else, so there is exactly one implementation to keep in sync.
#
# WHAT THIS FUNCTION DELIBERATELY DOES NOT DO
# ---------------------------------------------
# * No perspective correction, deskew, rotation, or automatic crop.
# * No automatic ROI detection -- `roi_polygon` is always either None
#   (process the complete image) or exactly what a human operator drew
#   in the ROI editor.
# * No resizing before or during detection -- every array from
#   `load_image_no_transform()` onward keeps its original shape all the
#   way through. The only resize in the whole application is
#   `resize_for_display()`, and this function never calls it.


def run_pipeline(image_path, params, roi_polygon=None):
    """Full pipeline entry point, used identically by live preview and
    batch/single export.

    image_path: path to the ORIGINAL image file. Loaded via
        `load_image_no_transform` -- no crop/rotate/resize.
    params: parameter dict (see DEFAULT_PARAMS for the full set).
    roi_polygon: None (process the complete image) or a list of
        normalized (x_frac, y_frac) points from the manual ROI editor.

    Returns a dict with every intermediate stage's output (for the live
    preview panels) plus the final masks/contours/region-properties
    table (for export). Every array in the returned dict has the SAME
    (height, width) as the original image -- nothing was cropped.
    """
    bgr = load_image_no_transform(image_path)
    gray = to_grayscale(bgr)
    h, w = gray.shape[:2]

    # Base ROI: the complete image unless the user drew a polygon.
    roi = polygon_to_mask((h, w), roi_polygon)

    pre = preprocess(gray, params)
    enh = compute_enhancement_channels(pre["denoised"], params)
    det = run_multiband_detection(pre["denoised"], enh["dog_fine"], enh["dog_coarse"], roi, params)

    final_mask = cv2.bitwise_or(det["bright"]["mask"], det["dark"]["mask"])
    dog_combined = enh["dog_fine"] + enh["dog_coarse"]

    final_overlay = draw_defect_overlay(gray, det["bright"]["contours"], det["dark"]["contours"])
    bright_overlay = draw_single_polarity_overlay(gray, det["bright"]["contours"], color=(0, 0, 255))
    dark_overlay = draw_single_polarity_overlay(gray, det["dark"]["contours"], color=(0, 0, 255))

    region_table = (
        region_properties_table(det["bright"]["mask"], pre["denoised"], "bright")
        + region_properties_table(det["dark"]["mask"], pre["denoised"], "dark")
    )

    return dict(
        bgr=bgr, gray=gray, roi=roi,
        background=pre["background"], normalized=pre["normalized"], denoised=pre["denoised"],
        clahe_view=pre["clahe_view"],
        dog_fine=enh["dog_fine"], dog_coarse=enh["dog_coarse"], dog_combined=dog_combined,
        bright=det["bright"], dark=det["dark"],
        final_mask=final_mask, final_overlay=final_overlay,
        bright_overlay=bright_overlay, dark_overlay=dark_overlay,
        region_table=region_table,
    )


# ======================================================================
# SECTION 10 -- GUI
# ======================================================================

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")


class CTkSpinbox(ctk.CTkFrame):
    def __init__(self, parent, from_val, to_val, current_val, is_float=False, resolution=1, linked_var=None, on_update_callback=None):
        super().__init__(parent, fg_color="transparent")
        self.from_val = from_val
        self.to_val = to_val
        self.is_float = is_float
        self.resolution = resolution
        self.linked_var = linked_var
        self.callback = on_update_callback

        self.btn_down = ctk.CTkButton(self, text="\u25bc", width=28, height=28, font=("Arial", 10),
                                       fg_color="#37474f", hover_color="#263238", command=self.decrement)
        self.btn_down.pack(side=tk.LEFT, padx=2)
        self.entry = ctk.CTkEntry(self, width=65, height=28, font=('Helvetica', 12), justify='center')
        self.entry.insert(0, f"{current_val:.2f}" if self.is_float else str(int(current_val)))
        self.entry.pack(side=tk.LEFT, padx=2)
        self.btn_up = ctk.CTkButton(self, text="\u25b2", width=28, height=28, font=("Arial", 10),
                                     fg_color="#37474f", hover_color="#263238", command=self.increment)
        self.btn_up.pack(side=tk.LEFT, padx=2)

    def get_value(self):
        try:
            return float(self.entry.get()) if self.is_float else int(float(self.entry.get()))
        except ValueError:
            return self.from_val

    def set_value(self, val):
        self.entry.delete(0, tk.END)
        self.entry.insert(0, f"{val:.2f}" if self.is_float else str(int(val)))
        if self.linked_var:
            self.linked_var.set(val)

    def increment(self):
        new_val = np.clip(self.get_value() + self.resolution, self.from_val, self.to_val)
        self.set_value(new_val)
        if self.callback:
            self.callback()

    def decrement(self):
        new_val = np.clip(self.get_value() - self.resolution, self.from_val, self.to_val)
        self.set_value(new_val)
        if self.callback:
            self.callback()


class ROIPolygonEditor(ctk.CTkToplevel):
    """Click to add a vertex, drag to move one, right-click to delete one.

    Left click on empty canvas   -> add a vertex at that point
    Left click + drag a vertex   -> move that vertex
    Right click near a vertex    -> delete that vertex
    'Clear Points'                -> discard all vertices (start over)
    'Confirm ROI'                 -> apply the polygon (or, if empty,
                                      apply "no ROI restriction" -- i.e.
                                      process the complete image)
    'Cancel'                       -> close without changing anything

    Calls `on_confirm(normalized_points_or_None)` exactly once, only if
    the user actually confirms or explicitly clears -- Cancel calls
    nothing, leaving any previously-confirmed ROI untouched.

    This editor is shown a (possibly downsized, for on-screen display
    only) COPY of the full raw image via `resize_for_display`. It never
    receives a cropped or rotated image -- the full frame, at whatever
    display scale, is always what the user is drawing on.
    """

    HANDLE_RADIUS = 5
    HIT_RADIUS = 10
    MAX_DISPLAY_DIM = 900

    def __init__(self, parent, full_bgr_image, existing_polygon_norm, on_confirm):
        super().__init__(parent)
        self.title("Define Processing ROI \u2014 click to add points, drag to move, right-click to delete")
        self.on_confirm = on_confirm
        self.dragging_idx = None

        disp_img = resize_for_display(full_bgr_image, self.MAX_DISPLAY_DIM)
        self.disp_h, self.disp_w = disp_img.shape[:2]

        rgb = cv2.cvtColor(disp_img, cv2.COLOR_BGR2RGB)
        # Kept as an instance attribute -- PhotoImage is garbage-collected
        # (and the canvas goes blank) if no Python reference survives.
        self.tk_photo = ImageTk.PhotoImage(Image.fromarray(rgb))

        self.canvas = tk.Canvas(self, width=self.disp_w, height=self.disp_h,
                                 cursor="tcross", bg="black", highlightthickness=0)
        self.canvas.pack(padx=10, pady=10)
        self.canvas.create_image(0, 0, anchor="nw", image=self.tk_photo)

        if existing_polygon_norm:
            self.points = [(fx * self.disp_w, fy * self.disp_h) for (fx, fy) in existing_polygon_norm]
        else:
            self.points = []

        hint = ctk.CTkLabel(
            self, text="Left-click: add point   |   Drag: move point   |   Right-click: delete point",
            font=('Helvetica', 11, 'italic'), text_color="#90a4ae")
        hint.pack(pady=(0, 5))

        btn_row = ctk.CTkFrame(self, fg_color="transparent")
        btn_row.pack(pady=(0, 10))
        ctk.CTkButton(btn_row, text="Clear Points", fg_color="#546e7a", hover_color="#37474f",
                      command=self.clear_points).pack(side=tk.LEFT, padx=8)
        ctk.CTkButton(btn_row, text="\u2713 Confirm ROI", fg_color="#2e7d32", hover_color="#1b5e20",
                      command=self.confirm).pack(side=tk.LEFT, padx=8)
        ctk.CTkButton(btn_row, text="Cancel", fg_color="#8d1e1e", hover_color="#5c1414",
                      command=self.destroy).pack(side=tk.LEFT, padx=8)

        self.canvas.bind("<Button-1>", self.on_left_click)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)
        self.canvas.bind("<Button-3>", self.on_right_click)

        self.redraw()
        self.grab_set()  # modal-ish: keep focus on the editor while it's open

    def find_nearest_point(self, x, y):
        best_idx, best_dist = None, self.HIT_RADIUS
        for i, (px, py) in enumerate(self.points):
            d = ((px - x) ** 2 + (py - y) ** 2) ** 0.5
            if d <= best_dist:
                best_dist, best_idx = d, i
        return best_idx

    def on_left_click(self, event):
        idx = self.find_nearest_point(event.x, event.y)
        if idx is not None:
            self.dragging_idx = idx
        else:
            self.points.append((event.x, event.y))
            self.redraw()

    def on_drag(self, event):
        if self.dragging_idx is not None:
            x = min(max(event.x, 0), self.disp_w)
            y = min(max(event.y, 0), self.disp_h)
            self.points[self.dragging_idx] = (x, y)
            self.redraw()

    def on_release(self, _event):
        self.dragging_idx = None

    def on_right_click(self, event):
        idx = self.find_nearest_point(event.x, event.y)
        if idx is not None:
            del self.points[idx]
            self.redraw()

    def redraw(self):
        self.canvas.delete("roi_shape")
        if len(self.points) >= 3:
            flat = [c for pt in self.points for c in pt]
            self.canvas.create_polygon(flat, outline="#00e5ff", fill="#00e5ff", stipple="gray12",
                                        width=2, tags="roi_shape")
        elif len(self.points) == 2:
            flat = [c for pt in self.points for c in pt]
            self.canvas.create_line(flat, fill="#00e5ff", width=2, tags="roi_shape")
        for (x, y) in self.points:
            r = self.HANDLE_RADIUS
            self.canvas.create_oval(x - r, y - r, x + r, y + r, fill="#ff4081",
                                     outline="white", tags="roi_shape")

    def clear_points(self):
        self.points = []
        self.redraw()

    def confirm(self):
        if len(self.points) == 0:
            self.on_confirm(None)  # explicit clear -- process the full image
            self.destroy()
            return
        if len(self.points) < 3:
            messagebox.showwarning("ROI", "Place at least 3 points to define a polygon (or clear all points to process the full image).")
            return
        norm = [(x / self.disp_w, y / self.disp_h) for (x, y) in self.points]
        self.on_confirm(norm)
        self.destroy()


class PBFInspectorWorkstation(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("PBF Powder-Bed Inspection Workstation \u2014 Modular Classical CV Engine")
        self.geometry("1650x1060")

        self.image_path = None
        self.folder_path = None
        self.max_display_dim = 900  # display only -- see resize_for_display
        self.updating_ui = False
        self.params = {}
        self.roi_polygon = None
        self.roi_confirmed_or_skipped = False  # gates all processing

        self.setup_ui()

    # ---------------- UI construction ----------------

    def setup_ui(self):
        top_bar = ctk.CTkFrame(self, height=60, corner_radius=0)
        top_bar.pack(side=tk.TOP, fill=tk.X)

        ctk.CTkButton(top_bar, text="\U0001F4C2 Load Single Image", command=self.load_image_action,
                      font=('Helvetica', 12, 'bold'), fg_color="#0288d1", hover_color="#01579b").pack(side=tk.LEFT, padx=15, pady=10)
        ctk.CTkButton(top_bar, text="\U0001F4C1 Load Batch Folder", command=self.load_folder_action,
                      font=('Helvetica', 12, 'bold'), fg_color="#ff8f00", hover_color="#c67100").pack(side=tk.LEFT, padx=10, pady=10)
        ctk.CTkButton(top_bar, text="\U0001F53A Define ROI", command=self.open_roi_editor,
                      font=('Helvetica', 12, 'bold'), fg_color="#6a1b9a", hover_color="#4a148c").pack(side=tk.LEFT, padx=10, pady=10)
        ctk.CTkButton(top_bar, text="Process Full Image (No ROI)", command=self.process_full_image,
                      font=('Helvetica', 12), fg_color="#455a64", hover_color="#263238").pack(side=tk.LEFT, padx=10, pady=10)
        ctk.CTkButton(top_bar, text="\u2715 Clear ROI", command=self.clear_roi,
                      font=('Helvetica', 12), fg_color="#546e7a", hover_color="#37474f", width=90).pack(side=tk.LEFT, padx=(0, 10), pady=10)

        self.path_lbl = ctk.CTkLabel(top_bar, text="No source files loaded.", font=('Helvetica', 12, 'italic'), text_color="#90a4ae")
        self.path_lbl.pack(side=tk.LEFT, padx=15)

        self.viewport_frame = ctk.CTkFrame(self, corner_radius=10, fg_color="#1e1e1e")
        self.viewport_frame.pack(side=tk.TOP, fill=tk.BOTH, expand=True, padx=15, pady=10)
        for i in range(6):
            self.viewport_frame.columnconfigure(i, weight=1, uniform="viewport")
        self.viewport_frame.rowconfigure(1, weight=1)

        titles = [
            "1. Raw Input (complete, untouched)",
            "2. CLAHE View (operator aid only)",
            "3. DoG Response (warm=bright / cool=dark)",
            "4. Bright Defects (Red)",
            "5. Dark Defects (Red)",
            "6. Unified Output (Bright=Red, Dark=Orange)",
        ]
        self.view_labels = []
        for i, t in enumerate(titles):
            ctk.CTkLabel(self.viewport_frame, text=t, font=('Helvetica', 11, 'bold'), text_color="white").grid(row=0, column=i, pady=(10, 5), sticky="ew")
            view = ctk.CTkLabel(self.viewport_frame, text="Load an image to begin.", text_color="#616161")
            view.grid(row=1, column=i, padx=3, pady=5, sticky="nsew")
            self.view_labels.append(view)

        control_panel = ctk.CTkFrame(self, height=400)
        control_panel.pack(side=tk.BOTTOM, fill=tk.X, padx=15, pady=15)

        self.tabview = ctk.CTkTabview(control_panel, height=380)
        self.tabview.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=10, pady=5)

        self.tab_illum = self.tabview.add(" Tab 1 \u2014 Preprocessing ")
        self.tab_dog = self.tabview.add(" Tab 2 \u2014 Enhancement (DoG) ")
        self.tab_sens = self.tabview.add(" Tab 3 \u2014 Segmentation Sensitivity ")
        self.tab_filter = self.tabview.add(" Tab 4 \u2014 Shape Filtering ")
        self.tab_extent = self.tabview.add(" Tab 5 \u2014 Full-Extent Band ")
        self.tab_rescue = self.tabview.add(" Tab 6 \u2014 Minute-Defect Rescue ")

        self.build_tabs_layout()

        right_bar = ctk.CTkFrame(control_panel, width=240, fg_color="transparent")
        right_bar.pack(side=tk.RIGHT, fill=tk.Y, padx=10, pady=10)
        self.export_btn = ctk.CTkButton(right_bar, text="\U0001F4BE Export Output\n(Single or Batch Folder)", command=self.start_async_export,
                                         font=('Helvetica', 12, 'bold'), fg_color="#2e7d32", hover_color="#1b5e20")
        self.export_btn.pack(fill=tk.BOTH, expand=True, pady=10)

    def create_parameter_row(self, parent, key, label_text, from_val, to_val, current_val, row_idx, is_float=False, resolution=1):
        ctk.CTkLabel(parent, text=label_text, font=('Helvetica', 11), anchor='w').grid(row=row_idx, column=0, sticky='w', pady=3, padx=10)
        var = tk.DoubleVar(value=current_val) if is_float else tk.IntVar(value=current_val)
        self.params[key] = var
        slider = ctk.CTkSlider(parent, from_=from_val, to=to_val, number_of_steps=max(1, int((to_val - from_val) / resolution)), variable=var)
        slider.grid(row=row_idx, column=1, sticky='ew', padx=20, pady=3)
        spinbox = CTkSpinbox(parent, from_val, to_val, current_val, is_float, resolution, linked_var=var, on_update_callback=self.trigger_refresh)
        spinbox.grid(row=row_idx, column=2, padx=10, pady=3)
        slider.bind("<ButtonRelease-1>", lambda e: self.sync_slider_to_spinbox(var, spinbox))
        spinbox.entry.bind("<Return>", lambda e: self.sync_spinbox_to_slider(spinbox, var, from_val, to_val))
        parent.columnconfigure(1, weight=1)

    def create_toggle_row(self, parent, key, label_text, current_val, row_idx):
        ctk.CTkLabel(parent, text=label_text, font=('Helvetica', 11), anchor='w').grid(row=row_idx, column=0, sticky='w', pady=3, padx=10)
        var = tk.BooleanVar(value=current_val)
        self.params[key] = var
        ctk.CTkSwitch(parent, text="", variable=var, command=self.trigger_refresh).grid(row=row_idx, column=1, sticky='w', padx=20, pady=3)

    def sync_slider_to_spinbox(self, var, spinbox):
        if self.updating_ui:
            return
        self.updating_ui = True
        spinbox.set_value(var.get())
        self.updating_ui = False
        self.trigger_refresh()

    def sync_spinbox_to_slider(self, spinbox, var, from_val, to_val):
        if self.updating_ui:
            return
        self.updating_ui = True
        val = spinbox.get_value()
        if from_val <= val <= to_val:
            var.set(val)
            self.updating_ui = False
            self.trigger_refresh()
            return
        else:
            messagebox.showwarning("Out of Bounds", f"Value must be between {from_val} and {to_val}")
        self.updating_ui = False

    def build_tabs_layout(self):
        dp = DEFAULT_PARAMS
        self.create_parameter_row(self.tab_illum, "bg_sigma", "Background Gaussian Sigma (Illumination Scale):", 10.0, 150.0, dp["bg_sigma"], 0, is_float=True, resolution=5.0)
        self.create_parameter_row(self.tab_illum, "bilat_d", "Bilateral Filter Diameter:", 1, 25, dp["bilat_d"], 1, resolution=1)
        self.create_parameter_row(self.tab_illum, "bilat_sc", "Bilateral Sigma Color:", 5.0, 200.0, dp["bilat_sc"], 2, is_float=True, resolution=5.0)
        self.create_parameter_row(self.tab_illum, "bilat_ss", "Bilateral Sigma Space:", 5.0, 200.0, dp["bilat_ss"], 3, is_float=True, resolution=5.0)

        self.create_parameter_row(self.tab_dog, "fine_sigma1", "Fine Band Sigma 1:", 0.3, 5.0, dp["fine_sigma1"], 0, is_float=True, resolution=0.1)
        self.create_parameter_row(self.tab_dog, "fine_sigma2", "Fine Band Sigma 2:", 1.0, 10.0, dp["fine_sigma2"], 1, is_float=True, resolution=0.2)
        self.create_parameter_row(self.tab_dog, "coarse_sigma1", "Coarse Band Sigma 1:", 1.0, 20.0, dp["coarse_sigma1"], 2, is_float=True, resolution=0.5)
        self.create_parameter_row(self.tab_dog, "coarse_sigma2", "Coarse Band Sigma 2:", 5.0, 60.0, dp["coarse_sigma2"], 3, is_float=True, resolution=1.0)
        self.create_parameter_row(self.tab_dog, "recon_radius", "Speckle Reconstruction Radius (px):", 0, 5, dp["recon_radius"], 4, resolution=1)

        self.create_parameter_row(self.tab_sens, "noise_k_fine", "Fine-Band Sensitivity (mean + k\u00b7std):", 1.0, 12.0, dp["noise_k_fine"], 0, is_float=True, resolution=0.1)
        self.create_parameter_row(self.tab_sens, "noise_k_coarse", "Coarse-Band Sensitivity (mean + k\u00b7std):", 1.0, 12.0, dp["noise_k_coarse"], 1, is_float=True, resolution=0.1)
        self.create_parameter_row(self.tab_sens, "min_component_area_fine", "Fine-Band Min Component Area (px):", 1, 100, dp["min_component_area_fine"], 2, resolution=1)
        self.create_parameter_row(self.tab_sens, "min_component_area_coarse", "Coarse-Band Min Component Area (px):", 5, 500, dp["min_component_area_coarse"], 3, resolution=5)
        self.create_parameter_row(self.tab_sens, "local_max_min_dist", "Watershed Marker Min Distance (px):", 1, 30, dp["local_max_min_dist"], 4, resolution=1)
        self.create_parameter_row(self.tab_sens, "compactness", "Watershed Compactness:", 0.0, 5.0, dp["compactness"], 5, is_float=True, resolution=0.1)

        self.create_parameter_row(self.tab_filter, "min_area", "Minimum Area (Pixels):", 1, 5000, dp["min_area"], 0, resolution=1)
        self.create_parameter_row(self.tab_filter, "max_area", "Maximum Area (Pixels):", 100, 50000, dp["max_area"], 1, resolution=100)
        self.create_parameter_row(self.tab_filter, "min_circularity", "Minimum Circularity:", 0.0, 1.0, dp["min_circularity"], 2, is_float=True, resolution=0.05)
        self.create_parameter_row(self.tab_filter, "min_solidity", "Minimum Solidity:", 0.0, 1.0, dp["min_solidity"], 3, is_float=True, resolution=0.05)
        self.create_parameter_row(self.tab_filter, "max_aspect_ratio", "Maximum Aspect Ratio:", 1.0, 20.0, dp["max_aspect_ratio"], 4, is_float=True, resolution=0.5)
        self.create_parameter_row(self.tab_filter, "min_convexity", "Minimum Convexity:", 0.0, 1.0, dp["min_convexity"], 5, is_float=True, resolution=0.05)

        self.create_parameter_row(self.tab_extent, "extent_k", "Full-Extent Sensitivity (h-dome depth, k\u00b7\u03c3):", 0.5, 10.0, dp["extent_k"], 0, is_float=True, resolution=0.1)
        self.create_parameter_row(self.tab_extent, "min_component_area_extent", "Full-Extent Min Component Area (px):", 10, 5000, dp["min_component_area_extent"], 1, resolution=10)
        self.create_parameter_row(self.tab_extent, "local_max_min_dist_extent", "Full-Extent Watershed Marker Min Distance (px):", 1, 60, dp["local_max_min_dist_extent"], 2, resolution=1)
        self.create_parameter_row(self.tab_extent, "close_radius_fine", "Closing Radius \u2014 Fine Band (px):", 0, 8, dp["close_radius_fine"], 3, resolution=1)
        self.create_parameter_row(self.tab_extent, "close_radius_coarse", "Closing Radius \u2014 Coarse Band (px):", 0, 8, dp["close_radius_coarse"], 4, resolution=1)
        self.create_parameter_row(self.tab_extent, "close_radius_extent", "Closing Radius \u2014 Extent Band (px):", 0, 12, dp["close_radius_extent"], 5, resolution=1)

        self.create_toggle_row(self.tab_rescue, "micro_rescue_trim_enabled", "Enable Trim Pass (safe, only removes candidates):", dp["micro_rescue_trim_enabled"], 0)
        self.create_toggle_row(self.tab_rescue, "micro_rescue_relaxed_enabled", "Enable Relaxed Pass (adds faint-defect recall, more candidates):", dp["micro_rescue_relaxed_enabled"], 1)
        self.create_parameter_row(self.tab_rescue, "micro_rescue_ring_px", "Local Context Ring Width (px):", 2, 20, dp["micro_rescue_ring_px"], 2, resolution=1)
        self.create_parameter_row(self.tab_rescue, "micro_rescue_min_z", "Local Contrast Sensitivity (z-score):", 1.0, 6.0, dp["micro_rescue_min_z"], 3, is_float=True, resolution=0.1)
        self.create_parameter_row(self.tab_rescue, "micro_rescue_max_area", "Max Area Considered 'Minute' (px):", 5, 300, dp["micro_rescue_max_area"], 4, resolution=5)

    # ---------------- ROI wiring ----------------

    def open_roi_editor(self):
        if not self.image_path:
            messagebox.showwarning("Define ROI", "Load a single image or batch folder first.")
            return
        try:
            img = load_image_no_transform(self.image_path)
        except Exception as e:
            messagebox.showerror("Define ROI", str(e))
            return
        ROIPolygonEditor(self, img, self.roi_polygon, self.on_roi_confirmed)

    def on_roi_confirmed(self, normalized_points_or_none):
        self.roi_polygon = normalized_points_or_none
        self.roi_confirmed_or_skipped = True
        self.trigger_refresh()

    def clear_roi(self):
        self.roi_polygon = None
        self.roi_confirmed_or_skipped = True
        self.trigger_refresh()

    def process_full_image(self):
        """Explicit opt-out of ROI selection -- still a deliberate user
        action, never automatic."""
        self.roi_polygon = None
        self.roi_confirmed_or_skipped = True
        self.trigger_refresh()

    # ---------------- File loading ----------------

    def load_image_action(self):
        file_path = filedialog.askopenfilename(filetypes=[("All Image Formats", "*.jpg *.jpeg *.png *.bmp *.tiff *.pgm")])
        if not file_path:
            return
        self.folder_path = None
        self.image_path = file_path
        self.path_lbl.configure(text=os.path.basename(file_path))
        self.roi_polygon = None
        self.roi_confirmed_or_skipped = False
        self.show_raw_image_only()

    def load_folder_action(self):
        folder_path = filedialog.askdirectory(title="Select Batch Folder of AM Images")
        if not folder_path:
            return
        self.image_path = None
        self.folder_path = folder_path
        files = [f for f in os.listdir(folder_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp'))]
        self.path_lbl.configure(text=f"Batch Folder: {os.path.basename(folder_path)} ({len(files)} target images)")
        if files:
            self.image_path = os.path.join(folder_path, files[0])
            self.roi_polygon = None
            self.roi_confirmed_or_skipped = False
            self.show_raw_image_only()

    def show_raw_image_only(self):
        """The complete original image must be visible BEFORE any ROI
        selection or processing happens. This renders only the raw
        panel and leaves the rest showing a prompt."""
        img = load_image_no_transform(self.image_path)
        disp = resize_for_display(img, self.max_display_dim)
        self.view_labels[0].configure(image=self._to_ctk_image(disp, "bgr"), text="")
        self.view_labels[0].image = self._to_ctk_image(disp, "bgr")
        for lbl in self.view_labels[1:]:
            lbl.configure(image=None, text="Define ROI (or 'Process Full Image') to begin.")

    def get_current_params_dict(self):
        return {k: v.get() for k, v in self.params.items()}

    # ---------------- Live preview ----------------

    def trigger_refresh(self):
        if not self.image_path or self.updating_ui or not self.roi_confirmed_or_skipped:
            return
        p_dict = self.get_current_params_dict()
        try:
            result = run_pipeline(self.image_path, p_dict, roi_polygon=self.roi_polygon)
        except Exception as e:
            messagebox.showerror("Processing Error", str(e))
            return
        self.update_viewports(result)

    def _to_ctk_image(self, arr, source="bgr"):
        if source == "bgr":
            rgb = cv2.cvtColor(arr, cv2.COLOR_BGR2RGB)
        elif source == "gray":
            rgb = cv2.cvtColor(arr, cv2.COLOR_GRAY2RGB)
        else:
            rgb = arr
        h, w = rgb.shape[:2]
        pil_img = Image.fromarray(rgb)
        return ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=(w, h))

    def update_viewports(self, result):
        # Display-only downsizing happens HERE, after detection, never
        # before -- detection above ran on the full-resolution arrays.
        raw_disp = resize_for_display(result["bgr"], self.max_display_dim)
        raw_disp = draw_roi_outline(raw_disp, self.roi_polygon)
        clahe_disp = resize_for_display(result["clahe_view"], self.max_display_dim)
        dog_colored = dog_to_colormap(result["dog_combined"])
        dog_disp = resize_for_display(dog_colored, self.max_display_dim)
        bright_disp = resize_for_display(result["bright_overlay"], self.max_display_dim)
        dark_disp = resize_for_display(result["dark_overlay"], self.max_display_dim)
        final_disp = resize_for_display(result["final_overlay"], self.max_display_dim)

        panels = [
            self._to_ctk_image(raw_disp, "bgr"),
            self._to_ctk_image(clahe_disp, "gray"),
            self._to_ctk_image(dog_disp, "bgr"),
            self._to_ctk_image(bright_disp, "bgr"),
            self._to_ctk_image(dark_disp, "bgr"),
            self._to_ctk_image(final_disp, "bgr"),
        ]
        for lbl, img in zip(self.view_labels, panels):
            lbl.configure(image=img, text="")
            lbl.image = img

    # ---------------- Export ----------------

    def start_async_export(self):
        if not self.image_path and not self.folder_path:
            messagebox.showwarning("Export Error", "Please load a single image or batch folder first.")
            return
        if not self.roi_confirmed_or_skipped:
            messagebox.showwarning("Export Error", "Define an ROI (or click 'Process Full Image') before exporting.")
            return
        selected_parent_dir = filedialog.askdirectory(title="Select Destination Folder")
        if not selected_parent_dir:
            return
        self.export_btn.configure(state="disabled", text="\u23f3 Running Batch Pool...")
        threading.Thread(target=self.background_export_worker, args=(selected_parent_dir,), daemon=True).start()

    def background_export_worker(self, target_base_path):
        try:
            p_dict = self.get_current_params_dict()
            roi_polygon = self.roi_polygon

            if self.folder_path:
                output_dir = os.path.join(target_base_path, "Output_Images")
                os.makedirs(output_dir, exist_ok=True)
                files_to_process = [
                    os.path.join(self.folder_path, f) for f in os.listdir(self.folder_path)
                    if f.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp'))
                ]
            else:
                base_filename = os.path.splitext(os.path.basename(self.image_path))[0]
                output_dir = os.path.join(target_base_path, f"pbf_inspection_{base_filename}_outputs")
                os.makedirs(output_dir, exist_ok=True)
                files_to_process = [self.image_path]

            def process_single_file(file_path):
                file_name_only = os.path.splitext(os.path.basename(file_path))[0]
                r = run_pipeline(file_path, p_dict, roi_polygon=roi_polygon)

                if self.folder_path:
                    cv2.imwrite(os.path.join(output_dir, f"{file_name_only}_segmented.png"), r["final_overlay"])
                else:
                    cv2.imwrite(os.path.join(output_dir, "01_original.png"), r["bgr"])
                    cv2.imwrite(os.path.join(output_dir, "02_normalized.png"), np.clip(r["normalized"], 0, 255).astype(np.uint8))
                    cv2.imwrite(os.path.join(output_dir, "03_clahe_view.png"), r["clahe_view"])
                    cv2.imwrite(os.path.join(output_dir, "04_denoised.png"), np.clip(r["denoised"], 0, 255).astype(np.uint8))
                    cv2.imwrite(os.path.join(output_dir, "05_dog_combined.png"), dog_to_colormap(r["dog_combined"]))
                    cv2.imwrite(os.path.join(output_dir, "06_bright_mask.png"), r["bright"]["mask"])
                    cv2.imwrite(os.path.join(output_dir, "07_dark_mask.png"), r["dark"]["mask"])
                    cv2.imwrite(os.path.join(output_dir, "08_final_mask.png"), r["final_mask"])
                    cv2.imwrite(os.path.join(output_dir, "09_roi_mask.png"), r["roi"])
                    cv2.imwrite(os.path.join(output_dir, "10_final_overlay.png"), r["final_overlay"])

                    with open(os.path.join(output_dir, "region_properties.json"), "w") as f:
                        json.dump(r["region_table"], f, indent=2)
                    save_config(os.path.join(output_dir, "parameters.json"), p_dict, roi_polygon,
                                extra={"bright_defect_count": len(r["bright"]["contours"]),
                                       "dark_defect_count": len(r["dark"]["contours"])})

            with ThreadPoolExecutor() as executor:
                executor.map(process_single_file, files_to_process)

            self.after(0, lambda: self.on_export_complete(output_dir))
        except Exception as e:
            self.after(0, lambda: self.on_export_failed(str(e)))

    def on_export_complete(self, output_dir):
        self.export_btn.configure(state="normal", text="\U0001F4BE Export Output\n(Single or Batch Folder)")
        messagebox.showinfo("Export Successful", f"Done.\nTarget Directory:\n{output_dir}")

    def on_export_failed(self, error_msg):
        self.export_btn.configure(state="normal", text="\U0001F4BE Export Output\n(Single or Batch Folder)")
        messagebox.showerror("Export Error", error_msg)


# ======================================================================
# SECTION 11 -- entry point
# ======================================================================

if __name__ == "__main__":
    app = PBFInspectorWorkstation()
    app.mainloop()
