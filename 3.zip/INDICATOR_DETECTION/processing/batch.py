"""Batch image processing + 3D visualisation (the original 'Tab 3'):
looping through an input folder, indicator classification, progress
updates, and launching the FreeCAD/3D Slicer visualisation tools.
Relocated verbatim from ImageAnalyzerApp in the original single-file
app."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from PIL import Image, ImageTk
import cv2
import numpy as np
from scipy import ndimage as ndi
from skimage.segmentation import watershed as _skimage_watershed
from skimage.morphology import disk
import copy
import json
import math
import os
import sys
import gc
import threading
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from .utils.constants import DEFAULT_PIPELINE_PARAMS


class BatchMixin:
    """
    Mixin holding methods relocated verbatim from the original
    ``ImageAnalyzerApp`` god-class. It is combined with the other
    mixins in ``app.Application`` via multiple inheritance, so every
    method below still shares the same ``self`` (and therefore the
    same widgets / state) as before -- nothing about how these
    methods call each other or access ``self.*`` attributes changed.
    """

    @staticmethod
    def _merge_pipeline_params(loaded_params):
        """Deep-merge a loaded pipeline_params dict onto a fresh copy of
        DEFAULT_PIPELINE_PARAMS. See SingleImageMixin._merge_pipeline_params
        for the full rationale (R6) -- duplicated here (rather than relying
        on MRO to find the SingleImageMixin copy) so BatchMixin does not
        implicitly depend on being combined with SingleImageMixin in a
        particular order.
        """
        merged = copy.deepcopy(DEFAULT_PIPELINE_PARAMS)
        if not isinstance(loaded_params, dict):
            return merged
        for step_key, step_defaults in merged.items():
            loaded_step = loaded_params.get(step_key)
            if isinstance(loaded_step, dict):
                step_defaults.update(loaded_step)
        return merged

    def _batch3d_pick_input_folder(self):
        """Pick input folder and auto-load config.json from Configurations/ subfolder."""
        folder_path = filedialog.askdirectory(title='Select Input Images Folder')
        if not folder_path:
            return
        self.tab3_input_folder = folder_path
        self._tab3_folder_var.set(folder_path)
        self.tab3_log(f"Input folder selected: {folder_path}")

        # Auto-load Configurations/config.json relative to the input folder
        conf_candidates = [
            os.path.join(folder_path, 'Configurations', 'config.json'),
            os.path.join(folder_path, '..', 'Configurations', 'config.json'),
            str(Path(__file__).resolve().parent / 'configurations' / 'conf.json'),
        ]
        loaded = False
        for conf_path in conf_candidates:
            conf_path = os.path.normpath(conf_path)
            if os.path.isfile(conf_path):
                try:
                    with open(conf_path, 'r') as f:
                        data = json.load(f)
                    self.tab3_config_data = data
                    if 'polygon_points' in data:
                        self.tab3_roi_points = np.array(data['polygon_points'], dtype=np.int32)
                    self.tab3_log(f"Configuration loaded successfully from: {conf_path}")
                    loaded = True
                    break
                except Exception as e:
                    self.tab3_log(f"Could not load config from {conf_path}: {e}")
        if not loaded:
            self.tab3_log("Configuration file not found   will use defaults.")

    def _batch3d_stop(self):
        """Signal running task to stop."""
        self._batch3d_stop_flag = True
        self.tab3_processing = False
        self.tab3_log("Operation cancelled by user.")
        self._batch3d_status_lbl.config(text='Stopped')

    def _batch3d_clear(self):
        """Clear all UI inputs and status without deleting output files."""
        self._tab3_folder_var.set('Not selected')
        self._batch3d_stl_var.set('Not selected')
        self._tab3_output_var.set('Not selected')
        self.tab3_input_folder = None
        self._batch3d_set_progress(0)
        self._batch3d_status_lbl.config(text='Ready')
        self.tab3_log_text.delete('1.0', tk.END)
        self._batch3d_report_link_btn.config(
            text='No report generated yet', fg=self.FG2, cursor='arrow')
        self._latest_report_path = None
        self.tab3_log("UI cleared successfully.")

    def _batch3d_start(self):
        """Start button: batch    report    3D viz (auto chain)."""
        if self.tab3_processing:
            return
        if not self.tab3_input_folder or self.tab3_input_folder == 'Not selected':
            messagebox.showwarning('Start', 'Please select an Input Folder first.')
            return
        output_base = self._tab3_output_var.get()
        if not output_base or output_base == 'Not selected':
            messagebox.showwarning('Start', 'Please select an Output Folder.')
            return

        self._batch3d_stop_flag = False
        self.tab3_processing = True
        self._batch3d_start_btn.config(state='disabled')
        self._batch3d_set_progress(0)
        self._batch3d_status_lbl.config(text='Batch Processing ')

        # Collect images
        image_extensions = ['.png', '.jpg', '.jpeg']
        image_files = [
            os.path.join(self.tab3_input_folder, f)
            for f in os.listdir(self.tab3_input_folder)
            if os.path.isfile(os.path.join(self.tab3_input_folder, f))
            and any(f.lower().endswith(ext) for ext in image_extensions)
        ]
        if not image_files:
            messagebox.showwarning('Start', 'No image files found in selected folder.')
            self.tab3_processing = False
            self._batch3d_start_btn.config(state='normal')
            return

        self.tab3_log(f"\nFound {len(image_files)} image(s) to process")

        defects_path     = os.path.join(output_base, 'indicators')
        non_defects_path = os.path.join(output_base, 'non_indicators')
        os.makedirs(defects_path, exist_ok=True)
        os.makedirs(non_defects_path, exist_ok=True)
        self.tab3_log(f"Output -> Indicators: {defects_path}")
        self.tab3_log(f"Output -> Non Indicators: {non_defects_path}")

        def _run():
            total        = len(image_files)
            defect_count = 0
            non_defect   = 0
            segment_counts = {}   # filename -> number of segments (reused by report)
            import multiprocessing as _mp
            workers = max(1, min(_mp.cpu_count(), 32))
            '''self.root.after(0, lambda: self.tab3_log(
                f"Starting parallel processing with {workers} worker(s) "))'''
                

            from concurrent.futures import ThreadPoolExecutor, as_completed as _as_completed
            futures = {}
            UPDATE_EVERY = max(1, total // 20)

            with ThreadPoolExecutor(max_workers=workers) as executor:
                for img_path in image_files:
                    if self._batch3d_stop_flag:
                        break
                    fut = executor.submit(
                        self.tab3_process_single_image,
                        img_path, defects_path, non_defects_path, img_path)
                    futures[fut] = img_path

                for done_idx, fut in enumerate(_as_completed(futures), start=1):
                    if self._batch3d_stop_flag:
                        break
                    img_path = futures[fut]
                    fname = os.path.basename(img_path)
                    try:
                        num_seg = fut.result()
                        segment_counts[fname] = num_seg
                        if num_seg >= 1:
                            defect_count += 1
                            msg = f"{fname} -> Indicator ({num_seg} segments)"
                        else:
                            non_defect += 1
                            msg = f"{fname} -> Non Indicator"
                    except Exception as exc:
                        segment_counts[fname] = 0
                        msg = f"{fname} -> ERROR: {exc}"
                    del fut
                    gc.collect()

                    # Progress: batch phase is 0-70%   update on every image
                    # so the bar/percentage advance smoothly without large jumps.
                    progress = (done_idx / total) * 70
                    show_log = (done_idx % UPDATE_EVERY == 0 or done_idx == total)
                    _msg = msg;
                    _di = done_idx;
                    _log_it = show_log

                    def _update(p=progress, m=_msg, di=_di, log_it=_log_it):
                        self._batch3d_set_progress(p)
                        self._batch3d_status_lbl.config(text=f"Processing {di}/{total}...")
                        # Change 3: Individual per-image log lines suppressed.
                        # Only the progress bar and status label advance per image.

                    self.root.after(0, _update)

            if self._batch3d_stop_flag:
                def _stopped():
                    self.tab3_processing = False
                    self._batch3d_start_btn.config(state='normal')
                self.root.after(0, _stopped)
                return

            # ── Phase 2: Report generation (70  75%) ─────────────────────
            def _do_report():
                self._batch3d_set_progress(70)
                self._batch3d_status_lbl.config(text='Generating report')
                self.tab3_log("\nGenerating report")
                report_path = os.path.join(output_base, 'report.xlsx')
                try:
                    self._batch3d_generate_report_auto(
                        output_base, defects_path, non_defects_path, report_path,
                        segment_counts=segment_counts)
                    self.tab3_log(f"Report generated -> {report_path}")
                    self._batch3d_set_report_link(report_path)
                except Exception as e:
                    self.tab3_log(f"Report generation failed: {e}")
                self._batch3d_set_progress(75)
                self._batch3d_status_lbl.config(text='Report done.')
                self.tab3_log(f"\nBatch complete   Indicators: {defect_count} | Non Indicators: {non_defect}")

                # ── Phase 3: Auto 3D Viz (75  100%) ──────────────────────
                stl_path = self._batch3d_stl_var.get()
                if stl_path and stl_path != 'Not selected' and os.path.isfile(stl_path):
                    self.tab3_log("\n3D Visualization starting automatically")
                    self._batch3d_status_lbl.config(text='3D Visualization')
                    self._batch3d_run_viz(output_base, stl_path, auto=True)
                else:
                    self.tab3_log("STL file not selected   skipping auto 3D Visualization.")
                    self._batch3d_set_progress(100)
                    self._batch3d_status_lbl.config(text='Complete!')

                self.tab3_processing = False
                self._batch3d_start_btn.config(state='normal')

            self.root.after(0, _do_report)

        threading.Thread(target=_run, daemon=True).start()

    def _batch3d_set_progress(self, value):
        """Update the progress bar AND its percentage label together (Change 1)."""
        value = max(0, min(100, value))
        self._batch3d_progress['value'] = value
        if hasattr(self, '_batch3d_pct_lbl'):
            self._batch3d_pct_lbl.config(text=f"{int(round(value))}%")

    def _batch3d_set_report_link(self, report_path):
        """Enable/refresh the clickable Report hyperlink (Change 3). Always
        points to the most recently generated report; stays clickable until
        replaced by a newer report."""
        self._latest_report_path = report_path
        if hasattr(self, '_batch3d_report_link_btn'):
            self._batch3d_report_link_btn.config(
                text=f'Open Report ({os.path.basename(report_path)})',
                fg=self.HIGHLIGHT, cursor='hand2')

    def _batch3d_open_report(self):
        """Open the latest generated report with the OS-default application."""
        path = getattr(self, '_latest_report_path', None)
        if not path or not os.path.isfile(path):
            messagebox.showwarning('Report', 'No report has been generated yet.')
            return
        try:
            if sys.platform.startswith('win'):
                os.startfile(path)
            elif sys.platform == 'darwin':
                import subprocess as _sp
                _sp.Popen(['open', path])
            else:
                import subprocess as _sp
                _sp.Popen(['xdg-open', path])
        except Exception as e:
            messagebox.showerror('Report', f'Could not open report:\n{e}')

    def _batch3d_generate_report_auto(self, output_base, defects_path, non_defects_path, report_path,
                                       segment_counts=None):
        """Auto-generate a simple summary xlsx after batch processing.

        segment_counts: optional {filename: num_segments} dict captured during
        batch processing (Change 5)   reused here rather than recomputed.
        """
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        except ImportError:
            raise RuntimeError("openpyxl not installed. Run: pip install openpyxl")

        segment_counts = segment_counts or {}

        # Collect image names from each folder
        def _list_images(folder):
            exts = {'.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif'}
            if not os.path.isdir(folder):
                return []
            return [f for f in os.listdir(folder)
                    if os.path.splitext(f)[1].lower() in exts]

        defect_imgs     = _list_images(defects_path)
        non_defect_imgs = _list_images(non_defects_path)
        all_imgs = ([(f, 'defects') for f in defect_imgs] +
                    [(f, 'non_defects') for f in non_defect_imgs])
        all_imgs.sort(key=lambda x: x[0])

        HDR_FILL = PatternFill('solid', fgColor='2D7DD2')
        HDR_FONT = Font(bold=True, color='FFFFFF', size=10)
        DEF_FILL = PatternFill('solid', fgColor='F8D7DA')
        NOD_FILL = PatternFill('solid', fgColor='D4EDDA')
        THIN     = Border(left=Side(style='thin'), right=Side(style='thin'),
                          top=Side(style='thin'), bottom=Side(style='thin'))
        CENTER   = Alignment(horizontal='center', vertical='center')
        LEFT     = Alignment(horizontal='left', vertical='center')

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = 'Batch Results'

        CAT_LABELS = {'defects': 'Indicator', 'non_defects': 'Non Indicator'}

        headers = ['Image Name', 'Classification', 'Number of Segments']
        widths  = [36, 20, 20]
        for col, (h, w) in enumerate(zip(headers, widths), start=1):
            c = ws.cell(row=1, column=col, value=h)
            c.font = HDR_FONT; c.fill = HDR_FILL
            c.alignment = CENTER; c.border = THIN
            ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = w

        for r_idx, (fname, cat) in enumerate(all_imgs, start=2):
            fill = DEF_FILL if cat == 'defects' else NOD_FILL
            num_segments = segment_counts.get(fname, 0)
            label = CAT_LABELS.get(cat, cat)
            for col, val in enumerate([fname, label, num_segments], start=1):
                c = ws.cell(row=r_idx, column=col, value=val)
                c.fill = fill; c.border = THIN
                c.alignment = LEFT if col == 1 else CENTER

        ws2 = wb.create_sheet(title='Summary')
        summary_data = [
            ('Total Images',   len(all_imgs)),
            ('Indicators',     len(defect_imgs)),
            ('Non Indicators', len(non_defect_imgs)),
        ]
        for r, (k, v) in enumerate(summary_data, start=1):
            ws2.cell(row=r, column=1, value=k).font = Font(bold=True)
            ws2.cell(row=r, column=2, value=v)

        wb.save(report_path)

    def _batch3d_run_viz(self, output_base, stl_or_step_path, auto=False, seg_nrrd_path=None):
        """Launch 3D Slicer visualization (mirrors original _launch_3d logic).

        Change 7: when `seg_nrrd_path` is provided (the new "seg.nrrd + STL"
        workflow), the existing headless segmentation-GENERATION phase is
        skipped entirely   that phase's only job is to produce a seg.nrrd
        file from the PNG stack, and the caller is already handing us one.
        We reuse the user-supplied seg.nrrd in place of the generated one
        and jump straight to the SAME visualization phase (`visualise()`
        in the Slicer script below) that the Results-Folder workflow uses:
        identical transform constants, identical Harden Transform call,
        identical final view. No second visualization pipeline is created.
        """
        import glob as _glob, subprocess, tempfile

        slicer_exe = self._slicer_exe_var.get().strip()
        if not slicer_exe or not os.path.isfile(slicer_exe):
            msg = (f'3D Slicer executable not found:\n  {slicer_exe}\n\n'
                   'Place Slicer inside <project>/slicer/ folder.')
            self.root.after(0, lambda: messagebox.showwarning('3D Slicer Not Found', msg))
            self.root.after(0, lambda: self._batch3d_set_progress(100))
            self.root.after(0, lambda: self._batch3d_status_lbl.config(text='3D Viz skipped (Slicer not found)'))
            return

        # Results folder = output_base (contains defects / non_defects)
        folder = output_base

        # Determine STL path (STEP    STL conversion if needed)
        step_path = Path(stl_or_step_path)
        if step_path.suffix.lower() in ('.step', '.stp'):
            stl_file = str(step_path.with_suffix('.stl'))
            step_file = str(step_path)
        else:
            stl_file  = str(step_path)
            step_file = str(step_path)

        seg_out = os.path.join(output_base, '3D_Models', 'indicator_model.seg.nrrd')
        os.makedirs(os.path.join(output_base, '3D_Models'), exist_ok=True)

        # ── Change 7: direct seg.nrrd + STL workflow ───────────────────────
        # If the caller already has a seg.nrrd on disk (new workflow), skip
        # PNG collection / headless generation altogether and go straight
        # to the visualization-only Slicer pass, reusing it as-is.
        skip_generation = bool(seg_nrrd_path)
        if skip_generation:
            seg_src = str(seg_nrrd_path)
            if not os.path.isfile(seg_src):
                self.root.after(0, lambda: messagebox.showerror(
                    '3D Visualization Error', f'seg.nrrd file not found:\n{seg_src}'))
                self.root.after(0, lambda: self._batch3d_set_progress(100))
                self.root.after(0, lambda: self._batch3d_status_lbl.config(text='3D Viz failed (seg.nrrd missing)'))
                return
            # Use the supplied seg.nrrd directly as the file the Slicer
            # visualization pass loads (seg_output_path below). If it isn't
            # already inside output_base/3D_Models, copy it there so the
            # rest of the pipeline (and the STL copy step) behaves exactly
            # like the existing Results-Folder workflow.
            try:
                if os.path.abspath(seg_src) != os.path.abspath(seg_out):
                    import shutil as _shutil2
                    _shutil2.copy2(seg_src, seg_out)
                self.root.after(0, lambda p=seg_out: self.tab3_log(f"seg.nrrd ready for visualization    {p}"))
            except Exception as _seg_copy_exc:
                self.root.after(0, lambda e=_seg_copy_exc: self.tab3_log(
                    f"Could not stage seg.nrrd into 3D Models folder: {e}"))
                seg_out = seg_src  # fall back to loading it directly in place

            png_files = []
            category_summary = ''
        else:
            # Collect PNGs from defects / non_defects subfolders
            png_entries = []
            for sub in sorted(os.listdir(folder)):
                sub_path = os.path.join(folder, sub)
                if os.path.isdir(sub_path) and sub.lower() in (
                        'indicators', 'non_indicators', 'indicator', 'non_indicator',
                        'defects', 'non_defects', 'defect', 'non_defect'):
                    for fname in sorted(os.listdir(sub_path)):
                        if fname.lower().endswith('.png'):
                            png_entries.append((sub, os.path.join(sub_path, fname)))

            if not png_entries:
                self.root.after(0, lambda: self.tab3_log(
                    "No PNG files found for 3D Visualization."))
                self.root.after(0, lambda: self._batch3d_set_progress(100))
                self.root.after(0, lambda: self._batch3d_status_lbl.config(text='3D Viz skipped (no PNGs)'))
                return

            png_files = [path for _, path in png_entries]
            from collections import Counter as _Counter
            cat_counts = _Counter(cat for cat, _ in png_entries)
            category_summary = '\n'.join(
                f'    {cat}: {cnt} image(s)' for cat, cnt in sorted(cat_counts.items()))

        # FreeCAD conversion (same as original)
        freecad_exe = self._freecad_exe_var.get().strip()
        if freecad_exe and os.path.isfile(freecad_exe) and step_file != stl_file:
            fc_script_text = f"""
import FreeCAD, Part, Mesh, MeshPart
doc = FreeCAD.newDocument()
shape = Part.read(r"{step_file}")
obj = doc.addObject("Part::Feature", "Part")
obj.Shape = shape
mesh = MeshPart.meshFromShape(Shape=shape, LinearDeflection=0.1, AngularDeflection=0.5, Relative=False)
mesh_obj = doc.addObject("Mesh::Feature", "Mesh")
mesh_obj.Mesh = mesh
Mesh.export([mesh_obj], r"{stl_file}")
"""
            fc_tmp = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False,
                prefix='fc_convert_', encoding='utf-8')
            fc_tmp.write(fc_script_text); fc_tmp.close()
            try:
                subprocess.run([freecad_exe, fc_tmp.name], timeout=120, capture_output=True)
            except Exception:
                pass

        # ── Change 6: copy the STL used for visualization into 3D_Models
        #    too, so seg.nrrd and the STL always exist together. ───────────
        try:
            import shutil as _shutil
            if os.path.isfile(stl_file):
                _stl_dest = os.path.join(output_base, '3D_Models', os.path.basename(stl_file))
                if os.path.abspath(stl_file) != os.path.abspath(_stl_dest):
                    _shutil.copy2(stl_file, _stl_dest)
                self.root.after(0, lambda p=_stl_dest: self.tab3_log(f"STL copied to 3D Models folder    {p}"))
            else:
                self.root.after(0, lambda: self.tab3_log("STL file not found yet -- skipping copy to 3D Models folder."))
        except Exception as _copy_exc:
            self.root.after(0, lambda e=_copy_exc: self.tab3_log(f"Could not copy STL into 3D Models folder: {e}"))

        # Build Slicer script (identical to original _launch_3d, now
        # parameterised by `headless` to split generation from display  
        # see Change 2: Slicer Launch Timing).
        import textwrap
        sp_x=self._VIZ3D_SP_X; sp_y=self._VIZ3D_SP_Y; sp_z=self._VIZ3D_SP_Z
        island=self._VIZ3D_ISLAND; r_min=self._VIZ3D_R_MIN; g_max=self._VIZ3D_G_MAX
        sx=self._VIZ3D_SX; sy=self._VIZ3D_SY; sz=self._VIZ3D_SZ
        tx=self._VIZ3D_TX; ty=self._VIZ3D_TY; tz=self._VIZ3D_TZ
        nsx=self._VIZ3D_NRRD_SX; nsy=self._VIZ3D_NRRD_SY; nsz=self._VIZ3D_NRRD_SZ
        ntx=self._VIZ3D_NRRD_TX; nty=self._VIZ3D_NRRD_TY; ntz=self._VIZ3D_NRRD_TZ

        import textwrap as _textwrap

        def _make_script(headless):
            return _textwrap.dedent(f'''
            import os, glob, subprocess, random, pathlib, slicer, numpy as np, qt, vtk

            try:
                print(f"VTK thread pool size: {{vtk.vtkSlicerThreading.GetNumberOfThreads()}}")
            except Exception:
                pass
            os.environ['VTK_NUM_THREADS'] = '32'
            try:
                slicer.app.threading.setNumberOfThreads(32)
            except Exception:
                pass
            
            png_folder = r"{folder}"
            seg_output_path = r"{seg_out}"
            png_file_list = {repr(png_files)}
            spacing_x = {sp_x}; spacing_y = {sp_y}; spacing_z = {sp_z}
            minimum_island_size = {island}
            R_min, G_max, B_max = {r_min}, {g_max}, 0
            step_file = pathlib.Path(r"{step_file}")
            stl_file  = pathlib.Path(r"{stl_file}")
            freecad_cmd = r"{freecad_exe if freecad_exe else ''}"

            def create_segmentation_from_png():
                print("STAGE::LOADING_DATA")
                print("STEP::1/13::Loading PNG Stack...")
                print("\\n=== Loading PNG stack ===")
                png_files = png_file_list if png_file_list else sorted(
                    glob.glob(os.path.join(png_folder, "**", "*.png"), recursive=True))
                if not png_files:
                    raise RuntimeError(f"No PNG files found in {{png_folder}}")
                print(f"Total PNGs: {{len(png_files)}}")
                setup_view()
                from PIL import Image
                slices = []; target_size = None
                for f in png_files:
                    img = Image.open(f).convert("RGB")
                    if target_size is None: target_size = img.size
                    if img.size != target_size: img = img.resize(target_size)
                    slices.append(np.array(img))
                if not slices: raise RuntimeError("No valid PNG images loaded")
                volume_array = np.stack(slices, axis=0)
                volume_node = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLVectorVolumeNode", "PNGStack")
                slicer.util.updateVolumeFromArray(volume_node, volume_array)
                volume_node.SetSpacing(spacing_x, spacing_y, spacing_z)
                volume_node.CreateDefaultDisplayNodes()
                # ── Orientation correction: flip X axis so IJK  RAS becomes IJK  LAS ──
                _vtk_mat = vtk.vtkMatrix4x4()
                volume_node.GetIJKToRASMatrix(_vtk_mat)
                _current = np.array(
                    [[_vtk_mat.GetElement(i, j) for j in range(4)] for i in range(4)],
                    dtype=np.float64)
                _flip_x = np.diag([-1.0, 1.0, 1.0, 1.0])
                _new_mat_np = _current @ _flip_x
                _new_vtk_mat = vtk.vtkMatrix4x4()
                for i in range(4):
                    for j in range(4):
                        _new_vtk_mat.SetElement(i, j, float(_new_mat_np[i, j]))
                volume_node.SetIJKToRASMatrix(_new_vtk_mat)
                volume_node.Modified()
                print("IJK->LAS orientation correction applied to PNGStack.")
                # ── End orientation correction ─────────────────────────────────────
                rgb_arr = slicer.util.arrayFromVolume(volume_node)
                print("STEP::2/13::Extracting Red Mask...")
                R = rgb_arr[..., 0] if rgb_arr.shape[-1]==3 else rgb_arr[0]
                G = rgb_arr[..., 1] if rgb_arr.shape[-1]==3 else rgb_arr[1]
                B = rgb_arr[..., 2] if rgb_arr.shape[-1]==3 else rgb_arr[2]
                mask = ((R==R_min)&(G==G_max)&(B==B_max)).astype(np.uint8)
                print("STEP::3/13::Creating Scalar Volume...")
                scalar_node = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLScalarVolumeNode", "RedMaskVolume")
                slicer.util.updateVolumeFromArray(scalar_node, mask)
                scalar_node.CopyOrientation(volume_node); scalar_node.SetOrigin(volume_node.GetOrigin())
                scalar_node.SetSpacing(volume_node.GetSpacing()); scalar_node.CreateDefaultDisplayNodes()
                print("STAGE::SEGMENTATION")
                print("STEP::4/13::Creating Segmentation...")
                seg_node = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLSegmentationNode", "IndicatorSegmentation")
                seg_node.CreateDefaultDisplayNodes()
                seg_node.SetReferenceImageGeometryParameterFromVolumeNode(scalar_node)
                segmentation = seg_node.GetSegmentation()
                segment_id = segmentation.AddEmptySegment("Indicator")
                seg_node.CreateBinaryLabelmapRepresentation()
                ew = slicer.qMRMLSegmentEditorWidget(); ew.setMRMLScene(slicer.mrmlScene)
                en = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLSegmentEditorNode")
                ew.setMRMLSegmentEditorNode(en); ew.setSegmentationNode(seg_node); ew.setSourceVolumeNode(scalar_node)
                en.SetSelectedSegmentID(segment_id)
                ew.setActiveEffectByName("Threshold"); t = ew.activeEffect()
                print("STEP::5/13::Applying Threshold...")
                t.setParameter("MinimumThreshold","1"); t.setParameter("MaximumThreshold","255"); t.self().onApply()
                slicer.app.processEvents()
                ew.setActiveEffectByName("Islands"); isl = ew.activeEffect()
                print("STEP::6/13::Removing Small Islands...")
                isl.setParameter("Operation","REMOVE_SMALL_ISLANDS"); isl.setParameter("MinimumSize",str(minimum_island_size))
                isl.self().onApply(); slicer.app.processEvents()
                for i in range(segmentation.GetNumberOfSegments()):
                    seg_id = segmentation.GetNthSegmentID(i)
                    segmentation.GetSegment(seg_id).SetColor(1,0,0)  # CHANGED: solid red instead of random color
                print("STAGE::MODEL_GENERATION")
                print("STEP::7/13::Generating Closed Surface...")
                seg_node.CreateClosedSurfaceRepresentation(); seg_node.GetDisplayNode().SetVisibility3D(True)
                print("STAGE::STL_PROCESSING")
                print("STEP::8/13::Saving Segmentation (.seg.nrrd)...")
                slicer.util.saveNode(seg_node, seg_output_path)
                print(f"Segmentation saved to {{seg_output_path}}")
                return seg_node

            def visualise(seg_node, stl_path):
                print("STAGE::VISUALIZATION")
                print("STEP::9/13::Loading Segmentation...")
                segNode = slicer.util.loadSegmentation(seg_output_path)
                print("STEP::9b/13::Scaling & Translating seg.nrrd...")
                seg_tn = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLLinearTransformNode","SegScaleTranslate")
                seg_mx = vtk.vtkMatrix4x4(); seg_mx.Identity()
                seg_mx.SetElement(0,0,{nsx}); seg_mx.SetElement(1,1,{nsy}); seg_mx.SetElement(2,2,{nsz})
                seg_mx.SetElement(0,3,{ntx}); seg_mx.SetElement(1,3,{nty}); seg_mx.SetElement(2,3,{ntz})
                seg_tn.SetMatrixTransformToParent(seg_mx); segNode.SetAndObserveTransformNodeID(seg_tn.GetID())
                slicer.vtkSlicerTransformLogic().hardenTransform(segNode)
                # IMPORTANT: closed-surface representation must be (re)generated
                # AFTER the transform is hardened onto the master (labelmap)
                # representation. hardenTransform() invalidates any derived
                # representation that already existed (e.g. one created before
                # the harden call), which is why the segmentation previously
                # vanished from the 3D view -- SetVisibility3D was being set on
                # a closed-surface representation that had since been wiped
                # out by the harden step. Generating it here, after the
                # transform is applied, ensures the 3D view has valid,
                # correctly-positioned closed-surface geometry to render.
                segNode.CreateClosedSurfaceRepresentation()
                sd = segNode.GetDisplayNode(); sd.SetVisibility3D(True); sd.SetOpacity3D(1)
                print("STEP::10/13::Loading STL Model...")
                modelNode = slicer.util.loadModel(stl_path); modelNode.CreateDefaultDisplayNodes()
                md = modelNode.GetDisplayNode(); md.SetColor(1.0, 0.843, 0.0); md.SetOpacity(0.1)  # CHANGED: gold color, opacity unchanged
                tn = slicer.mrmlScene.AddNewNodeByClass("vtkMRMLLinearTransformNode","ScaleTranslate")
                print("STEP::11/13::Scaling & Translating STL...")
                mx = vtk.vtkMatrix4x4(); mx.Identity()
                mx.SetElement(0,0,{sx}); mx.SetElement(1,1,{sy}); mx.SetElement(2,2,{sz})
                mx.SetElement(0,3,{tx}); mx.SetElement(1,3,{ty}); mx.SetElement(2,3,{tz})
                tn.SetMatrixTransformToParent(mx); modelNode.SetAndObserveTransformNodeID(tn.GetID())
                print("STEP::12/13::Hardening Transform...")
                slicer.vtkSlicerTransformLogic().hardenTransform(modelNode)
                print("STEP::13/13::Launching 3D Visualization...")
                slicer.app.layoutManager().setLayout(slicer.vtkMRMLLayoutNode.SlicerLayoutOneUp3DView)
                v = slicer.app.layoutManager().threeDWidget(0).threeDView(); v.resetFocalPoint(); v.resetCamera()
                # Re-hide any dock widgets/panels that Slicer may have
                # re-shown while loading the STL/segmentation, so only the
                # 3D viewport remains visible.
                _hide_ui_chrome()
                print("Visualization ready")

            # MODIFIED (Change 1   3D Slicer window: only the 3D viewport
            # should be visible). Broadened this function beyond dock
            # widgets / menu bar / toolbars / status bar to also hide the
            # Data Probe bar and Python console (two additional pieces of
            # Slicer chrome that live outside the QDockWidget/QToolBar
            # families and were previously left visible), and to zero out
            # the central widget's layout margins so no empty chrome strip
            # remains around the 3D view. Still safe to call multiple
            # times   used both before and after data loads, since loading
            # STL/segmentation data can cause Slicer to re-display a panel
            # (e.g. Data/Subject Hierarchy).
            def _hide_ui_chrome():
                if HEADLESS:
                    # No main window exists under --no-main-window; skip
                    # window-chrome setup entirely during the headless pass.
                    return
                mw = slicer.util.mainWindow()
                if mw is None:
                    return
                slicer.app.layoutManager().setLayout(slicer.vtkMRMLLayoutNode.SlicerLayoutOneUp3DView)
                # Left-side panes / all dock widgets (Data, Subject
                # Hierarchy, Modules selector, Segment Editor, etc.)
                for d in mw.findChildren("QDockWidget"):
                    d.hide()
                # Menu bar and every toolbar (module toolbar, main toolbar).
                mw.menuBar().hide()
                for t in mw.findChildren("QToolBar"):
                    t.hide()
                mw.statusBar().hide()
                # Data Probe bar (bottom info strip) and Python console  
                # neither is a QDockWidget/QToolBar, so hide them by their
                # known Slicer object names if present.
                for _obj_name in ("DataProbeCollapsibleWidget", "pythonConsoleDockWidget"):
                    _w = mw.findChild("QWidget", _obj_name)
                    if _w is not None:
                        _w.hide()
                try:
                    slicer.util.pythonShell().parent().hide()
                except Exception:
                    pass
                # Remove leftover margins around the 3D viewport so it
                # fills the window with nothing else visible.
                try:
                    _central = mw.centralWidget()
                    if _central is not None and _central.layout() is not None:
                        _central.layout().setContentsMargins(0, 0, 0, 0)
                except Exception:
                    pass
            # END MODIFIED (Change 1)

            def setup_view():
                if HEADLESS:
                    # No main window exists under --no-main-window; skip
                    # window-chrome setup entirely during the headless pass.
                    return
                _hide_ui_chrome()
                mw = slicer.util.mainWindow()
                mw.showMaximized()

            HEADLESS = {('True' if headless else 'False')}

            def delayed_run():
                try:
                    if HEADLESS:
                        # Generation-only pass: build & save the segmentation
                        # (.seg.nrrd) WITHOUT showing/using the 3D view.
                        # The Slicer window is never displayed to the user
                        # during this phase   it only opens afterwards, once
                        # generation has finished, for the visualization pass.
                        create_segmentation_from_png()
                        print("STAGE::COMPLETE")
                        qt.QTimer.singleShot(800, lambda: slicer.app.exit(0))
                    else:
                        # Visualization-only pass: seg.nrrd already exists on
                        # disk from the prior headless generation phase.
                        setup_view()
                        visualise(None, stl_file)
                        print("STAGE::COMPLETE")
                except Exception as _e:
                    print(f"STAGE::ERROR::{{_e}}")
                    if HEADLESS:
                        slicer.app.exit(1)
                    raise

            qt.QTimer.singleShot(200, delayed_run)
        ''')


        import tempfile as _tempfile

        try:
            import subprocess as _subprocess
            env = os.environ.copy()
            for _k in ('QT_QPA_PLATFORM_PLUGIN_PATH', 'QT_PLUGIN_PATH', 'QT_DEBUG_PLUGINS'):
                env.pop(_k, None)
            _slicer_root = os.path.dirname(os.path.dirname(os.path.abspath(slicer_exe)))
            for _cand in (os.path.join(_slicer_root, 'lib', 'Qt', 'plugins'),
                          os.path.join(_slicer_root, 'lib', 'qt5', 'plugins'),
                          os.path.join(_slicer_root, 'plugins')):
                if os.path.isdir(_cand):
                    env['QT_QPA_PLATFORM_PLUGIN_PATH'] = _cand; break
            env['QT_QPA_PLATFORM'] = 'xcb'; env['XDG_SESSION_TYPE'] = 'x11'

            def _set_progress(p):
                self._batch3d_set_progress(p)

            def _set_status(txt):
                self._batch3d_status_lbl.config(text=txt)

            # Progress range for the 3D Viz phase itself spans 75  100 when
            # launched as part of the auto chain (matches existing phase
            # hints), or starts fresh at 0  100 when launched independently.
            # The phase is further split between the headless generation
            # pass (Change 2) and the GUI visualization pass so the bar
            # keeps advancing smoothly with no single big jump.
            base, span = (75, 25) if auto else (0, 100)
            gen_base, gen_span = base, span * 0.6
            viz_base, viz_span = base + span * 0.6, span * 0.4

            gen_stage_map = {
                'LOADING_DATA':     (gen_base + gen_span * 0.20, 'Loading data'),
                'SEGMENTATION':     (gen_base + gen_span * 0.55, 'Segmentation'),
                'MODEL_GENERATION': (gen_base + gen_span * 0.80, 'Model generation'),
                'STL_PROCESSING':   (gen_base + gen_span * 0.95, 'Saving segmentation'),
            }
            viz_stage_map = {
                'VISUALIZATION':    (viz_base + viz_span * 0.6, 'Visualization'),
            }

            def _launch_phase(headless, stage_map, on_done, on_complete=None):
                """Launch one Slicer subprocess (generation or visualization
                pass), stream its output, and invoke on_done(ok, error) on
                the GUI thread once it exits. When headless=True, Slicer
                runs with --no-main-window so its window is never shown  
                it only opens for the visualization pass, and only after
                generation has completed successfully (Change 2).

                Progress-bar fix: the visualization pass keeps the Slicer
                window open afterwards for user interaction, so its process
                does NOT exit once finished -- it only exits when the user
                later closes the window. Waiting for process exit to mark
                the bar 100% therefore left it stuck at the last in-progress
                percentage. `on_complete`, if given, fires as soon as the
                pipeline itself reports `STAGE::COMPLETE` in its output --
                i.e. the moment the 3D visualization has actually finished
                (rendering, transforms, and UI setup all done) -- instead of
                waiting for the (possibly much later) process exit."""
                script_content = _make_script(headless)
                tmp = _tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False,
                    prefix='indicator_nrrd_stl_', encoding='utf-8')
                tmp.write(script_content); tmp.close()

                cmd = [slicer_exe, '--no-splash']
                if headless:
                    cmd.append('--no-main-window')
                cmd += ['--python-script', tmp.name]

                proc = _subprocess.Popen(
                    cmd, shell=False, env=env,
                    stdout=_subprocess.PIPE, stderr=_subprocess.STDOUT,
                    text=True, bufsize=1)

                # MODIFIED (Change 3   suppress internal Slicer status
                # messages): Slicer's stdout occasionally interleaves its
                # own internal initialization/debug chatter (Qt/VTK class
                # names, markups-module boilerplate, "No main window
                # available", etc.) alongside the meaningful STEP::/STAGE::
                # progress lines this app already understands. None of that
                # internal chatter is meaningful to the user, so it is
                # filtered out here before anything falls through to the
                # generic "[Slicer] ..." log line below. STEP::/STAGE::/
                # completion/error handling above is untouched.
                _SLICER_NOISE_SUBSTRINGS = (
                    'qSlicerMarkupsModuleWidget',
                    'vtkMRMLMarkupsNode',
                    'No main window available',
                )
                _SLICER_NOISE_PREFIXES = ('qSlicer', 'vtkMRML', 'qMRML', 'qSlicerCore')

                def _is_slicer_noise(line):
                    """True for internal Slicer init/debug chatter that
                    should not be shown in the Status/Log window."""
                    stripped = line.strip()
                    if any(s in stripped for s in _SLICER_NOISE_SUBSTRINGS):
                        return True
                    if stripped.startswith(_SLICER_NOISE_PREFIXES):
                        return True
                    return False

                # END MODIFIED (Change 3 helper definition)
                def _monitor():
                    completed_ok = False
                    error_seen   = None
                    completion_fired = False
                    try:
                        for line in proc.stdout:
                            line = line.rstrip('\n')
                            if not line:
                                continue
                            if line.startswith('STAGE::ERROR::'):
                                error_seen = line[len('STAGE::ERROR::'):]
                                self.root.after(0, lambda m=line: self.tab3_log(f"{m}"))
                                continue
                            if line.startswith('STAGE::COMPLETE'):
                                completed_ok = True
                                self.root.after(0, lambda: self.tab3_log("Pipeline stage reported completion."))
                                if on_complete is not None and not completion_fired:
                                    completion_fired = True
                                    self.root.after(0, on_complete)
                                continue
                            if line.startswith('STEP::'):
                                step_body = line[len('STEP::'):]
                                step_no, _, step_label = step_body.partition('::')
                                display = f"[{step_no}] {step_label}" if step_label else f"[{step_no}]"
                                self.root.after(0, lambda d=display: self.tab3_log(d))
                                continue
                            if line.startswith('STAGE::'):
                                stage_key = line[len('STAGE::'):]
                                pct, label = stage_map.get(stage_key, (None, None))
                                if pct is not None:
                                    self.root.after(0, lambda p=pct: _set_progress(p))
                                    self.root.after(0, lambda l=label: _set_status(l))
                                    self.root.after(0, lambda l=label: self.tab3_log(f"  {l}"))
                                continue
                                # MODIFIED (Change 3): drop internal Slicer
                                # init/debug chatter instead of logging it.
                            if _is_slicer_noise(line):
                                continue
                                # END MODIFIED (Change 3)
                            self.root.after(0, lambda m=line: self.tab3_log(f"[Slicer] {m}"))
                    except Exception as _read_exc:
                        self.root.after(0, lambda e=_read_exc: self.tab3_log(f"Lost connection to Slicer output stream: {e}"))

                    self.root.after(0, lambda: on_done(completed_ok, error_seen, completion_fired))

                threading.Thread(target=_monitor, daemon=True).start()

            def _on_viz_complete():
                """Fires the instant the pipeline reports STAGE::COMPLETE for
                the visualization pass -- i.e. once rendering, transforms,
                and the 3D view are fully set up -- rather than waiting for
                the Slicer process to exit (it stays open for interaction
                and may not exit for a long time, if ever, in this run)."""
                _set_progress(100)
                _set_status('3D Visualization complete!')
                self.tab3_log("3D Visualization finished successfully -- Slicer window is ready for interaction.")

            def _on_viz_done(ok, err, completion_fired=False):
                if ok and not err:
                    # Success was already fully reflected (progress bar at
                    # 100%, status, and log line) by _on_viz_complete the
                    # moment STAGE::COMPLETE was seen -- nothing further to
                    # do here; this branch only runs later, whenever the
                    # user eventually closes the Slicer window.
                    if not completion_fired:
                        _set_progress(100)
                        _set_status('3D Visualization complete!')
                        self.tab3_log("3D Visualization finished successfully -- Slicer window is ready for interaction.")
                elif err:
                    _set_status('3D Visualization failed.')
                    self.tab3_log(f"3D Visualization failed: {err}")
                    messagebox.showerror('3D Visualization Error',
                                          f'The visualization pipeline reported an error:\n{err}')
                else:
                    _set_status('3D Visualization ended unexpectedly.')
                    self.tab3_log("Slicer output stream closed before the pipeline reported completion. "
                                  "3D Visualization may not have finished successfully.")

            def _on_gen_done(ok, err, completion_fired=False):
                if not ok or err:
                    _set_status('3D segmentation generation failed.')
                    self.tab3_log(f"Segmentation generation failed: {err or 'unknown error'} -- Slicer will not be opened.")
                    messagebox.showerror('3D Visualization Error',
                                          f'Segmentation generation failed:\n{err or "unknown error"}\n\n'
                                          f'3D Slicer was not opened.')
                    return
                # Required files (seg.nrrd + STL) are now confirmed on disk  
                # only now does the Slicer window open, for visualization.
                self.tab3_log("Segmentation generated and saved -- required files are ready.")
                self.tab3_log("Opening 3D Slicer for visualization")
                _set_status('Opening 3D Slicer ')
                _set_progress(viz_base)
                _launch_phase(False, viz_stage_map, _on_viz_done, on_complete=_on_viz_complete)

            if skip_generation:
                # Change 7: seg.nrrd already supplied by the user   there is
                # nothing to generate, so the headless pass is skipped and
                # we go straight to the SAME visualization phase used by
                # the Results-Folder workflow.
                self.root.after(0, lambda: _set_status('Opening 3D Slicer '))
                self.root.after(0, lambda: self.tab3_log(
                    "\n3D Visualization pipeline started   using the supplied seg.nrrd directly "
                    "(no segmentation generation needed) "))
                self.root.after(0, lambda: _set_progress(viz_base))
                _launch_phase(False, viz_stage_map, _on_viz_done, on_complete=_on_viz_complete)
            else:
                self.root.after(0, lambda: _set_status('Generating 3D segmentation '))
                self.root.after(0, lambda: self.tab3_log(
                    "\n3D Visualization pipeline started   generating segmentation in the background "
                    "(Slicer window will open once generation finishes) "))
                self.root.after(0, lambda: _set_progress(gen_base))

                _launch_phase(True, gen_stage_map, _on_gen_done)

        except Exception as exc:
            def _viz_err(e=exc):
                messagebox.showerror('Launch Error', f'Failed to launch 3D Slicer:\n{e}')
                self._batch3d_set_progress(100)
                self._batch3d_status_lbl.config(text='3D Viz launch failed.')
                self.tab3_log(f"Failed to launch 3D Slicer: {e}")
            self.root.after(0, _viz_err)

    def _batch3d_launch_viz_independent(self):
        """Independent 3D Visualise button   opens a dedicated dialog to pick
        inputs for visualization, completely independent of the main batch
        inputs.

        Change 7: the dialog now offers two input modes that both feed the
        SAME underlying `_batch3d_run_viz` visualization pipeline:
          • Results Folder + STL  (original workflow   unchanged)
          • seg.nrrd + STL        (new workflow   produces an identical
                                    visualization, per the existing transform
                                    + Harden Transform logic already in
                                    `_batch3d_run_viz`)
        No second visualization implementation is created; only the input
        mechanism differs.
        """

        # ── Modal dialog ─────────────────────────────────────────────────
        popup = tk.Toplevel(self.root)
        popup.title("3D Visualise   Select Inputs")
        popup.resizable(False, False)
        popup.configure(bg=self.BG)
        popup.grab_set()

        # Centre over main window
        self.root.update_idletasks()
        DIALOG_W, DIALOG_H = 540, 360
        rx = self.root.winfo_x() + (self.root.winfo_width()  - DIALOG_W) // 2
        ry = self.root.winfo_y() + (self.root.winfo_height() - DIALOG_H) // 2
        popup.geometry(f"{DIALOG_W}x{DIALOG_H}+{rx}+{ry}")

        card = tk.Frame(popup, bg=self.PANEL)
        card.place(relx=0.5, rely=0.5, anchor='center', width=500, height=330)

        tk.Label(card, text='3D Visualise', bg=self.PANEL, fg=self.HIGHLIGHT,
                 font=(self.FONT, 13, 'bold')).pack(anchor='w', padx=20, pady=(16, 2))
        tk.Label(card, text='Choose an input mode, then select files to launch visualization independently.',
                 bg=self.PANEL, fg=self.FG2,
                 font=(self.FONT, 9), wraplength=460, justify='left').pack(anchor='w', padx=20, pady=(0, 8))

        # ── Mode toggle: Results Folder + STL  /  seg.nrrd + STL ──────────
        mode_var = tk.StringVar(value='seg_nrrd')   # default to the new workflow

        mode_row = tk.Frame(card, bg=self.PANEL)
        mode_row.pack(fill='x', padx=20, pady=(0, 8))
        tk.Radiobutton(mode_row, text='seg.nrrd + STL', variable=mode_var, value='seg_nrrd',
                       bg=self.PANEL, fg=self.FG, selectcolor=self.ENTRY_BG,
                       activebackground=self.PANEL, activeforeground=self.HIGHLIGHT,
                       font=(self.FONT, 9, 'bold'), cursor='hand2',
                       command=lambda: _set_mode('seg_nrrd')).pack(side='left', padx=(0, 16))
        tk.Radiobutton(mode_row, text='Results Folder + STL', variable=mode_var, value='results',
                       bg=self.PANEL, fg=self.FG, selectcolor=self.ENTRY_BG,
                       activebackground=self.PANEL, activeforeground=self.HIGHLIGHT,
                       font=(self.FONT, 9, 'bold'), cursor='hand2',
                       command=lambda: _set_mode('results')).pack(side='left')

        tk.Frame(card, bg=self.ACCENT, height=1).pack(fill='x', padx=20, pady=(0, 10))

        # ── Results Folder row (original workflow) ─────────────────────────
        results_var = tk.StringVar(value='No folder selected')

        def _pick_results():
            p = filedialog.askdirectory(
                title='Select Results Folder  (must contain Indicator / Non Indicator subfolders)',
                parent=popup)
            if p:
                results_var.set(p)

        row1 = tk.Frame(card, bg=self.PANEL)
        tk.Label(row1, text='Results Folder :', bg=self.PANEL, fg=self.FG2,
                 font=(self.FONT, 9), width=16, anchor='w').pack(side='left')
        tk.Entry(row1, textvariable=results_var, bg=self.ENTRY_BG, fg=self.FG,
                 relief='flat', font=(self.FONT, 9), state='readonly',
                 readonlybackground=self.ENTRY_BG, bd=0
                 ).pack(side='left', fill='x', expand=True, ipady=5, padx=(4, 8))
        tk.Button(row1, text='Browse', command=_pick_results,
                  bg=self.BTN_BG, fg=self.FG, relief='flat',
                  font=(self.FONT, 9, 'bold'), padx=10,
                  activebackground=self.HIGHLIGHT, cursor='hand2').pack(side='right')

        # ── seg.nrrd row (new workflow   Change 7) ──────────────────────────
        seg_var = tk.StringVar(value='No file selected')

        def _pick_seg():
            p = filedialog.askopenfilename(
                title='Select seg.nrrd File',
                filetypes=[('Segmentation NRRD files', '*.nrrd'), ('All files', '*.*')],
                parent=popup)
            if p:
                seg_var.set(p)

        row_seg = tk.Frame(card, bg=self.PANEL)
        tk.Label(row_seg, text='seg.nrrd File :', bg=self.PANEL, fg=self.FG2,
                 font=(self.FONT, 9), width=16, anchor='w').pack(side='left')
        tk.Entry(row_seg, textvariable=seg_var, bg=self.ENTRY_BG, fg=self.FG,
                 relief='flat', font=(self.FONT, 9), state='readonly',
                 readonlybackground=self.ENTRY_BG, bd=0
                 ).pack(side='left', fill='x', expand=True, ipady=5, padx=(4, 8))
        tk.Button(row_seg, text='Browse', command=_pick_seg,
                  bg=self.BTN_BG, fg=self.FG, relief='flat',
                  font=(self.FONT, 9, 'bold'), padx=10,
                  activebackground=self.HIGHLIGHT, cursor='hand2').pack(side='right')

        # ── STL File row (shared by both modes) ─────────────────────────────
        stl_var = tk.StringVar(value='No file selected')

        def _pick_stl():
            p = filedialog.askopenfilename(
                title='Select STL / STEP File',
                filetypes=[('STL/STEP files', '*.stl *.step *.stp'), ('All files', '*.*')],
                parent=popup)
            if p:
                stl_var.set(p)

        row2 = tk.Frame(card, bg=self.PANEL)
        row2.pack(fill='x', padx=20, pady=4)
        tk.Label(row2, text='STL / STEP File :', bg=self.PANEL, fg=self.FG2,
                 font=(self.FONT, 9), width=16, anchor='w').pack(side='left')
        tk.Entry(row2, textvariable=stl_var, bg=self.ENTRY_BG, fg=self.FG,
                 relief='flat', font=(self.FONT, 9), state='readonly',
                 readonlybackground=self.ENTRY_BG, bd=0
                 ).pack(side='left', fill='x', expand=True, ipady=5, padx=(4, 8))
        tk.Button(row2, text='Browse', command=_pick_stl,
                  bg=self.BTN_BG, fg=self.FG, relief='flat',
                  font=(self.FONT, 9, 'bold'), padx=10,
                  activebackground=self.HIGHLIGHT, cursor='hand2').pack(side='right')

        def _set_mode(mode):
            mode_var.set(mode)
            if mode == 'seg_nrrd':
                row1.pack_forget()
                row_seg.pack(fill='x', padx=20, pady=4, before=row2)
            else:
                row_seg.pack_forget()
                row1.pack(fill='x', padx=20, pady=4, before=row2)
            err_lbl.config(text='')

        tk.Frame(card, bg=self.ACCENT, height=1).pack(fill='x', padx=20, pady=(10, 8))

        err_lbl = tk.Label(card, text='', bg=self.PANEL, fg='#e05c5c',
                           font=(self.FONT, 9), wraplength=460, justify='left')
        err_lbl.pack(pady=(0, 4))

        # Show the default mode's row now that err_lbl/row2 exist
        _set_mode('seg_nrrd')

        # ── Launch button ─────────────────────────────────────────────────
        def _launch():
            mode     = mode_var.get()
            stl_path = stl_var.get().strip()

            if stl_path == 'No file selected' or not os.path.isfile(stl_path):
                err_lbl.config(text='Please select a valid STL / STEP File.')
                return

            if mode == 'seg_nrrd':
                seg_path = seg_var.get().strip()
                if seg_path == 'No file selected' or not os.path.isfile(seg_path):
                    err_lbl.config(text='Please select a valid seg.nrrd File.')
                    return
                if not seg_path.lower().endswith('.nrrd'):
                    err_lbl.config(text='Selected file does not look like a .nrrd file.')
                    return

                popup.destroy()

                self.tab3_log(f"\n3D Visualization started (seg.nrrd + STL mode)")
                self.tab3_log(f"  seg.nrrd : {seg_path}")
                self.tab3_log(f"  STL      : {stl_path}")
                self._batch3d_status_lbl.config(text='3D Visualization ')
                self._batch3d_set_progress(0)

                # Use the STL's own folder as the output_base, so the
                # staged copy of seg.nrrd + STL lands in
                # <stl folder>/3D_Models   same convention the existing
                # Results-Folder workflow already uses (output_base/3D_Models).
                output_base = os.path.dirname(os.path.abspath(stl_path))

                def _run_viz():
                    self._batch3d_run_viz(output_base, stl_path, auto=False,
                                           seg_nrrd_path=seg_path)
                threading.Thread(target=_run_viz, daemon=True).start()

            else:
                results_path = results_var.get().strip()
                if results_path == 'No folder selected' or not os.path.isdir(results_path):
                    err_lbl.config(text='Please select a valid Results Folder.')
                    return

                # Verify at least one of defects / non_defects exists
                has_sub = any(
                    os.path.isdir(os.path.join(results_path, s))
                    for s in ('indicators', 'non_indicators', 'Indicators', 'Non_Indicators',
                              'defects', 'non_defects', 'Defects', 'Non_Defects')
                )
                if not has_sub:
                    err_lbl.config(
                        text='Results Folder must contain Indicator / Non Indicator subfolders.')
                    return

                popup.destroy()

                self.tab3_log(f"\n3D Visualization started (Results Folder mode)")
                self.tab3_log(f"  Results : {results_path}")
                self.tab3_log(f"  STL     : {stl_path}")
                self._batch3d_status_lbl.config(text='3D Visualization ')
                self._batch3d_set_progress(0)

                def _run_viz():
                    self._batch3d_run_viz(results_path, stl_path, auto=False)
                threading.Thread(target=_run_viz, daemon=True).start()

        btn_row = tk.Frame(card, bg=self.PANEL)
        btn_row.pack(pady=(4, 0))
        tk.Button(btn_row, text='  Launch 3D Viewer',
                  command=_launch,
                  bg='#1e3a2f', fg='#5dbf8e', relief='flat',
                  font=(self.FONT, 11, 'bold'), padx=22, pady=7,
                  activebackground='#14532d', cursor='hand2').pack(side='left', padx=(0, 10))
        tk.Button(btn_row, text='Cancel',
                  command=popup.destroy,
                  bg=self.BTN_BG, fg=self.FG, relief='flat',
                  font=(self.FONT, 10, 'bold'), padx=14, pady=7,
                  activebackground=self.HIGHLIGHT, cursor='hand2').pack(side='left')

    def _tab3_select_output_folder(self):
        """Select output folder."""
        folder_path = filedialog.askdirectory(title="Select Output Folder")
        if folder_path:
            self._tab3_output_var.set(folder_path)

    def tab3_select_folder(self):
        """Select input folder for batch processing"""
        folder_path = filedialog.askdirectory(title="Select Input Folder")

        if folder_path:
            self.tab3_input_folder = folder_path
            self._tab3_folder_var.set(folder_path)
            self.tab3_log(f"Input folder selected: {folder_path}")
            self.tab3_check_ready()

    def tab3_load_config(self):
        """Load configuration file for batch processing"""
        file_path = filedialog.askopenfilename(
            title="Load Configuration",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )

        if file_path:
            try:
                with open(file_path, 'r') as f:
                    loaded = json.load(f)

                # Verify it has required keys
                if 'polygon_points' not in loaded or 'pipeline_params' not in loaded:
                    messagebox.showerror("Error",
                                          "Invalid configuration file. Must contain polygon_points and pipeline_params.")
                    self.tab3_config_data = None
                    return

                # REGRESSION FIX (R6): merge pipeline_params onto a fresh
                # copy of the defaults instead of trusting the file to
                # contain every key. A config saved under an older/partial
                # key schema would otherwise raise a KeyError deep inside
                # tab3_process_single_image the first time it's used.
                loaded['pipeline_params'] = self._merge_pipeline_params(loaded['pipeline_params'])
                self.tab3_config_data = loaded

                self.tab3_log(f"Configuration loaded: {file_path}")
                self.tab3_check_ready()
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load configuration: {str(e)}")
                self.tab3_config_data = None

    def tab3_load_roi(self):
        """Load ROI coordinates from JSON file"""
        file_path = filedialog.askopenfilename(
            title="Select ROI Coordinates File",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )

        if file_path:
            try:
                with open(file_path, 'r') as f:
                    data = json.load(f)

                # Can load from either pure ROI file or config file
                if 'polygon_points' in data:
                    self.tab3_roi_points = np.array(data['polygon_points'], dtype=np.int32)
        
                    self.tab3_log(f"ROI coordinates loaded: {file_path} ({len(self.tab3_roi_points)} points)")
                    self.tab3_check_ready()
                else:
                    messagebox.showerror("Error", "Invalid file. Must contain 'polygon_points'.")
                    self.tab3_roi_points = None
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load ROI: {str(e)}")
                self.tab3_roi_points = None

    def tab3_check_ready(self):
        """Check if ready to start batch processing"""
        # Need: input folder + ROI points
        if self.tab3_input_folder and self.tab3_roi_points is not None:
            self._batch3d_start_btn.config(state='normal')
        elif self.tab3_input_folder:
            # Allow start even without explicit ROI; pipeline will use defaults
            self._batch3d_start_btn.config(state='normal')
        else:
            self._batch3d_start_btn.config(state='disabled')

    def tab3_log(self, message):
        """Add message to log (GUI) and mirror it to the terminal in real time.

        This is the single choke point through which ALL batch-processing,
        report-generation and 3D Slicer status/progress/warning/completion
        messages flow (including the ones streamed live from the Slicer
        subprocess in `_batch3d_run_viz`). Mirroring here guarantees that
        every message the user sees in the GUI log is also printed to the
        terminal/console, with no changes required at any call site and no
        change to the existing GUI behaviour.
        """
        # ── Existing GUI behaviour (unchanged) ───────────────────────────
        self.tab3_log_text.insert(tk.END, message + '\n')
        self.tab3_log_text.see(tk.END)
        self.tab3_log_text.update()

        # ── New: real-time terminal/console mirror ───────────────────────
        try:
            timestamp = datetime.now().strftime('%H:%M:%S')
            print(f"[{timestamp}] {message}", flush=True)
        except Exception:
            # Never let a terminal/console print failure break the GUI log.
            try:
                print(message, flush=True)
            except Exception:
                pass

    def tab3_start_batch_processing(self):
        """Start batch processing of images   runs in background thread."""
        if self.tab3_processing:
            return

        self.tab3_processing = True
        self._batch3d_start_btn.config(state='disabled')

        # Collect image files
        image_extensions = ['.png', '.jpg', '.jpeg']
        image_files = [
            os.path.join(self.tab3_input_folder, f)
            for f in os.listdir(self.tab3_input_folder)
            if os.path.isfile(os.path.join(self.tab3_input_folder, f))
            and any(f.lower().endswith(ext) for ext in image_extensions)
        ]

        if not image_files:
            messagebox.showwarning("Warning", "No image files found in selected folder")
            self.tab3_processing = False
            self._batch3d_start_btn.config(state='normal')
            return

        self.tab3_log(f"\nFound {len(image_files)} image(s) to process")

        # Output folders
        output_base = self._tab3_output_var.get()
        if not output_base or output_base == 'Not selected':
            output_base = self.tab3_input_folder
        defects_path     = os.path.join(output_base, "indicators")
        non_defects_path = os.path.join(output_base, "non_indicators")
        os.makedirs(defects_path, exist_ok=True)
        os.makedirs(non_defects_path, exist_ok=True)

        self.tab3_log(f"Output folders:")
        self.tab3_log(f"  - {defects_path}")
        self.tab3_log(f"  - {non_defects_path}")

        # Snapshot config & ROI so the background thread doesn't touch self
        roi_points  = (self.tab3_roi_points.tolist()
                       if self.tab3_roi_points is not None else None)
        config_data = self.tab3_config_data

        # ── Run in background thread so GUI stays responsive ─────────────
        def _run():
            total         = len(image_files)
            defect_count  = 0
            non_defect    = 0
            # Determine worker count: min(CPU cores, 4) to stay memory-safe
            import multiprocessing as _mp
            workers = max(1, min(_mp.cpu_count(), 32))
            '''self.root.after(0, lambda: self.tab3_log(
                f"Starting parallel processing with {workers} worker(s) "))'''

            # Use ThreadPoolExecutor   safe with Tkinter/OpenCV on all OSes
            # (ProcessPoolExecutor requires picklable args; threads share memory
            #  which is fine since each image write is to a different file)
            from concurrent.futures import ThreadPoolExecutor, as_completed
            futures = {}
            UPDATE_EVERY = max(1, total // 20)   # update UI every ~5 %

            with ThreadPoolExecutor(max_workers=workers) as executor:
                for img_path in image_files:
                    fut = executor.submit(
                        self.tab3_process_single_image,
                        img_path, defects_path, non_defects_path, img_path
                    )
                    futures[fut] = img_path

                for done_idx, fut in enumerate(as_completed(futures), start=1):
                    img_path = futures[fut]
                    fname    = os.path.basename(img_path)
                    try:
                        num_seg = fut.result()
                        if num_seg >= 1:
                            defect_count += 1
                            msg = f"{fname} -> defects ({num_seg} segments)"
                        else:
                            non_defect += 1
                            msg = f"{fname} -> non_defects"
                    except Exception as exc:
                        msg = f"{fname} -> ERROR: {exc}"

                    # Free result memory immediately
                    del fut
                    gc.collect()

                    # Throttle UI updates to avoid flooding the GUI thread
                    if done_idx % UPDATE_EVERY == 0 or done_idx == total:
                        progress = (done_idx / total) * 100
                        _msg = msg  # capture for lambda
                        _di  = done_idx
                        def _update(p=progress, m=_msg, di=_di):
                            self._batch3d_progress['value'] = p
                            self._batch3d_status_lbl.config(
                                text=f"Processing {di}/{total} ")
                            self.tab3_log(m)
                        self.root.after(0, _update)
                    else:
                        _msg = msg
                        self.root.after(0, lambda m=_msg: self.tab3_log(m))

            # ── Done ─────────────────────────────────────────────────────
            def _finish():
                self._batch3d_progress['value'] = 100
                self._batch3d_status_lbl.config(text="Processing Complete!")
                self.tab3_log(f"\n=== Processing Complete ===")
                self.tab3_log(f"Total: {total}  |  Defects: {defect_count}  |  Non-defects: {non_defect}")
                self.tab3_processing = False
                self._batch3d_start_btn.config(state='normal')
                messagebox.showinfo("Complete",
                    f"Batch processing complete!\n\n"
                    f"Processed : {total} images\n"
                    f"Defects   : {defect_count}\n"
                    f"Non-defects: {non_defect}")
            self.root.after(0, _finish)

        threading.Thread(target=_run, daemon=True).start()

    def tab3_process_single_image(self, image_path, defects_folder, non_defects_folder, filename):
        """Process a single image and save to appropriate folder"""
        # Load image
        cv_image = cv2.imread(image_path)
        if cv_image is None:
            raise ValueError("Failed to load image")

        # Get ROI points - use separately loaded ROI if available
        if self.tab3_roi_points is not None:
            roi_points = self.tab3_roi_points
        elif self.tab3_config_data and 'polygon_points' in self.tab3_config_data:
            roi_points = np.array(self.tab3_config_data['polygon_points'], dtype=np.int32)
        else:
            # No ROI defined – use full image as ROI
            h, w = cv_image.shape[:2]
            roi_points = np.array([[0, 0], [w-1, 0], [w-1, h-1], [0, h-1]], dtype=np.int32)

        # Get parameters from config, or fall back to built-in defaults
        # Keys match exactly those used by the Single Image (Tab 2) pipeline.
        # REGRESSION FIX (R4): this used to be a second, independently
        # hand-maintained copy of the defaults that had drifted from the one
        # in ui/tabs.py. Both now deep-copy the single source of truth in
        # utils/constants.py.
        if self.tab3_config_data and 'pipeline_params' in self.tab3_config_data:
            params = self.tab3_config_data['pipeline_params']
        else:
            params = copy.deepcopy(DEFAULT_PIPELINE_PARAMS)
        # Step 1: Apply ROI mask
        mask = np.zeros(cv_image.shape[:2], dtype=np.uint8)
        cv2.fillPoly(mask, [roi_points], 255)
        masked_image = cv_image.copy()
        masked_image[mask == 0] = [0, 0, 0]

        # Step 2: Rotate / Flip
        rotated_bgr = masked_image.copy()
        if params.get('step_2_rotate_flip', {}).get('enabled', False):
            angle = params['step_2_rotate_flip'].get('rotate', 0)
            if angle != 0:
                h, w = rotated_bgr.shape[:2]
                M_rot = cv2.getRotationMatrix2D((w // 2, h // 2), -angle, 1.0)
                rotated_bgr = cv2.warpAffine(rotated_bgr, M_rot, (w, h),
                                             borderMode=cv2.BORDER_CONSTANT,
                                             borderValue=(0, 0, 0))
            if params['step_2_rotate_flip'].get('flip_h', False):
                rotated_bgr = cv2.flip(rotated_bgr, 1)
            if params['step_2_rotate_flip'].get('flip_v', False):
                rotated_bgr = cv2.flip(rotated_bgr, 0)

        # Step 3: Grayscale
        gray = cv2.cvtColor(rotated_bgr, cv2.COLOR_BGR2GRAY)

        # Step 4: Sobel gradient
        if params.get('step_4_sobel', {}).get('enabled', True):
            sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
            sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
            elevation_map = np.hypot(sobel_x, sobel_y)
            elevation_display = cv2.normalize(elevation_map, None, 0, 255,
                                              cv2.NORM_MINMAX).astype(np.uint8)
        else:
            elevation_display = gray
            
        # Step 5: Topography Surface Generation
        # REGRESSION FIX (R5): ported the Gaussian-division preprocessing
        # from processing/single.py -- this batch copy previously ran
        # Step 5 straight off raw `gray`, silently ignoring
        # gaussian_division_enabled / gaussian_sigma, so Batch and Single
        # Image gave different results for the same config.
        topo_params = params.get('step_5_topography', {})
        gaussian_div_enabled = topo_params.get('gaussian_division_enabled', True)
        gaussian_sigma = max(0.1, float(topo_params.get('gaussian_sigma', 50.0)))

        if gaussian_div_enabled:
            gray_float = gray.astype(np.float32)
            gaussian_background = cv2.GaussianBlur(
                gray_float, (0, 0), sigmaX=gaussian_sigma, sigmaY=gaussian_sigma
            )
            gaussian_background = np.maximum(gaussian_background, 1.0)
            gaussian_div = cv2.divide(gray_float, gaussian_background)
            step5_gray = cv2.normalize(gaussian_div, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        else:
            step5_gray = gray.copy()

        if topo_params.get('enabled', True):
            use_gradient = topo_params.get('use_gradient', False)
            peak_ratio = float(topo_params.get('peak_threshold_ratio', 0.5))
            peak_cutoff = int(round(peak_ratio * 255))
            _, filtered_mask = cv2.threshold(step5_gray, peak_cutoff, 255, cv2.THRESH_BINARY)
            if use_gradient:
                flooding_surface = cv2.morphologyEx(
                    step5_gray, cv2.MORPH_GRADIENT,
                    cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
                ).astype(np.float32)
            else:
                flooding_surface = -cv2.distanceTransform(filtered_mask, cv2.DIST_L2, 5)
        else:
            _, filtered_mask = cv2.threshold(step5_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
            flooding_surface = step5_gray.astype(np.float32)

        # Step 6: Peak Marker Separation, Compactness & Connectivity Watershed
        # REGRESSION FIX (R5): ported the fixed <90/>220 defect-threshold
        # mask and step6_defect_mask computation from single.py. Previously
        # this batch copy computed `segmentation_labels` and then never
        # used it for anything -- pure wasted CPU/memory on every image,
        # a likely contributor to the "Killed" (OOM) batch failures.
        STEP6_LOW_THRESHOLD = 90
        STEP6_HIGH_THRESHOLD = 220
        low_defect_mask = step5_gray < STEP6_LOW_THRESHOLD
        high_defect_mask = step5_gray > STEP6_HIGH_THRESHOLD
        threshold_defect_mask = np.logical_or(low_defect_mask, high_defect_mask).astype(np.uint8) * 255

        topo_ws_params = params.get('step_6_topo_watershed', {})
        if topo_ws_params.get('enabled', True):
            min_distance = max(1, int(topo_ws_params.get('min_distance', 5)))
            compactness = float(topo_ws_params.get('compactness', 0.0))
            connectivity = int(topo_ws_params.get('connectivity', 1))

            integrated_mask = cv2.bitwise_or(filtered_mask, threshold_defect_mask)

            selem = disk(min_distance)
            ret, topo_markers = cv2.connectedComponents(integrated_mask)
            topo_markers = topo_markers + 1
            unknown = cv2.subtract(cv2.dilate(integrated_mask, selem, iterations=1), integrated_mask)
            topo_markers[unknown == 255] = 0
            conn_footprint = disk(connectivity) if connectivity > 1 else None

            segmentation_labels = _skimage_watershed(
                flooding_surface, topo_markers,
                mask=integrated_mask.astype(bool), compactness=compactness,
                connectivity=conn_footprint
            )
            step6_defect_mask = np.logical_and(
                segmentation_labels > 0, threshold_defect_mask > 0
            ).astype(np.uint8)
        else:
            segmentation_labels = threshold_defect_mask.copy()
            step6_defect_mask = (threshold_defect_mask > 0).astype(np.uint8)

        # Step 7: Histogram markers
        #high_thresh = 150  # default fallback
        #foreground_mask = gray > high_thresh  # default fallback
        if params.get('step_7_markers', {}).get('enabled', True):
            low_thresh  = params['step_7_markers'].get('low_threshold', 30)
            high_thresh = params['step_7_markers'].get('high_threshold', 150)

            inv = 255 - gray
            background = cv2.GaussianBlur(inv, (0, 0), sigmaX=50, sigmaY=50)
            gbImg = cv2.subtract(inv, background)
            _, gb = cv2.threshold(gbImg, 10, 255, cv2.THRESH_BINARY)

            markers = np.zeros_like(gray, dtype=np.int32)
            background_mask = gray < low_thresh
            markers[background_mask] = gb[background_mask]
            foreground_mask = gray > high_thresh
            markers[foreground_mask] = gray[foreground_mask].astype(np.int32) + 1
        else:
            markers = np.zeros_like(gray, dtype=np.int32)
            markers[gray > 0] = gray[gray > 0].astype(np.int32) + 1

        # Step 8: Watershed
        if params.get('step_8_watershed', {}).get('enabled', True):
            elevation_map_color = cv2.cvtColor(elevation_display, cv2.COLOR_GRAY2BGR)
            markers_watershed = markers.copy()
            segmentation = cv2.watershed(elevation_map_color, markers_watershed)
        else:
            segmentation = markers.copy()

        # Convert segmentation to binary.
        # FIX: watershed labels can span the entire image (no true background seeds),
        # so thresholding on label values captures everything    one giant blob > max_area.
        # Instead, use the foreground_mask (bright defect pixels) directly, then let
        # morphological steps clean / separate the regions.
        if params.get('step_7_markers', {}).get('enabled', True):
            # binary_seg = (segmentation > high_thresh).astype(np.uint8)
            high_thresh = params['step_7_markers'].get('high_threshold', 150)
            binary_seg = (segmentation > high_thresh).astype(np.uint8)
        else:
            binary_seg = (segmentation > 0).astype(np.uint8)

        # REGRESSION FIX (R5): fold in the Step 6 topography defect mask
        # (union, so it can only add detections on top of the original
        # markers/watershed path, never remove ones already found) --
        # mirrors the same fix in processing/single.py.
        step5_enabled = params.get('step_5_topography', {}).get('enabled', True)
        step6_enabled = params.get('step_6_topo_watershed', {}).get('enabled', True)
        if step5_enabled or step6_enabled:
            binary_seg = cv2.bitwise_or(binary_seg, step6_defect_mask.astype(np.uint8))

        # Step 9: Morphological Close
        if params.get('step_9_morph_close', {}).get('enabled', True):
            iterations = params['step_9_morph_close'].get('iterations', 1)
            kernel = np.ones((3, 3), np.uint8)
            morph_close = cv2.morphologyEx(binary_seg, cv2.MORPH_CLOSE, kernel,
                                           iterations=iterations)
        else:
            morph_close = binary_seg.copy()

        # Step 10: Morphological Open
        if params.get('step_10_morph_open', {}).get('enabled', True):
            iterations = params['step_10_morph_open'].get('iterations', 1)
            kernel = np.ones((3, 3), np.uint8)
            morph_open = cv2.morphologyEx(morph_close, cv2.MORPH_OPEN, kernel,
                                          iterations=iterations)
        else:
            morph_open = morph_close.copy()

        # Step 11: Fill holes
        if params.get('step_11_fillholes', {}).get('enabled', True):
            filled = ndi.binary_fill_holes(morph_open).astype(np.uint8) * 255
        else:
            filled = morph_open * 255

        # Step 12: Label components
        # REGRESSION FIX (R2, CRITICAL): this used to read/write
        # 'step_10_labeling', a stale key left over from the pre-rename
        # 12-step scheme. The correct 14-step key is 'step_12_labeling'.
        # Since the built-in fallback params dict never contained
        # 'step_10_labeling' at all, `params['step_10_labeling']` raised a
        # KeyError on essentially every batch-processed image -- this was
        # the direct cause of "Batch Processing is broken".
        if params.get('step_12_labeling', {}).get('enabled', True):
            labeled_array, num_features = ndi.label(filled)
            min_size = params['step_12_labeling'].get('min_size', 50)
            sizes = np.bincount(labeled_array.ravel())
            mask_sizes = sizes > min_size
            mask_sizes[0] = 0
            cleaned_labels = mask_sizes[labeled_array]
            labeled_cleaned, num_cleaned = ndi.label(cleaned_labels)
        else:
            labeled_cleaned, num_cleaned = ndi.label(filled)

        # Step 13: Color valid segments on original image
        result = cv_image.copy()
        segment_color = (0, 0, 255)  # Red in BGR
        min_area = params.get('step_13_final', {}).get('min_area', 50)
        max_area = params.get('step_13_final', {}).get('max_area', 10000)

        valid_segments = 0
        for region_label in range(1, num_cleaned + 1):
            region_mask = (labeled_cleaned == region_label).astype(np.uint8) * 255
            contours, _ = cv2.findContours(region_mask, cv2.RETR_EXTERNAL,
                                           cv2.CHAIN_APPROX_SIMPLE)
            if contours:
                for contour in contours:
                    area = cv2.contourArea(contour)
                    if min_area <= area <= max_area:
                        valid_segments += 1
                        cv2.drawContours(result, [contour], -1, segment_color, -1)

        # Save to appropriate folder
        filename = os.path.basename(filename)

        # Step 14: Perspective Warp   apply before saving
        warp_enabled = params.get('step_14_perspective', {}).get('enabled', True)
        if warp_enabled and roi_points is not None and len(roi_points) >= 4:
            try:
                roi_pts = roi_points.reshape(-1, 2).astype(np.float32)
                s = roi_pts.sum(axis=1)
                d = np.diff(roi_pts, axis=1).ravel()
                tl = roi_pts[np.argmin(s)]
                br = roi_pts[np.argmax(s)]
                tr = roi_pts[np.argmin(d)]
                bl = roi_pts[np.argmax(d)]
                src_quad = np.array([tl, tr, br, bl], dtype=np.float32)
                out_w, out_h = 272*8, 272*8
                dst_quad = np.array([[0, 0], [out_w - 1, 0],
                                     [out_w - 1, out_h - 1], [0, out_h - 1]], dtype=np.float32)
                M = cv2.getPerspectiveTransform(src_quad, dst_quad)
                result = cv2.warpPerspective(result, M, (out_w, out_h),
                                             flags=cv2.INTER_LINEAR,
                                             borderMode=cv2.BORDER_CONSTANT,
                                             borderValue=(0, 0, 0))
            except Exception:
                pass  # if warp fails, fall back to un-warped result

        if valid_segments >= 1:
            output_path = os.path.join(defects_folder, filename)
        else:
            output_path = os.path.join(non_defects_folder, filename)

        cv2.imwrite(output_path, result)

        # ── Explicit memory cleanup   free all intermediate arrays ───────
        # REGRESSION FIX (R7): this used to `del markers, watershed_result,
        # binary` -- neither `watershed_result` nor `binary` are real names
        # in this function (the actual variables are `segmentation` and
        # `binary_seg`), so that block silently did nothing (NameError
        # swallowed by the bare except). It also never freed any of the new
        # Step 5/6 topography intermediates (flooding_surface, filtered_mask,
        # segmentation_labels, topo_markers, unknown, step6_defect_mask,
        # threshold_defect_mask, step5_gray), which are large float32/label
        # arrays created fresh per image. Freeing them explicitly here
        # matters a lot under ThreadPoolExecutor(max_workers=32), where many
        # of these are alive concurrently.
        del cv_image, masked_image, rotated_bgr, gray, result
        del markers, segmentation, binary_seg, morph_close, morph_open, filled
        del step5_gray, filtered_mask, flooding_surface, segmentation_labels
        del threshold_defect_mask, step6_defect_mask
        try:
            del elevation_display, elevation_map
        except Exception:
            pass
        try:
            del topo_markers, unknown, integrated_mask
        except Exception:
            pass
        gc.collect()

        return valid_segments

