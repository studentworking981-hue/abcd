"""Single-image processing pipeline (the original 'Tab 2'): step-by-step
watershed segmentation, topography, parameter update handlers, and
pipeline config save/load. Relocated verbatim from ImageAnalyzerApp in
the original single-file app."""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from PIL import Image, ImageTk
import cv2
import numpy as np
from scipy import ndimage as ndi
from skimage.segmentation import watershed as _skimage_watershed
from skimage.morphology import disk
import copy
import json
import math
import os
import sys
import gc
import threading
from datetime import datetime
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

from .utils.constants import DEFAULT_PIPELINE_PARAMS


class SingleImageMixin:
    """
    Mixin holding methods relocated verbatim from the original
    ``ImageAnalyzerApp`` god-class. It is combined with the other
    mixins in ``app.Application`` via multiple inheritance, so every
    method below still shares the same ``self`` (and therefore the
    same widgets / state) as before -- nothing about how these
    methods call each other or access ``self.*`` attributes changed.
    """

    @staticmethod
    def _merge_pipeline_params(loaded_params):
        """Deep-merge a loaded pipeline_params dict onto a fresh copy of
        DEFAULT_PIPELINE_PARAMS.

        REGRESSION FIX (R6): previously config loading did a straight
        ``self.params = data['pipeline_params']`` replacement. Any config
        file saved under a different/older key schema (missing keys like
        step_5_topography, step_6_topo_watershed, step_14_perspective)
        would then raise a KeyError the next time process_all_steps() ran.
        Merging keeps every default key present, only overriding the
        sub-keys the loaded file actually provides, and silently ignores
        unrecognized legacy keys instead of crashing.
        """
        merged = copy.deepcopy(DEFAULT_PIPELINE_PARAMS)
        if not isinstance(loaded_params, dict):
            return merged
        for step_key, step_defaults in merged.items():
            loaded_step = loaded_params.get(step_key)
            if isinstance(loaded_step, dict):
                step_defaults.update(loaded_step)
        return merged

    def tab2_upload_image(self):
        """Upload image for watershed analysis"""
        file_path = filedialog.askopenfilename(
            title="Select Image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png"),
                       ("All files", "*.*")]
        )

        if file_path:
            self.tab2_image_path = file_path
            self.tab2_cv_image = cv2.imread(file_path)
            self.tab2_image = cv2.cvtColor(self.tab2_cv_image, cv2.COLOR_BGR2RGB)

            # Display the image immediately
            self.step_images = {}
            self.step_images[0] = self.tab2_image.copy()
            self.current_step = 0
            self.display_current_step()

            self.tab2_info_label.config(text="Image loaded. Load ROI coordinates and click Start Processing.")

    def tab2_load_roi(self):
        """Load ROI coordinates from JSON file"""
        file_path = filedialog.askopenfilename(
            title="Select ROI Coordinates File",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )

        if file_path:
            with open(file_path, 'r') as f:
                data = json.load(f)

            self.tab2_roi_points = np.array(data['polygon_points'], dtype=np.int32)

            # Load parameters if they exist in the file.
            # REGRESSION FIX (R6): merge onto a fresh copy of the defaults
            # instead of replacing self.params outright, so a file saved
            # under an older/incomplete key schema (e.g. missing the new
            # step_5_topography / step_6_topo_watershed / step_14_perspective
            # keys) fills in the gaps instead of causing a KeyError deep
            # inside process_all_steps().
            if 'pipeline_params' in data:
                self.params = self._merge_pipeline_params(data['pipeline_params'])

            self.tab2_info_label.config(
                text=f"ROI loaded with {len(self.tab2_roi_points)} points. Click Start Processing."
            )

    def tab2_zoom(self, event):
        """Zoom image with Ctrl+MouseWheel (Windows/macOS: delta; Linux: num)"""
        if self.tab2_image is None:
            return
        # event.delta works on Windows/macOS; on Linux Button-4/5 give delta=0
        if event.delta != 0:
            factor = 1.1 if event.delta > 0 else 0.9
        else:
            # Linux scroll up = Button-4, scroll down = Button-5
            factor = 1.1 if getattr(event, 'num', 0) == 4 else 0.9
        self.tab2_zoom_level *= factor
        self.tab2_zoom_level = max(0.1, min(10.0, self.tab2_zoom_level))
        self._tab2_update_zoom_label()
        if self.current_step == 1:
            self._display_step1_drawing()
        elif self.current_step in self.step_images:
            self.display_current_step()

    def tab2_zoom_button(self, factor):
        """Zoom image with +/- buttons or keys"""
        if self.current_step != 1 and self.current_step not in self.step_images:
            return
        self.tab2_zoom_level *= factor
        self.tab2_zoom_level = max(0.1, min(10.0, self.tab2_zoom_level))
        self._tab2_update_zoom_label()
        self.display_current_step()

    def tab2_zoom_reset(self):
        """Reset zoom to 100%."""
        self.tab2_zoom_level = 1.0
        self._tab2_update_zoom_label()
        self.display_current_step()

    def _tab2_update_zoom_label(self):
        """Refresh the zoom % label in the nav bar."""
        if hasattr(self, 'zoom_label'):
            self.zoom_label.config(text=f"{int(self.tab2_zoom_level * 100)}%")

    def _tab2_drag_zoom_start(self, event):
        """Record start Y position for Ctrl+drag zoom."""
        self._drag_zoom_start_y = event.y
        self._drag_zoom_start_level = self.tab2_zoom_level

    def _tab2_drag_zoom_motion(self, event):
        """Ctrl+drag up = zoom in, drag down = zoom out."""
        if not hasattr(self, '_drag_zoom_start_y'):
            return
        delta = self._drag_zoom_start_y - event.y   # positive = dragged up
        factor = 1.0 + delta * 0.005                # 0.5% per pixel
        new_level = self._drag_zoom_start_level * factor
        self.tab2_zoom_level = max(0.1, min(10.0, new_level))
        self._tab2_update_zoom_label()
        if self.current_step != 1 and self.current_step not in self.step_images:
            return
        self.display_current_step()

    def tab2_step1_canvas_click(self, event):
        """Handle canvas click: only active during Step 1 ROI drawing."""
        if self.current_step != 1:
            return
        if self.tab2_image is None:
            return
        if self.step1_polygon_closed:
            return

        # Convert canvas coords    image coords (account for zoom)
        cx = int(self.tab2_canvas.canvasx(event.x))
        cy = int(self.tab2_canvas.canvasy(event.y))
        x = int(cx / self.tab2_zoom_level)
        y = int(cy / self.tab2_zoom_level)

        # Clamp to image bounds
        h, w = self.tab2_image.shape[:2]
        x = max(0, min(w - 1, x))
        y = max(0, min(h - 1, y))

        # Check if clicking near first point to close polygon
        if len(self.step1_polygon_points) >= 3:
            fp = self.step1_polygon_points[0]
            dist = math.sqrt((x - fp[0])**2 + (y - fp[1])**2)
            if dist <= int(15 / self.tab2_zoom_level):
                self.step1_polygon_closed = True
                self.tab2_roi_points = np.array(self.step1_polygon_points, dtype=np.int32)
                self._step1_auto_save()
                self._display_step1_drawing()
                return

        self.step1_polygon_points.append((x, y))
        self._display_step1_drawing()

    def _step1_auto_save(self):
        """Auto-save ROI coordinates JSON next to the loaded image.
           The config JSON (Save Config) will use the same folder."""
        if self.tab2_image_path is None:
            return
        img_dir  = os.path.dirname(os.path.abspath(self.tab2_image_path))
        img_stem = Path(self.tab2_image_path).stem
        roi_path = os.path.join(img_dir, f"{img_stem}_roi.json")

        data = {
            "image_path":  self.tab2_image_path,
            "image_shape": list(self.tab2_image.shape[:2]),
            "polygon_points": self.step1_polygon_points,
            "pipeline_params": self.params
        }
        with open(roi_path, 'w') as f:
            json.dump(data, f, indent=4)

        # ── Also write a copy to configurations/conf.json so Batch tab
        #    can auto-load it on next startup ──────────────────────────
        try:
            conf_dir = Path(__file__).resolve().parent / 'configurations'
            conf_dir.mkdir(exist_ok=True)
            with open(conf_dir / 'conf.json', 'w') as _cf:
                json.dump(data, _cf, indent=4)
        except Exception:
            pass  # never block the main save if this fails

        # Remember save folder so Save Config lands in same place
        self._roi_save_dir = img_dir
        self.tab2_info_label.config(
            text=f"ROI auto-saved    {roi_path}  |  Click Next to run pipeline.")
        messagebox.showinfo("ROI Saved",
            f"Polygon closed!\n\nCoordinates auto-saved to:\n{roi_path}\n\nClick Next to run the pipeline.")

    def tab2_step1_clear_points(self):
        """Clear Step 1 polygon drawing."""
        self.step1_polygon_points = []
        self.step1_polygon_closed = False
        self.tab2_roi_points = None
        self._display_step1_drawing()

    def tab2_start_processing(self):
        """Start the step-by-step watershed processing.

        Behaviour:
        - If the user has previously clicked 'Load Config' and the config
          contained polygon_points, those points are already stored in
          self.step1_polygon_points / self.step1_polygon_closed.
             Step 1 will open with the saved polygon pre-drawn so the user
            can verify or modify it before proceeding.
        - If no config was loaded (or the config had no polygon), the Step 1
          polygon state is empty and the user draws manually as before.
        """
        if self.tab2_image is None:
            messagebox.showwarning("Warning", "Please upload an image first")
            return

        # ── Determine whether a pre-loaded ROI is available ──────────────
        # (populated by tab2_load_config when JSON contains polygon_points)
        roi_pre_loaded = (
            self.step1_polygon_closed and
            len(self.step1_polygon_points) >= 3
        )

        # If no config was loaded at all, make sure the drawing state is clean
        if not roi_pre_loaded:
            self.tab2_roi_points      = None
            self.step1_polygon_points = []
            self.step1_polygon_closed = False

        # Show Step 0: original image only
        self.step_images = {}
        self.step_images[0] = self.tab2_image.copy()
        self.current_step = 0
        self.display_current_step()

        # Allow moving to Step 1 (ROI draw/review)
        self.next_button.config(state='normal')
        self.prev_button.config(state='disabled')

        if roi_pre_loaded:
            self.tab2_info_label.config(
                text=f"ROI from loaded config pre-filled "
                     f"({len(self.step1_polygon_points)} points). "
                     f"Click Next to review / edit in Step 1, then proceed.")
        else:
            self.tab2_info_label.config(
                text="Step 0 loaded. Click Next to draw ROI polygon in Step 1.")

    def process_all_steps(self):
        """Process all watershed steps using Scikit-Image approach (Sobel + Histogram Markers)"""
        self.step_images = {}
        self.step_data = {}

        # Step 0: Original Image
        self.step_images[0] = self.tab2_image.copy()

        # Step 1: RoI Masked Image (4-point polygon)
        mask = np.zeros(self.tab2_image.shape[:2], dtype=np.uint8)
        cv2.fillPoly(mask, [self.tab2_roi_points], 255)
        masked_image = self.tab2_cv_image.copy()
        masked_image[mask == 0] = [0, 0, 0]
        self.step_images[1] = cv2.cvtColor(masked_image, cv2.COLOR_BGR2RGB)
        self.step_data['mask'] = mask
        self.step_data['masked_bgr'] = masked_image

        # Step 2: Rotate / Flip  (NEW)
        rotated_bgr = masked_image.copy()
        if self.params['step_2_rotate_flip']['enabled']:
            angle = self.params['step_2_rotate_flip']['rotate']
            if angle != 0:
                h, w = rotated_bgr.shape[:2]
                cx, cy = w // 2, h // 2
                M_rot = cv2.getRotationMatrix2D((cx, cy), -angle, 1.0)
                rotated_bgr = cv2.warpAffine(rotated_bgr, M_rot, (w, h),
                                             borderMode=cv2.BORDER_CONSTANT,
                                             borderValue=(0, 0, 0))
            if self.params['step_2_rotate_flip']['flip_h']:
                rotated_bgr = cv2.flip(rotated_bgr, 1)
            if self.params['step_2_rotate_flip']['flip_v']:
                rotated_bgr = cv2.flip(rotated_bgr, 0)
        self.step_images[2] = cv2.cvtColor(rotated_bgr, cv2.COLOR_BGR2RGB)
        self.step_data['rotated_bgr'] = rotated_bgr

        # Step 3: Grayscale Conversion  (was Step 2)
        if self.params['step_3_grayscale']['enabled']:
            gray = cv2.cvtColor(rotated_bgr, cv2.COLOR_BGR2GRAY)
            self.step_images[3] = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
        else:
            gray = cv2.cvtColor(rotated_bgr, cv2.COLOR_BGR2GRAY)
            self.step_images[3] = self.step_images[2].copy()
        self.step_data['gray'] = gray

        # Step 4: Sobel Gradient (Elevation Map)  (was Step 3)
        if self.params['step_4_sobel']['enabled']:
            sobel_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
            sobel_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
            elevation_map = np.hypot(sobel_x, sobel_y)
            elevation_display = cv2.normalize(elevation_map, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        else:
            elevation_map = gray.astype(np.float64)
            elevation_display = gray
        self.step_images[4] = cv2.cvtColor(elevation_display, cv2.COLOR_GRAY2RGB)
        self.step_data['elevation_map'] = elevation_map
        
        # Step 5 + Step 6 integrated segmentation path
        # ---------------------------------------------------------------
        # Gaussian division is applied here as preprocessing. Step 5 builds
        # the topography inputs and Step 6 produces the actual defect mask.
        #
        # IMPORTANT:
        #   Defect pixels are defined as:
        #       gray < 90 OR gray > 220
        #
        # The Step 6 binary defect mask is preserved as `step6_defect_mask`.
        # If Steps 7 and 8 are skipped, this mask is fed DIRECTLY into Step 9.
        # If Steps 7/8 are enabled, the original marker/watershed path remains.
        topo_params = self.params['step_5_topography']

        gaussian_div_enabled = topo_params.get('gaussian_division_enabled', True)
        gaussian_sigma = max(0.1, float(topo_params.get('gaussian_sigma', 50.0)))

        if gaussian_div_enabled:
            gray_float = gray.astype(np.float32)
            gaussian_background = cv2.GaussianBlur(
                gray_float, (0, 0),
                sigmaX=gaussian_sigma,
                sigmaY=gaussian_sigma
            )
            gaussian_background = np.maximum(gaussian_background, 1.0)

            gaussian_div = cv2.divide(gray_float, gaussian_background)
            gaussian_div = cv2.normalize(
                gaussian_div, None, 0, 255, cv2.NORM_MINMAX
            ).astype(np.uint8)
            step5_gray = gaussian_div
        else:
            step5_gray = gray.copy()

        self.step_data['gaussian_division'] = step5_gray

        # Step 5: Topography Surface Generation
        if topo_params['enabled']:
            use_gradient = topo_params['use_gradient']
            peak_ratio = float(topo_params['peak_threshold_ratio'])
            peak_cutoff = int(round(peak_ratio * 255))

            # Keep the original Step 5 foreground-mask behaviour intact,
            # but use the Gaussian-division-preprocessed image when enabled.
            _, filtered_mask = cv2.threshold(
                step5_gray, peak_cutoff, 255, cv2.THRESH_BINARY
            )

            if use_gradient:
                flooding_surface = cv2.morphologyEx(
                    step5_gray,
                    cv2.MORPH_GRADIENT,
                    cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
                ).astype(np.float32)
            else:
                flooding_surface = -cv2.distanceTransform(
                    filtered_mask,
                    cv2.DIST_L2,
                    5
                )

            topo_display = cv2.normalize(
                flooding_surface, None, 0, 255, cv2.NORM_MINMAX
            ).astype(np.uint8)
        else:
            _, filtered_mask = cv2.threshold(
                step5_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
            )
            flooding_surface = step5_gray.astype(np.float32)
            topo_display = step5_gray.copy()

        self.step_images[5] = cv2.cvtColor(topo_display, cv2.COLOR_GRAY2RGB)
        self.step_data['filtered_mask'] = filtered_mask
        self.step_data['flooding_surface'] = flooding_surface

        # Step 6: Integrated watershed + low/high defect segmentation
        topo_ws_params = self.params['step_6_topo_watershed']

        # Required fixed defect thresholds:
        # pixels below 90 OR above 220 are defects.
        STEP6_LOW_THRESHOLD = 90
        STEP6_HIGH_THRESHOLD = 220

        low_defect_mask = step5_gray < STEP6_LOW_THRESHOLD
        high_defect_mask = step5_gray > STEP6_HIGH_THRESHOLD
        threshold_defect_mask = np.logical_or(
            low_defect_mask, high_defect_mask
        ).astype(np.uint8) * 255

        if topo_ws_params['enabled']:
            min_distance = max(1, int(topo_ws_params['min_distance']))
            compactness = float(topo_ws_params['compactness'])
            connectivity = int(topo_ws_params['connectivity'])

            # Integrate the Step 5 mask with the required Step 6 defect mask.
            # This keeps Step 5 involved while ensuring <90 and >220 pixels
            # are always treated as candidate defects.
            integrated_mask = cv2.bitwise_or(
                filtered_mask, threshold_defect_mask
            )

            selem = disk(min_distance)
            _, topo_markers = cv2.connectedComponents(integrated_mask)
            topo_markers = topo_markers + 1

            unknown = cv2.subtract(
                cv2.dilate(integrated_mask, selem, iterations=1),
                integrated_mask
            )
            topo_markers[unknown == 255] = 0

            conn_footprint = disk(connectivity) if connectivity > 1 else None

            segmentation_labels = _skimage_watershed(
                flooding_surface,
                topo_markers,
                mask=integrated_mask.astype(bool),
                compactness=compactness,
                connectivity=conn_footprint
            )

            # Final Step 6 defect segmentation is restricted to the explicit
            # defect rule requested by the user: <90 OR >220.
            step6_defect_mask = np.logical_and(
                segmentation_labels > 0,
                threshold_defect_mask > 0
            ).astype(np.uint8)

            topo_ws_display = np.zeros(
                (gray.shape[0], gray.shape[1], 3), dtype=np.uint8
            )
            topo_ws_display[step6_defect_mask > 0] = [255, 0, 0]
        else:
            # Even when Step 6 watershed itself is skipped, preserve the
            # threshold segmentation so downstream morphology can still run.
            segmentation_labels = threshold_defect_mask.copy()
            step6_defect_mask = (
                threshold_defect_mask > 0
            ).astype(np.uint8)

            topo_ws_display = np.zeros(
                (gray.shape[0], gray.shape[1], 3), dtype=np.uint8
            )
            topo_ws_display[step6_defect_mask > 0] = [255, 0, 0]

        self.step_images[6] = topo_ws_display
        self.step_data['topo_markers_labels'] = segmentation_labels
        self.step_data['step6_defect_mask'] = step6_defect_mask
        self.step_data['step6_low_threshold'] = STEP6_LOW_THRESHOLD
        self.step_data['step6_high_threshold'] = STEP6_HIGH_THRESHOLD

        # Step 7: Histogram-based Markers  (was Step 4)
        if self.params['step_7_markers']['enabled']:
            low_thresh  = self.params['step_7_markers']['low_threshold']
            high_thresh = self.params['step_7_markers']['high_threshold']

            inv = 255 - gray
            background = cv2.GaussianBlur(inv, (0, 0), sigmaX=50, sigmaY=50)
            gbImg = cv2.subtract(inv, background)
            _, gb = cv2.threshold(gbImg, 10, 255, cv2.THRESH_BINARY)

            markers = np.zeros_like(gray, dtype=np.int32)
            background_mask = gray < low_thresh
            markers[background_mask] = gb[background_mask]

            foreground_mask = gray > high_thresh
            markers[foreground_mask] = gray[foreground_mask].astype(np.int32) + 1

            markers_display = np.zeros_like(gray)
            markers_display[background_mask] = gb[background_mask]
            markers_display[foreground_mask] = gray[foreground_mask]
        else:
            markers = np.zeros_like(gray, dtype=np.int32)
            markers[gray > 0] = gray[gray > 0].astype(np.int32) + 1
            markers_display = gray.copy()

        self.step_images[7] = cv2.cvtColor(markers_display, cv2.COLOR_GRAY2RGB)
        self.step_data['markers'] = markers

        # Step 8: Watershed Application  (was Step 5)
        if self.params['step_8_watershed']['enabled']:
            elevation_map_uint8 = elevation_display
            elevation_map_color = cv2.cvtColor(elevation_map_uint8, cv2.COLOR_GRAY2BGR)
            markers_watershed = markers.copy()
            segmentation = cv2.watershed(elevation_map_color, markers_watershed)

            watershed_display = np.zeros_like(self.step_data['rotated_bgr'])
            watershed_display[segmentation == 1]  = [50, 50, 50]
            watershed_display[segmentation == 2]  = [0, 200, 0]
            watershed_display[segmentation == -1] = [255, 0, 0]
            watershed_display[segmentation == 0]  = [0, 0, 0]
        else:
            segmentation = markers.copy()
            watershed_display = self.step_data['rotated_bgr'].copy()

        self.step_images[8] = cv2.cvtColor(watershed_display, cv2.COLOR_BGR2RGB)
        self.step_data['segmentation'] = segmentation

        # Convert segmentation to binary
        if self.params['step_7_markers']['enabled']:
            high_thresh = self.params['step_7_markers']['high_threshold']
            binary_seg = (segmentation > high_thresh).astype(np.uint8)
        else:
            binary_seg = (segmentation > 0).astype(np.uint8)

        # REGRESSION FIX (R5): Step 5/6 (topography + Gaussian division +
        # integrated topo-watershed) previously computed `step6_defect_mask`
        # and then never used it again -- Step 7 onward worked purely off
        # the old markers/watershed path, making the new steps pure dead
        # weight with zero effect on the final result. Folding the Step 6
        # defect mask in here (union, so Step 6 can only ADD detections,
        # never remove ones the original pipeline already found) is what
        # lets the new topography stage actually improve on ZIP1 instead of
        # just costing extra CPU/memory for nothing.
        if self.params['step_6_topo_watershed']['enabled'] or self.params['step_5_topography']['enabled']:
            binary_seg = cv2.bitwise_or(
                binary_seg,
                self.step_data['step6_defect_mask'].astype(np.uint8)
            )

        # Step 9: Morphological Close  (was Step 6)
        if self.params['step_9_morph_close']['enabled']:
            iterations = self.params['step_9_morph_close']['iterations']
            kernel = np.ones((3, 3), np.uint8)
            morph_close = cv2.morphologyEx(binary_seg, cv2.MORPH_CLOSE, kernel, iterations=iterations)
        else:
            morph_close = binary_seg.copy()

        self.step_images[9] = cv2.cvtColor(morph_close * 255, cv2.COLOR_GRAY2RGB)
        self.step_data['morph_close'] = morph_close

        # Step 10: Morphological Open  (was Step 7)
        if self.params['step_10_morph_open']['enabled']:
            iterations = self.params['step_10_morph_open']['iterations']
            kernel = np.ones((3, 3), np.uint8)
            morph_open = cv2.morphologyEx(morph_close, cv2.MORPH_OPEN, kernel, iterations=iterations)
        else:
            morph_open = morph_close.copy()

        self.step_images[10] = cv2.cvtColor(morph_open * 255, cv2.COLOR_GRAY2RGB)
        self.step_data['morph_open'] = morph_open

        # Step 11: Fill Holes  (was Step 8)
        if self.params['step_11_fillholes']['enabled']:
            filled = ndi.binary_fill_holes(morph_open).astype(np.uint8) * 255
        else:
            filled = morph_open * 255

        self.step_images[11] = cv2.cvtColor(filled, cv2.COLOR_GRAY2RGB)
        self.step_data['filled'] = filled

        # Step 12: Label Connected Components  (was Step 9)
        if self.params['step_12_labeling']['enabled']:
            labeled_array, num_features = ndi.label(filled)
            min_size = self.params['step_12_labeling']['min_size']
            sizes = np.bincount(labeled_array.ravel())
            mask_sizes = sizes > min_size
            mask_sizes[0] = 0
            cleaned_labels = mask_sizes[labeled_array]
            labeled_cleaned, num_cleaned = ndi.label(cleaned_labels)
            labeled_display = cv2.normalize(labeled_cleaned, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            labeled_colored = cv2.applyColorMap(labeled_display, cv2.COLORMAP_JET)
        else:
            labeled_cleaned, num_cleaned = ndi.label(filled)
            labeled_display = cv2.normalize(labeled_cleaned, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
            labeled_colored = cv2.applyColorMap(labeled_display, cv2.COLORMAP_JET)

        self.step_images[12] = cv2.cvtColor(labeled_colored, cv2.COLOR_BGR2RGB)
        self.step_data['labeled'] = labeled_cleaned
        self.step_data['num_labels'] = num_cleaned

        # Step 13: Final Result with Colored Segments  (was Step 10)
        result = self.tab2_cv_image.copy()
        min_area = self.params['step_13_final']['min_area']
        max_area = self.params['step_13_final']['max_area']
        segment_color = (0, 0, 255)

        for region_label in range(1, self.step_data['num_labels'] + 1):
            region_mask = (labeled_cleaned == region_label).astype(np.uint8) * 255
            contours, _ = cv2.findContours(region_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            if contours:
                for contour in contours:
                    area = cv2.contourArea(contour)
                    if min_area <= area <= max_area:
                        cv2.drawContours(result, [contour], -1, segment_color, -1)

        self.step_images[13] = cv2.cvtColor(result, cv2.COLOR_BGR2RGB)

        # Step 14: Perspective Warp  (was Step 11)
        if self.params['step_14_perspective']['enabled'] and self.tab2_roi_points is not None:
            roi_pts = self.tab2_roi_points.reshape(-1, 2).astype(np.float32)
            s = roi_pts.sum(axis=1)
            d = np.diff(roi_pts, axis=1).ravel()
            tl = roi_pts[np.argmin(s)]
            br = roi_pts[np.argmax(s)]
            tr = roi_pts[np.argmin(d)]
            bl = roi_pts[np.argmax(d)]
            src_quad = np.array([tl, tr, br, bl], dtype=np.float32)
            out_w = 272*8
            out_h = 272*8
            dst_quad = np.array([[0, 0], [out_w - 1, 0],
                                 [out_w - 1, out_h - 1], [0, out_h - 1]], dtype=np.float32)
            M = cv2.getPerspectiveTransform(src_quad, dst_quad)
            warped = cv2.warpPerspective(result, M, (out_w, out_h),
                                         flags=cv2.INTER_LINEAR,
                                         borderMode=cv2.BORDER_CONSTANT,
                                         borderValue=(0, 0, 0))
        else:
            warped = result.copy()

        self.step_images[14] = cv2.cvtColor(warped, cv2.COLOR_BGR2RGB)
        self.step_data['warped'] = warped

    def display_current_step(self):
        """Display the current step's image and parameters"""
        # Step 1 is interactive: display it even before step_images[1] exists
        if self.current_step == 1:
            self._display_step1_drawing()
            return

        if self.current_step not in self.step_images:
            return

        # Update step info
        step_names = [
            "Step 0: Original Image",
            "Step 1: RoI Selection (4-Point Polygon)",
            "Step 2: Rotate / Flip",
            "Step 3: Grayscale Conversion",
            "Step 4: Sobel Gradient (Elevation Map)",
            "Step 5: Topography Surface Style & Peak Threshold Ratio",
            "Step 6: Marker Separation, Compactness & Connectivity",
            "Step 7: Histogram Markers",
            "Step 8: Watershed Application",
            "Step 9: Morphological Close",
            "Step 10: Morphological Open",
            "Step 11: Fill Holes",
            "Step 12: Connected Component Labeling",
            "Step 13: Final Result",
            "Step 14: Perspective Warp"
        ]

        step_descriptions = [
            "Original loaded image without any processing.",
            "Image with Area of Interest applied. Regions outside the 4-point polygon are blacked out.",
            "Rotate and/or flip the masked image before further processing.",
            "Image converted to grayscale for processing.",
            "Sobel gradient (elevation map) computed. High gradient values form barriers between regions.",
            "Topography (flooding surface) generated as either a distance transform or morphological "
            "gradient, with a foreground peak detection cutoff threshold ratio setting the mask.",
            "Peak markers generated from the topography surface, with minimum separation distance, "
            "watershed compactness regularization, and connectivity footprint applied."
            "Markers with varying values: background uses low intensities, foreground uses high intensities.",
            "Watershed algorithm floods elevation map from markers. Boundaries marked in red.",
            "Morphological closing to fill small holes and connect nearby objects.",
            "Morphological opening to remove small noise and separate touching objects.",
            "Binary fill holes removes small holes in detected foreground regions.",
            "Connected component labeling identifies individual objects. Small objects filtered out.",
            "Final result with detected segments colored in red.",
            "Perspective warp: ROI polygon corners mapped to a flat rectangle for top-down indicator view."
        ]

        self.step_name_label.config(text=step_names[self.current_step])
        self.step_desc_label.config(text=step_descriptions[self.current_step])
        self.progress_label.config(text=f"Step {self.current_step} / 14")

        # Hide placeholder
        self._img_placeholder.place_forget()

        # Display image
        image = self.step_images[self.current_step]
        pil_img = Image.fromarray(image)
        new_width = int(pil_img.width * self.tab2_zoom_level)
        new_height = int(pil_img.height * self.tab2_zoom_level)
        pil_img = pil_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        self.tab2_photo = ImageTk.PhotoImage(pil_img)

        self.tab2_canvas.delete("all")
        self.tab2_canvas.create_image(0, 0, anchor='nw', image=self.tab2_photo)
        self.tab2_canvas.configure(scrollregion=self.tab2_canvas.bbox("all"))

        # Update parameter controls
        self.update_parameter_controls()

        # Update navigation buttons
        self.prev_button.config(state='normal' if self.current_step > 0 else 'disabled')
        self.next_button.config(state='normal' if self.current_step < 14 else 'disabled')

        # Update step pills
        self._update_step_pills()

    def _display_step1_drawing(self):
        """Render Step 1 interactive ROI drawing on the main tab2 canvas."""
        step_names = ["Step 0: Original Image",
                      "Step 1: RoI Selection (Draw Polygon)",]
        self.step_name_label.config(text="Step 1: RoI Selection (Draw Polygon)")
        self.step_desc_label.config(
            text="Click on the image to place polygon points. "
                 "Click near the first point (green circle) to close the polygon.")
        self.progress_label.config(text="Step 1 / 14")
        self._img_placeholder.place_forget()

        # Draw original image with polygon overlay
        display_img = self.tab2_image.copy()
        pts = self.step1_polygon_points
        zoom = self.tab2_zoom_level

        if len(pts) > 0:
            # Draw lines between consecutive points
            for i in range(len(pts) - 1):
                p1 = (int(pts[i][0] * zoom), int(pts[i][1] * zoom))
                p2 = (int(pts[i+1][0] * zoom), int(pts[i+1][1] * zoom))
                cv2.line(display_img, pts[i], pts[i+1], (0, 255, 0), 2)
            if self.step1_polygon_closed:
                cv2.line(display_img, pts[-1], pts[0], (0, 255, 0), 2)
                # Fill polygon overlay semi-transparent style (solid tint)
                overlay = display_img.copy()
                pts_arr = np.array(pts, dtype=np.int32)
                cv2.fillPoly(overlay, [pts_arr], (0, 255, 0))
                cv2.addWeighted(overlay, 0.15, display_img, 0.85, 0, display_img)
                cv2.polylines(display_img, [pts_arr], True, (0, 255, 0), 2)
            # Draw point circles
            for idx, pt in enumerate(pts):
                color = (255, 215, 0) if idx == 0 else (255, 0, 0)
                cv2.circle(display_img, pt, 7, color, -1)
                cv2.circle(display_img, pt, 8, (255, 255, 255), 2)
                cv2.putText(display_img, str(idx + 1), (pt[0]+10, pt[1]-6),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 255, 255), 1)

        pil_img = Image.fromarray(display_img)
        new_width  = int(pil_img.width  * self.tab2_zoom_level)
        new_height = int(pil_img.height * self.tab2_zoom_level)
        pil_img = pil_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        self.tab2_photo = ImageTk.PhotoImage(pil_img)

        self.tab2_canvas.delete("all")
        self.tab2_canvas.create_image(0, 0, anchor='nw', image=self.tab2_photo)
        self.tab2_canvas.configure(scrollregion=self.tab2_canvas.bbox("all"))

        # Update right panel controls for step 1
        self.update_parameter_controls()

        # Nav buttons
        self.prev_button.config(state='normal')
        self.next_button.config(state='normal')
        self._update_step_pills()

        # Update info label
        if self.step1_polygon_closed:
            self.tab2_info_label.config(
                text=f"Polygon closed with {len(pts)} points. "
                     f"Coordinates auto-saved. Click Next to run pipeline.")
        elif len(pts) == 0:
            self.tab2_info_label.config(
                text="Step 1: Click on the image to place ROI polygon points.")
        elif len(pts) < 3:
            self.tab2_info_label.config(
                text=f"Points placed: {len(pts)}. Need at least 3 points.")
        else:
            self.tab2_info_label.config(
                text=f"Points placed: {len(pts)}. Click near point 1 (gold circle) to close polygon.")

    def update_step2_rotate(self, rot_var):
        """Update step 2 rotation angle"""
        try:
            value = int(rot_var.get())
            value = max(-180, min(180, value))
            rot_var.set(value)
            self.params['step_2_rotate_flip']['rotate'] = value
            self.process_all_steps()
            self.display_current_step()
        except ValueError:
            rot_var.set(self.params['step_2_rotate_flip']['rotate'])

    def update_step2_flip(self, flip_h_var, flip_v_var):
        """Update step 2 flip flags"""
        if flip_h_var is not None:
            self.params['step_2_rotate_flip']['flip_h'] = flip_h_var.get()
        if flip_v_var is not None:
            self.params['step_2_rotate_flip']['flip_v'] = flip_v_var.get()
        self.process_all_steps()
        self.display_current_step()

    def update_step5_gaussian_division(self, enabled_var=None, sigma_var=None):
        """Update Gaussian division preprocessing used before Steps 5 and 6."""
        if enabled_var is not None:
            self.params['step_5_topography']['gaussian_division_enabled'] = bool(enabled_var.get())
        if sigma_var is not None:
            try:
                self.params['step_5_topography']['gaussian_sigma'] = max(
                    0.1, float(sigma_var.get())
                )
            except (tk.TclError, ValueError):
                return
        self.process_all_steps()
        self.display_current_step()

    def update_step5_topography(self, gradient_var, ratio_var):
        """Update step 5 topography surface style / peak threshold ratio"""
        try:
            if gradient_var is not None:
                self.params['step_5_topography']['use_gradient'] = gradient_var.get()
            if ratio_var is not None:
                value = max(0.0, min(1.0, float(ratio_var.get())))
                ratio_var.set(value)
                self.params['step_5_topography']['peak_threshold_ratio'] = value
            self.process_all_steps()
            self.display_current_step()
        except (ValueError, tk.TclError):
            if ratio_var is not None:
                ratio_var.set(self.params['step_5_topography']['peak_threshold_ratio'])

    def update_step6_topo_watershed(self, dist_var, compactness_var, connectivity_var):
        """Update step 6 min separation distance / compactness / connectivity"""
        try:
            if dist_var is not None:
                value = max(1, min(30, int(dist_var.get())))
                dist_var.set(value)
                self.params['step_6_topo_watershed']['min_distance'] = value
            if compactness_var is not None:
                value = max(0.0, min(1.0, float(compactness_var.get())))
                compactness_var.set(value)
                self.params['step_6_topo_watershed']['compactness'] = value
            if connectivity_var is not None:
                value = max(1, min(8, int(connectivity_var.get())))
                connectivity_var.set(value)
                self.params['step_6_topo_watershed']['connectivity'] = value
            self.process_all_steps()
            self.display_current_step()
        except (ValueError, tk.TclError):
            if dist_var is not None:
                dist_var.set(self.params['step_6_topo_watershed']['min_distance'])
            if compactness_var is not None:
                compactness_var.set(self.params['step_6_topo_watershed']['compactness'])
            if connectivity_var is not None:
                connectivity_var.set(self.params['step_6_topo_watershed']['connectivity'])    

    def update_step7_params(self, low_var, high_var):
        """Update step 7 threshold parameters"""
        try:
            if low_var:
                value = max(0, min(255, int(low_var.get())))
                low_var.set(value)
                self.params['step_7_markers']['low_threshold'] = value
            if high_var:
                value = max(0, min(255, int(high_var.get())))
                high_var.set(value)
                self.params['step_7_markers']['high_threshold'] = value
            self.process_all_steps()
            self.display_current_step()
        except ValueError:
            if low_var:
                low_var.set(self.params['step_7_markers']['low_threshold'])
            if high_var:
                high_var.set(self.params['step_7_markers']['high_threshold'])

    def update_step9_iterations(self, iter_var):
        """Update step 9 morphological close iterations"""
        try:
            value = max(1, min(10, int(iter_var.get())))
            iter_var.set(value)
            self.params['step_9_morph_close']['iterations'] = value
            self.process_all_steps()
            self.display_current_step()
        except ValueError:
            iter_var.set(self.params['step_9_morph_close']['iterations'])

    def update_step10_iterations(self, iter_var):
        """Update step 10 morphological open iterations"""
        try:
            value = max(1, min(10, int(iter_var.get())))
            iter_var.set(value)
            self.params['step_10_morph_open']['iterations'] = value
            self.process_all_steps()
            self.display_current_step()
        except ValueError:
            iter_var.set(self.params['step_10_morph_open']['iterations'])

    def update_step12_size(self, size_var):
        """Update step 12 minimum size"""
        try:
            value = max(0, min(200, int(size_var.get())))
            size_var.set(value)
            self.params['step_12_labeling']['min_size'] = value
            self.process_all_steps()
            self.display_current_step()
        except ValueError:
            size_var.set(self.params['step_12_labeling']['min_size'])

    def update_step13_min_area(self, area_var):
        """Update step 13 minimum area"""
        try:
            value = max(0, min(1500, int(area_var.get())))
            area_var.set(value)
            self.params['step_13_final']['min_area'] = value
            self.process_all_steps()
            self.display_current_step()
        except ValueError:
            area_var.set(self.params['step_13_final']['min_area'])

    def update_step13_max_area(self, area_var):
        """Update step 13 maximum area"""
        try:
            value = max(1000, min(50000, int(area_var.get())))
            area_var.set(value)
            self.params['step_13_final']['max_area'] = value
            self.process_all_steps()
            self.display_current_step()
        except ValueError:
            area_var.set(self.params['step_13_final']['max_area'])

    def tab2_save_config(self):
        """Save current configuration to JSON.
           Defaults to the same folder as the auto-saved ROI JSON."""
        if self.tab2_roi_points is None:
            messagebox.showwarning("Warning",
                "No ROI defined yet. Please complete Step 1 ROI drawing first.")
            return

        # Default save directory = same as ROI auto-save (next to image)
        init_dir = getattr(self, '_roi_save_dir', None)
        if init_dir is None and self.tab2_image_path:
            init_dir = os.path.dirname(os.path.abspath(self.tab2_image_path))

        img_stem = Path(self.tab2_image_path).stem if self.tab2_image_path else "config"
        default_name = f"{img_stem}_config.json"

        save_path = filedialog.asksaveasfilename(
            title="Save Configuration",
            initialdir=init_dir,
            initialfile=default_name,
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )

        if save_path:
            data = {
                "image_path": self.tab2_image_path,
                "polygon_points": self.tab2_roi_points.tolist(),
                "pipeline_params": self.params
            }

            with open(save_path, 'w') as f:
                json.dump(data, f, indent=4)

            # ── Also write a copy to configurations/conf.json so Batch tab
            #    can auto-load it on next startup ──────────────────────────
            try:
                conf_dir = Path(__file__).resolve().parent / 'configurations'
                conf_dir.mkdir(exist_ok=True)
                with open(conf_dir / 'conf.json', 'w') as _cf:
                    json.dump(data, _cf, indent=4)
            except Exception:
                pass  # never block the main save if this fails

            messagebox.showinfo("Success", f"Configuration saved to {save_path}")

    def tab2_load_config(self):
        """Load configuration from JSON.
        When polygon_points are present, pre-loads them into the Step 1 drawing
        state so that clicking 'Start Processing' will show the saved polygon
        in Step 1 rather than an empty canvas.
        """
        file_path = filedialog.askopenfilename(
            title="Load Configuration",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )

        if file_path:
            with open(file_path, 'r') as f:
                data = json.load(f)

            # Load ROI points into BOTH the roi_points array AND the Step 1
            # polygon drawing state so Start Processing can restore them.
            if 'polygon_points' in data:
                pts = data['polygon_points']
                self.tab2_roi_points       = np.array(pts, dtype=np.int32)
                # Pre-fill Step 1 drawing state
                self.step1_polygon_points  = [tuple(p) for p in pts]
                self.step1_polygon_closed  = True
            else:
                # Config has no polygon   clear any previously loaded ROI
                self.tab2_roi_points      = None
                self.step1_polygon_points = []
                self.step1_polygon_closed = False

            # Load pipeline parameters.
            # REGRESSION FIX (R6): merge onto defaults rather than replace
            # outright -- see _merge_pipeline_params for why.
            if 'pipeline_params' in data:
                self.params = self._merge_pipeline_params(data['pipeline_params'])

            messagebox.showinfo("Success", "Configuration loaded successfully")
            self.tab2_info_label.config(
                text=f"Configuration loaded "
                     f"({'ROI ready – click Start Processing to review in Step 1' if self.tab2_roi_points is not None else 'No ROI in file – draw ROI in Step 1'}).")

